#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-

from docutils import nodes

from functools import partial

import sphinx.ext.autodoc as ad
from sphinx.util import nested_parse_with_titles
from docutils.statemachine import ViewList

def to_sing(x):
    if x.endswith("es"):
        return x[:-2]
    else:
        return x[:-1]


def _auto_directives(dirname, arguments, options, content, lineno,
                    content_offset, block_text, state, state_machine):
    results = []
    for arg in filter(None, arguments[0].split(" ")):
        results.extend(
            ad.AutoDirective(to_sing(dirname), [arg],
                             options, content, lineno, content_offset,
                             block_text, state, state_machine).run())
    return results



def _automodule2(dirname, arguments, options, content, lineno,
                 content_offset, block_text, state, state_machine):

    node = nodes.section()

    content1 = ViewList()

    content1.append(":mod:`%s` -- |modtitle|" % (arguments[0], ), state.document, lineno + 1)
    content1.append("=============================================================", state.document, lineno + 2)
    content1.append("", state.document, lineno + 3)
    content1.append(".. automodule:: %s" % (arguments[0], ), state.document, lineno + 4)
    if "members" in options:
        if options["members"] is None:
            options["members"] = ""
        content1.append("   :members: %s" % (options["members"], ), state.document, lineno + 4)
    if "show-inheritance" in options:
        content1.append("   :show-inheritance:", state.document, lineno + 4)


    content1.append("", state.document, lineno)
    for l in content:
        content1.append("   " + l, state.document, lineno + 99)
    content1.append("", state.document, lineno)

    nested_parse_with_titles(state, content1, node)
    return node.children


def setup(app):
    cls_options = {'members': lambda x: x,
                   'undoc-members': ad.bool_option,
                   'noindex': ad.bool_option,
                   'inherited-members': ad.bool_option,
                   'show-inheritance': ad.bool_option}

    app.add_directive("autofunctions", _auto_directives,
                      content = 0, arguments = (1, 0, 1))
    app.add_directive("autoclasses", _auto_directives,
                      content = 0, arguments = (1, 0, 1), **cls_options)
    app.add_directive("prettyautomodule", _automodule2,
                      content = 1, arguments = (1, 0, 0), **cls_options)

