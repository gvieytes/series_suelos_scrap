"""The bibstyles package provides classes and styles for formatted text output.

This is the __init__.py for bibstyles package
"""

