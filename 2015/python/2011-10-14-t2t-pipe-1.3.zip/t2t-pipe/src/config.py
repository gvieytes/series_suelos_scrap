#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# config.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# 2010-2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Configuration File (executable)

Main configuration file for Tree-to-Tree Alignment Pipe (:mod:`t2t_pipe`). Update this file before 
you run the program. 

.. note::

    This file is executable and can be run from any directory. It makes sense to have one
    configuration file for every corpus / subcorpus used in the pipe. The contents of
    this file will be copied to :const:`T2T_SCRIPTDIR`. 

.. warning::

    The file ``config.py`` in :const:`T2T_SCRIPTDIR` will be overwritten if this configuration file is 
    executed from a directory other than the one specified in :const:`T2T_SCRIPTDIR`.

**Usage**

There are two ways of starting the pipe

- update and run ``config.py`` (from any directory on your system)

or

- update ``config.py`` in :const:`T2T_SCRIPTDIR` and run::

    t2t_pipe.py [-1 FIRST_STEP (default=1)] [-2 LAST_STEP (default=7)]

    1    extract parallel corpus / add article boundaries
    2    tokenize parallel corpus
    3    align sentences
    4    parse corpus
    5    get word-alignment probabilities
    6    get tree2tree alignments
    7    save output files

If you want to execute this file, specify the :const:`FIRST_STEP` and :const:`LAST_STEP` variables below (e.g. 
``FIRST_STEP = "2"``, ``LAST_STEP = "4"``).

"""
import codecs
import os
import subprocess
import time

#: Global Corpus Metadata (used e.g. for TigerXML header)
AUTHOR = u"Markus Killer"
#: Global Corpus Metadata (used e.g. for automatically generated filenames and TigerXML header)
CORPUS_YEARS = u"2011-10"
#: Global Corpus Metadata (used e.g. for automatically generated filenames and TigerXML header)
CORPUS_ID = u"sac"
#: Global Corpus Metadata (used e.g. for TigerXML header)
DESCRIPTION = u"Parallel Articles extracted from  SAC Zeitschrift Die Alpen/Les Alpes (http://www.sac-cas.ch) - Okt 2011 - de-fr"
#: Global Corpus Metadata (used e.g. for TigerXML header)
LICENSE = u""

#: The following languages are supported: German "de", French "fr" and English "en" (`Language Codes <http://en.wikipedia.org/wiki/List_of_ISO_639-1_codes>`_)
LANGUAGE_1 = "de"
#: Varieties: e.g. CH, DE, FR, CA, US, GB (see 
#:`English Country Codes <http://www.iso.org/iso/english_country_names_and_code_elements>`_)
VARIETY_1 = "CH"
#: The following languages are supported: German "de", French "fr" and English "en" (`Language Codes <http://en.wikipedia.org/wiki/List_of_ISO_639-1_codes>`_)
LANGUAGE_2 = "fr"

#: see :const:`VARIETY_1`
VARIETY_2 = "CH"

#: Tree2Tree-Pipe Script-Directory (the directory where all the modules of this program - 
#: including :mod:`t2t_pipe` are located)
T2T_SCRIPTDIR = '/home/mki/workspace/t2t-pipe-dev/src'

#: Value for command line option :option:`--first_step` of :mod:`t2t_pipe`
FIRST_STEP = "1"
#: Value for command line option :option:`--last_step` of :mod:`t2t_pipe`
LAST_STEP = "7"

#: The following input formats are supported: ``"XML"``, ``"TXT"`` and ``"EUROPARL"`` for details on 
#: input formats see :mod:`extract_corpus`.
INPUT_FORMAT = "TXT"
REMOVE_MID_SNT_NEWLINES = True
#: If ``True``, all input files are concatenated into one big file.
#: 
#: .. warning::
#: 
#:        If you are using ``hunalign`` and your corpus size is bigger than 20000 sentence pairs, 
#:        set :const:`ONE_BIG_FILE` ``= False``.
ONE_BIG_FILE = False
#: create new file before MAX_LINES_PER_FILE lines in L1 corpus (0 -> original file size)
MAX_LINES_PER_FILE = 0

#: Options: ``OUTPUT_FORMATS = ["TigerXML","TMX_SENT", "TMX_PHRASE"]``
#: In order to get just a ``TMX_SENT`` output, a run through steps 1-3, followed by step 7
#: is sufficient. ``TigerXML`` and ``TMX_PHRASE``, however require a tree aligned corpus.
#: 
#: .. warning::
#:
#:        The production of the ``TMX_PHRASE`` output is based on the ``TigerXML`` files`
#:        (i.e. ``TMX_PHRASE`` has to follow after ``TigerXML`` in :const:`OUTPUT_FORMATS`).
#:
#: .. note::
#:     The module :mod:`save_output` is executable and can be used to update the phrase segmented 
#:     tmx-files once the alignments have been manually checked and corrected, using 
#:     the :program:`Stockholm TreeAligner` (see: http://kitt.cl.uzh.ch/kitt/treealigner)
#:
#: Recommended programs to work with output files:
#
#:     - Files ending with ``sta.xml``    :program:`Stockholm TreeAligner` (http://kitt.cl.uzh.ch/kitt/treealigner)
#:
#:     - Files ending with ``.tmx``    Translation Memory System (e.g. :program:`OmegaT` http://www.omegat.org/en/omegat.html)
#:
OUTPUT_FORMATS = ["TigerXML", "TMX_SENTS", "TMX_PHRASES"]

#: The program looks for a format specific subdirectory (:const:`CORPUS_XML_DIRECTORY` or 
#: :const:`CORPUS_TXT_DIRECTORY` containing your corpus.
CORPUS_BASE_DIRECTORY = os.path.abspath('../test/t2t-pipe-demo/xml')
#: XML-Directory where corpus files are stored: ``file1_de.xml, file1_fr.xml, file2_de.xml, file2_fr.xml ...``
#: Currently, the following XML document structure is supported::
#: 
#:   <book id="file1_de">
#:      <article n="ARTICLE_ID" translation-of="file1_fr.xml:ARTICLE_ID">
#:         <div>PLAIN_TEXT_TO_BE_EXTRACTED</div>
#:      </article> </book>
#:
CORPUS_XML_DIRECTORY = os.path.join(CORPUS_BASE_DIRECTORY, "xml")

#: in multifile mode: index of file and language identifiers in 
#: ``original_filename.split(SPLIT-SYMBOL)``::
#:
#:    example file names: sac_1977_de.xml and sac_1977_fr.xml
#:
#:               SPLIT-SYMBOL, INDEX FID, INDEX LANG-ID, L1-ID, L2-ID
#:    XML_FID =  (    "_"    ,    1     ,      2       , "de" ,  "fr" )
#:
XML_FID = ("_", 1, 2, "de", "fr")

#: The following ``XML`` source formats are supported: 
#: * ``"TUB"``     - preliminary ``XML`` format of "Text- und Berg"-Pipe (see :mod:`extract_corpus`)
#: * ``"PDF2TXT"`` - ``XML`` files extracted from pdf source files by :mod:`resources.convert_files`
XML_SOURCE = "TUB"

#: For 'Text- und Berg' corpus only: If ``True`` - extract articles specified in
#: :const:`TUB_SELECTED_ARTICLES_L1`
TUB_SELECTED_ARTICLES = False
#: For 'Text- und Berg' corpus only: If :const:`TUB_SELECTED_ARTICLES_L1` is ``True`` only articles
#: specified in tuple ``(YEAR, [article_L1_id1, article_L1_id2, ...])`` are extracted.
TUB_SELECTED_ARTICLES_L1 = (1977, [15, 16, 21, 22] )

#: TXT-Directory where corpus files are stored: 
#:
#: * If :const:`INPUT_FORMAT` ``="TXT"``: ``file1_de.txt, file1_fr.txt, file2_de.txt, file2_fr.txt ...``
#: * If :const:`INPUT_FORMAT` ``="EUROPARL"``: ``de/file1.txt, fr/file1.txt, de/file2.txt, fr/file2.txt ...``
CORPUS_TXT_DIRECTORY = os.path.join(CORPUS_BASE_DIRECTORY, "txt")

#: in multifile mode: index of file and language identifiers in 
#: ``original_filename.split(SPLIT-SYMBOL)``::
#:
#:    example file names: sac_1977_de.txt and sac_1977_fr.txt
#:
#:               SPLIT-SYMBOL, INDEX FID, INDEX LANG-ID, L1-ID, L2-ID
#:    TXT_FID =  (    "_"    ,    1     ,      2       , "de" ,  "fr" )
#:
TXT_FID = ("-", 1, 2, "de", "fr")

#: For each project name a new directory will be created in :const:`CORPUS_BASE_DIRECTORY`.
T2T_PROJECT_NAME = "sac_2011-10_hun_stan_stan_tub_eparl"
T2T_BASE_DIRECTORY = os.path.join(CORPUS_BASE_DIRECTORY, "t2t")
T2T_PROJECT_BASE_DIRECTORY = os.path.join(T2T_BASE_DIRECTORY, T2T_PROJECT_NAME)
#: All corpus files are copied to this directory.
INPUT_DIRECTORY = os.path.join(T2T_PROJECT_BASE_DIRECTORY, "input")
TMP_DIRECTORY = os.path.join(T2T_PROJECT_BASE_DIRECTORY, "tmp")
OUTPUT_DIRECTORY = os.path.join(T2T_PROJECT_BASE_DIRECTORY, "output")
OUTPUT_XML = os.path.join(OUTPUT_DIRECTORY, "xml")
OUTPUT_TMX = os.path.join(OUTPUT_DIRECTORY, "tmx")


#: Specify this path if you already have good word alignment probability files for the current
#: Language pair. The directory must contain two files ``lex.e2f`` and ``lex.f2e``. These files are
#: produced by running steps 1 to 4 of ``train-model.perl`` (part of moses SMT
#: training scripts). If you intend to use a different word alignment tool (e.g. Berkeley Aligner),
#: these files have to be formatted in the following way::
#: 
#:    lex.e2f:
#:    <word_l2> <word_l1> <probability>\n
#:    ...
#:
#:    lex.f2e:
#:    <word_l1> <word_l2> <probability>\n
#:    ...
#:
PATH_TO_WORD_ALIGNMENT_PROBS = "/opt/cl/t2t-pipe/dicts"
UPDATE_WORD_PROBS_WITH_DICT = False


##########################################################
#
# Root Directories Tools
#
# Choose preferred tools and update root directories
#
##########################################################

#: Dictionary with absolute paths to sentence alignment tools
SENTENCE_ALIGNER_ROOT_DIRECTORIES = {
    "gargantua"        :'/opt/cl/sentence-alignment/Gargantua1.0/',
    "hunalign"         :'/opt/cl/sentence-alignment/hunalign-1.1/src/hunalign',
    "microsoft"        :'/opt/cl/sentence-alignment/ms_bsa-1.0',
    "vanilla"          :'/opt/cl/sentence-alignment/vanilla/src'

                                     }
#: Currently selected sentence alignment tool
SENTENCE_ALIGNER = "hunalign"
SENTENCE_ALIGNER_ROOT = SENTENCE_ALIGNER_ROOT_DIRECTORIES[SENTENCE_ALIGNER]

##########################################################
## hunalign options
##########################################################

#: source of hunalign dictionary - Options: "no_dict", "dict_cc"
DICT_SOURCE = "dict_cc"
#: directory of hunalign dictionary
DICT_DIRECTORY = "/opt/cl/t2t-pipe/dicts"

#: All alignments that have an alignment score greater than this value are 
#: extracted to the aligned corpus (approx. range: ``-10`` to ``+ 10``).
#: The vast majority of sentences are aligned correctly with a value between ``0.3`` and ``1.5``.
#:
#: **Recommended values** 
#:    * for word alignment model: ``0.3`` (or above)
#:    * for good corpus coverage: ``-0.5``  
HUNALIGN_THRESHOLD = -0.5
#: If set to ``True``, hunalign will realign sentences even if a dictionary is supplied
HUNALIGN_FORCE_REALIGN = False

##########################################################
## Microsoft Bilingual Sentence Aligner Options
##########################################################

#: :program:`MS Bilingual Sentence Aligner` Probability threshold - only sentences with  
#: alignment probability greater than threshold will be aligned.
INITIAL_THRESHOLD = 0.9
#: Additional tmp directory for huge amount of additional files produced by :program:`MS Bilingual Sentence Aligner`
MICROSOFT_BSA_TMP = os.path.join(TMP_DIRECTORY, 'bsa')

#: Optional combination of two sentence aligners (idea - not yet implemented)
#: Use only very high probability alignments of aligner 1 to segment tokenized text
#: into smaller units, then use vanilla aligner to align finely segmented texts.
#: Became somewhat obsolete after the integration of :program:`Hunalign` but it might
#: be interesting to come back to this idea for a pre-segmentation of otherwise 
#: completely unsegmented input. Especially, if there are passages that are only included
#: in one language.
COMBINE_SA_1_and_2 = False
SENTENCE_ALIGNER_2 = "vanilla"
SENTENCE_ALIGNER_2_ROOT = SENTENCE_ALIGNER_ROOT_DIRECTORIES[SENTENCE_ALIGNER_2]

#: Dictionary with absolute paths of parsers
PARSER_ROOT_DIRECTORIES = {
    "berkeley_de"          :'/opt/cl/parsing/berkeley-parser-2009-09-17',
    "berkeley_fr"          :'/opt/cl/parsing/berkeley-parser-2009-09-17',
    "berkeley_en"          :'/opt/cl/parsing/berkeley-parser-2009-09-17',
    "stanford_old_de"      :'/opt/cl/parsing/stanford-parser-2010-11-30',
    "stanford_de"          :'/opt/cl/parsing/stanford-parser-2011-08-04',
    "stanford_en"          :'/opt/cl/parsing/stanford-parser-2011-08-04',
    "stanford_fr"          :'/opt/cl/parsing/stanford-parser-2011-08-04'
                            }
#: Parser used to parse :const:`Language_1`
PARSER_L1 = "stanford_de"
PARSER_L1_ROOT = PARSER_ROOT_DIRECTORIES[PARSER_L1]
#: Parser used to parse :const:`Language_1`
PARSER_L2 = "stanford_fr"
PARSER_L2_ROOT = PARSER_ROOT_DIRECTORIES[PARSER_L2]

#: Dictionary with absolute paths to word alignment tools
WORD_ALIGNER_ROOT_DIRECTORIES = {
    "berkeley"         : '/opt/cl/word-alignment/berkeleyaligner',
    "berkeley_syn"     : '/opt/cl/word-alignment/berkeleyaligner',
    "giza"             : '/opt/cl/bin',
    "giza_in_moses"    : '/opt/cl/moses/scripts-20110609-1609/training',
                                }

#: Currently selected word alignment tool
WORD_ALIGNER = "giza_in_moses"
WORD_ALIGNER_ROOT = WORD_ALIGNER_ROOT_DIRECTORIES[WORD_ALIGNER]
#: Additional tmp directory for files produced by :program:`GIZA++` (does not work for 
#: ``"giza_in_moses"`` option
GIZA_TMP = os.path.join(TMP_DIRECTORY, 'giza')

#: Dictionary with absolute paths to Tree-to-Tree Alignment Tools
TREE2TREE_ALIGNER_ROOT_DIRECTORIES = {
    "zhechev"         : '/opt/cl/zhechev_treealigner/curr/bin',
    "zhechev_str2str" : '/opt/cl/zhechev_treealigner/curr/bin'
                                }
#: Currently selected tree-to-tree alignment tool
TREE2TREE_ALIGNER = "zhechev"
TREE2TREE_ALIGNER_ROOT = TREE2TREE_ALIGNER_ROOT_DIRECTORIES[TREE2TREE_ALIGNER]



####################################################################################################
# USUALLY NO CHANGES NEEDED BEYOND THIS POINT
####################################################################################################

##########################################################
# Character Replacements / Character exclusions
# (before Tokenisation)
##########################################################

#: Language specific characters in this dictionary are replaced in :py:func:`prepare_corpus.clean_line_de`.
#: E.g. ``Œ/œ -> OE/oe, ß -> ss « -> "`` etc.
CHARACTER_REPLACEMENT_DICTIONARY_DE = {u'Œ':u'OE',
                                       u'œ':u'oe',
                                       u'ß':u'ss'}
#: Language specific characters in this dictionary are replaced in :py:func:`prepare_corpus.clean_line_en`.
#: E.g. ``Œ/œ -> OE/oe, ß -> ss « -> "`` etc.
CHARACTER_REPLACEMENT_DICTIONARY_EN = {}
#: Language specific characters in this dictionary are replaced in :py:func:`prepare_corpus.clean_line_fr`.
#: E.g. ``Œ/œ -> OE/oe, ß -> ss « -> "`` etc.
CHARACTER_REPLACEMENT_DICTIONARY_FR = CHARACTER_REPLACEMENT_DICTIONARY_DE



#: Characters in this list are removed from corpus source in
#: :py:func:`clean_txt_files`. E.g. u"\xad" (hidden word-break) causes warnings and
#: unwanted word-breaks when fed to :program:`Stanford Parser`.
#: 
#: Other possibly noisy characters: ``■ [u'\u25a0'], — [u'\u2014'], • [u'\u2022']``
CHARACTER_STOP_LIST = [u'\xad', u'\u2014', u'\u2022', u'\u25a0', u'\u000C\n']

##########################################################

#: Turn rudimentary OCR-Cleaning on (True) and off (False)
#: Used in :py:func:`run_preprocessor.rudimentary_clean_ocr_debris`
RUDIMENTARY_OCR_CLEANING = False

#: list of very short words (for all languages) that should not be filtered out by 
#: :const:`MIN_LETTERS_PER_SENT`
with codecs.open(os.path.join(T2T_SCRIPTDIR, 'resources', 'very_short_words.txt'),
                 'r', 'utf-8') as in_f:
    VERY_SHORT_WORDS = [line.strip() for line in in_f]

LETTERS = u'ABCDEFGHIJKLMNOPQRSTUXYZÄÂÀÁÇÈÊÉËÎÍÌÏÖÓÕÔÜÛÙÚabcdefghijklmnopqrstuvwxyzäàâáãåæçéèëêîíìïℓööóòôùúûü'
NUMBERS = u'0123456789'
#: Smallest number of letters per sentence used for :const:`RUDIMENTARY_OCR_CLEANING`
MIN_LETTERS_PER_SENT = 4
#: lowercased variant of :const:`LANGUAGE_1`
L1 = LANGUAGE_1.lower()
#: lowercased variant of :const:`LANGUAGE_2`
L2 = LANGUAGE_2.lower()

L1_TIGERxml = L1 + "_" + VARIETY_1.upper()
L2_TIGERxml = L2 + "_" + VARIETY_2.upper()

L1_TMX = L1.upper() + "-" + VARIETY_1.upper()
L2_TMX = L2.upper() + "-" + VARIETY_2.upper()

PA = "_parallel_articles_"

def timestamp():
    '''Create timestamp for status messages.'''
    return time.strftime("%d-%m-%Y %H:%M:%S")

def timestamp_filename():
    '''Create timestamp used in file names.'''
    return time.strftime("%y-%m-%d-%H-%M-%S")

def date():
    '''Return current date DD-MM-YY.'''
    return time.strftime("%d-%m-%y")

def date_2():
    '''Return current date YYYY-MM-DD.'''
    return time.strftime("%Y-%m-%d")

def main():
    '''Copy config.py to script directory and run t2t_pipe.py with the current specifications.'''
    if os.getcwd() != T2T_SCRIPTDIR:
        with codecs.open(__file__, "r+b", "utf-8") as conf:
            with codecs.open(os.path.join(T2T_SCRIPTDIR, "config.py"), "w", "utf-8") as conf_copy:
                for line in conf:
                    conf_copy.write(line)
        time.sleep(0.5)
    run_t2t_pipe = subprocess.Popen(["./t2t_pipe.py",
                                     "--first_step=" + FIRST_STEP,
                                    "--last_step=" + LAST_STEP],
                                    cwd=T2T_SCRIPTDIR)
    run_t2t_pipe.wait()

if __name__ == '__main__':
    main()
