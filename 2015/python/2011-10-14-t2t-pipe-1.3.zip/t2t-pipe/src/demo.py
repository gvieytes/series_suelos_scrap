#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-

# demo.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# October 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Demo
"""
import resources.download_files
import resources.convert_files
import resources.build_sac_web_corpus
import t2t_pipe
import os

test_dir    = "../test"
demo_dir    = "../test/t2t-pipe-demo"
dl_dir      = "../test/t2t-pipe-demo/pdf"
xml_dir     = "../test/t2t-pipe-demo/xml"

def check_or_create_dir(directory):
    if os.path.isdir(directory):
        print "exists: ", directory
    else:
        os.mkdir(directory)
        print "created: ", directory

def run_demo(scope):
    print "Running demo: {0}".format(scope)
    check_or_create_dir(test_dir)
    check_or_create_dir(demo_dir)
    check_or_create_dir(dl_dir)
    check_or_create_dir(xml_dir)
    resources.download_files.check_or_create_dir(dl_dir)
    resources.download_files.download_sac(dl_dir)
    resources.convert_files.pdftoxml(dl_dir, "ad", xml_dir, "sac-", "-de", "utf-8")
    resources.convert_files.pdftoxml(dl_dir, "af", xml_dir, "sac-", "-fr", "utf-8")
    resources.build_sac_web_corpus.check_or_create_dir(os.path.join(xml_dir, "txt"))
    resources.build_sac_web_corpus.generate_sac_toc(xml_dir)
    if scope == "all":
        t2t_pipe.prepare_t2t_filesystem()
        for i in range(1, 8):
            t2t_pipe.run_step(i)
        
    
    
    
    
    

if __name__ == '__main__':
    # all = complete demo
    # build_sac_webcorpus = download and build_sac_webcorpus
    run_demo("all")
    #run_demo("build_sac_webcorpus")
    
    
    
