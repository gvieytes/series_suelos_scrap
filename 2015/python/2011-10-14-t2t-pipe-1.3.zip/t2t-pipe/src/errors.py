#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-

# errors.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Error messages
"""
import config
import os
import sys


SUPPORTED_LANGUAGES = ["de", "en", "fr"]


def check_languages():
    '''Return ``True`` if both languages of the language pair specified in :mod:`config` 
    are supported by the tools currently implemented in this program. 
    
    If one or both languages are not supported, the program will terminate (``sys.exit(-1)``).

    '''
    if config.L1 not in SUPPORTED_LANGUAGES:
        err_log("L1: " + LANGUAGE_NOT_SUPPORTED)
        err_log_and_exit("The following languages are supported:  " + ", ".join(SUPPORTED_LANGUAGES))
    if config.L2 not in SUPPORTED_LANGUAGES:
        err_log("L2: " + LANGUAGE_NOT_SUPPORTED)
        err_log_and_exit("The following languages are supported:  " + ", ".join(SUPPORTED_LANGUAGES))
    else:
        return True


def check_parallel_input_files(l1_files, l2_files, in_dir, req_ext):
    '''Return ``True`` if required parallel input files exist in :py:attr:`in_dir`. 
    
    If files are missing, the program will print an error meassage on ``sys.stderr`` 
    and terminate (``sys.exit(-1)``).

    '''
    if len(l1_files) > 0  and len(l1_files) == len(l2_files):
        return True
    else:
        err_log_and_exit(
        """
        
        ***Input file ERROR:
        directory: {0}
        required file extension: {1}
        # L1 files: {2} - # L2 files: {3}
        
        """.format(in_dir, req_ext, len(l1_files), len(l2_files)))

def check_snt_aligned_files(l1_file, l2_file):
    '''Return ``True`` if parallel sentence aligned files have exactly the same number of lines.
    
    If not, the program will print an error meassage on ``sys.stderr`` 
    and terminate (``sys.exit(-1)``).

    '''
    with open(l1_file, "r") as f_l1:
        lines_l1 = [line.strip() for line in f_l1]
    with open(l2_file, "r") as f_l2:
        lines_l2 = [line.strip() for line in f_l2]
        
    if len(lines_l1) == len(lines_l2):
        return len(lines_l1)
    else:
        err_log_and_exit(
        """
        
        ***Sentence Alignment ERROR:
        files: 
        L1: {0}
        L2: {1}
        need to have exactly the same number of lines:
        # Lines L1: {2} - # Lines L2: {3}
        
        """.format(l1_file, l2_file, len(lines_l1), len(lines_l2)))

def check_input_files(files, in_dir, req_ext):
    '''Return ``True`` if required input file(s) exist/s in :py:attr:`in_dir`. 
    
    If file(s) is/are missing, the program will print an error meassage on ``sys.stderr`` 
    and terminate (``sys.exit(-1)``).

    '''
    if len(files) > 0:
        return True
    else:
        err_log_and_exit(
        "\n\n***No input file ERROR:\n\n" +
        "directory: " + in_dir + "\n"
        "required file extension: " + req_ext)


def check_directory(directory):
    '''Return ``True`` if required directory exists and if there are any files in it. 
    
    If the directory is missing or empty, the program will print an error meassage on ``sys.stderr`` 
    and terminate (``sys.exit(-1)``).

    '''

    if os.path.isdir(directory) is False:
        err_log(DIRECTORY_DOES_NOT_EXIST)
        err_log(directory)
        err_log_and_exit("\n\n")
    elif len(os.listdir(directory)) == 0:
        err_log(DIRECTORY_IS_EMPTY)
        err_log(directory)
        err_log_and_exit("\n\n")
    else:
        return True

def err_log(s):
    '''Print error message :py:attr:`s` to ``sys.stderr`` 
    '''

    sys.stderr.write(s)

def err_log_and_exit(s):
    '''Print error message :py:attr:`s` to ``sys.stderr`` and exit ``sys.exit(-1)`` 
    '''
    sys.stderr.write(s)
    sys.exit(-1)
#:
CMD_LINE_ARGS_ERROR = '''
*** tree2tree_pipe error: Wrong number or type of command line arguments ***


    Usage: tree2tree_pipe.py [first step - default=1] [last step - default=7]
    
    Example: tree2tree_pipe.py 2 5    (to run steps two to five)
    
'''
#:
LANGUAGE_NOT_SUPPORTED = '''

*** tree2tree_pipe error: the language specified in config.py is not supported ***

'''
#:
DIRECTORY_DOES_NOT_EXIST = '''
*** tree2tree_pipe error: the following directory, specified in config.py does not exist: ***

'''
#:
DIRECTORY_IS_EMPTY = '''
*** tree2tree_pipe error: the following directory, specified in config.py is empty: ***

'''
#:
FILE_DOES_NOT_EXIST = '''
*** tree2tree_pipe error: an input file for the following function could not be found: ***

'''
#:
L1_L2_NOT_EQUAL_NO_OF_FILES = '''
*** tree2tree_pipe error: the number of files for L1 and L2 needs to be equal ***

- check files and directories for the following function:

'''
#:
INPUT_FORMAT_NOT_SUPPORTED = '''
*** tree2tree_pipe error: the input format specified in config.py is not supported ***

    Solution: choose different input format or modify the files listed below:
    
    - tree2tree_pipe (modify function in step 1 - add new input format)
    - check_and_extract_corpus.py (add function for new input format)
    
'''
#:
ONE_BIG_FILE_ERROR = '''
*** tree2tree_pipe error in config.py: 

ONE_BIG_FILE: True
Nr. of txt-files to be processed:
  
'''
#:
SENTENCE_ALIGNER_NOT_IMPLEMENTED = '''
*** tree2tree_pipe error: the sentence aligner specified in config.py is not yet implemented ***

    Solution: choose different sentence aligner or modify the files listed below:
    
    - config.py (add ROOT_DIRECTORY for new sentence aligner)
    - run_sent_align.py (modify 1st function and add function for new sentence aligner)
    
'''
#:
PARSER_NOT_IMPLEMENTED = '''
*** tree2tree_pipe error: the parser specified in config.py is not yet implemented ***

    Solution: choose different parser or modify the files listed below:
    
    - config.py (add ROOT_DIRECTORY for new parser)
    - run_parser.py (modify 1st function and add function for new parser)
    
'''
#:
NO_GIZA_DICTIONARY_FILES_FOUND = '''
    GIZA/MOSES lex.e2f and/or lex.f2e files could not be found. Specify PATH_TO_WORD_ALIGNMENT_PROBS
    in config.py or run word alignment step before trying to align trees.
    
'''
#:
NO_DICT_AFTER_GIZA = '''
    no dictionary file specified, next step will be run with original 
    moses/giza lex.e2f, lex.f2e files in order to obtain better alignment 
    results you might want to add a dictionary file (downloadable e.g. from dict.cc)
    
'''
#:
WORD_ALIGNER_NOT_IMPLEMENTED = '''
*** tree2tree_pipe error: the word aligner specified in config.py is not yet implemented ***

    Solution: choose different word aligner or modify the files listed below:
    
    - config.py (add ROOT_DIRECTORY for new word aligner)
    - run_word_align.py (modify 1st function and add function for new word aligner)
    
'''
#:
TREE2TREE_ALIGNER_NOT_IMPLEMENTED = '''
*** tree2tree_pipe error: the tree2tree aligner specified in config.py is not yet implemented ***

    Solution: choose different tree2tree aligner or modify the files listed below:
    
    - config.py (add ROOT_DIRECTORY for new tree2tree aligner)
    - run_tree2tree_align.py (modify 1st function and add function for new tree2tree aligner)
    
'''
#:
OUTPUT_FORMAT_NOT_SUPPORTED = '''
*** tree2tree_pipe error: one or more of the output formats specified in config.py is not supported ***

    Solution: choose different output format or modify the files listed below:\n
    - save_output.py (modify 1st function and add function/filter for new output format)
'''
#:
UNSPECIFIED_ERROR = '''There has been an UNSPECIFIED ERROR in the following module and function:\n\n'''
