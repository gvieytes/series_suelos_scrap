#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# extract_corpus.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Extract Corpus

Extract raw text data from other formats (e.g. ``xml``)

Supported input formats:

* ``TXT`` - plain text files - both languages in the same directory with a language identifier in the file name (e.g. ``file1_de.txt``, ``file1_fr.txt``) 
* ``EUROPARL`` - text files - languages in separate directories (e.g. ``de/file1.txt``, ``fr/file1.txt``)
* ``XML`` - ``xml``-files - both languages in the same directory with a language identifier in the file name (e.g. ``file1_de.xml``, ``file1_fr.xml``) currently only a specific, intermediate format of the 'Text- und Berg' corpus is supported, but the tags can be easily adjusted in the functions :py:func:`extract_from_xml` and :py:func:`extract_article_from_xml` ::


   f1_de.xml                                     | f2_fr.xml
                                                 |
   <?xml version='1.0' encoding='UTF-8'?>        | <?xml version='1.0' encoding='UTF-8'?>
   <book id="1_de">                              | <book id="1_fr"> 
    <article n="2" translation-of="f1_fr.xml:1"> |  <article n="1" translation-of="f1_de.xml:2">
     <tocEntry title="T" author="A" lang="de"/>  |   <tocEntry title="T" author="A" lang="de"/>
     <div>TEXT</div> ...                         |   <div>TEXT</div> ...
    </article> </book>                           |  </article> </book>



"""
#from xml.etree import cElementTree as ET
from lxml import etree as ET
import codecs
import config
import get_files
import os


def get_txt_files_from_xml():
    l1_files_xml = []
    l2_files_xml = []
    if config.TUB_SELECTED_ARTICLES:
        l1_all_files_xml, l2_all_files_xml = get_files.get_corpus_src_files()
        for l1_file, l2_file in zip (l1_all_files_xml, l2_all_files_xml):
            print l1_file
            print l2_file
            if str(config.TUB_SELECTED_ARTICLES_L1[0]) in l1_file.split(os.sep)[-1]: 
                l1_files_xml.append(l1_file)
            if str(config.TUB_SELECTED_ARTICLES_L1[0]) in l2_file.split(os.sep)[-1]:
                l2_files_xml.append(l2_file)
    else:
        l1_files_xml, l2_files_xml = get_files.get_corpus_src_files()
    
    print l1_files_xml
    print l2_files_xml

    if config.ONE_BIG_FILE is False or len(l1_files_xml) == 1:
        for f in l1_files_xml:
            l1_file_xml = f.split(os.sep)[-1]
            l2_file_xml = f.split(os.sep)[-1][:-6] + config.L2 + ".xml"
            l1_file_name = f[:-7] + config.PA + config.L1 + '_raw.txt'
            l2_file_name = f[:-7] + config.PA + config.L2 + '_raw.txt'
            l1_file_raw_txt = codecs.open(os.path.join(config.INPUT_DIRECTORY, l1_file_name),
                                          'w', 'utf-8')
            l2_file_raw_txt = codecs.open(os.path.join(config.INPUT_DIRECTORY, l2_file_name),
                                          'w', 'utf-8')
            extract_from_xml(l1_file_xml, l2_file_xml, l1_file_raw_txt, l2_file_raw_txt)
            l1_file_raw_txt.close()
            l2_file_raw_txt.close()
        return True

    elif config.ONE_BIG_FILE is True:
        l1_file_name = config.CORPUS_ID + "_" + config.CORPUS_YEARS + config.PA + \
                       config.L1 + '_raw.txt'
        l2_file_name = config.CORPUS_ID + "_" + config.CORPUS_YEARS + config.PA + \
                       config.L2 + '_raw.txt'
        l1_file_raw_txt = codecs.open(os.path.join(config.INPUT_DIRECTORY, l1_file_name),
                                      'w', 'utf-8')
        l2_file_raw_txt = codecs.open(os.path.join(config.INPUT_DIRECTORY, l2_file_name),
                                      'w', 'utf-8')
        for f in l1_files_xml:
            l1_file_xml = f.split(os.sep)[-1]
            l2_file_xml = f.split(os.sep)[-1][:-6] + config.L2 + ".xml"
            extract_from_xml(l1_file_xml, l2_file_xml, l1_file_raw_txt, l2_file_raw_txt)
        l1_file_raw_txt.close()
        l2_file_raw_txt.close()
        return True


def extract_from_xml(l1_file_xml, l2_file_xml, l1_file_raw_txt, l2_file_raw_txt):
    """Extract text from SAC Text und Berg Corpus xml files
    
    (c) 2010 by Rico Sennrich
    last modified: mki - 09.09.2010
    """
    str_buf = ''

    xml_l1 = ET.parse(os.path.join(config.INPUT_DIRECTORY, l1_file_xml))
    bookid = xml_l1.getroot().get('id')

    for article in xml_l1.findall('article'):
        print "working through book: ", bookid
        print article
        transarticle = article.get('translation-of')
        articleid = article.get('n')
        print transarticle
        print articleid
        if transarticle == None:
            continue

        transarticle = transarticle.split(':')
        xml_l2 = ET.parse(os.path.join(config.INPUT_DIRECTORY, l2_file_xml))
        for article2 in xml_l2.findall('article'):
            if config.TUB_SELECTED_ARTICLES:
                if int(article.get('n')) in config.TUB_SELECTED_ARTICLES_L1[1] \
                and article2.get('n') == transarticle[1]:
                    extract_article_from_xml(article, article2, l1_file_raw_txt, l2_file_raw_txt, str_buf)
            else:
                if article2.get('n') == transarticle[1]:
                    extract_article_from_xml(article, article2, l1_file_raw_txt, l2_file_raw_txt, str_buf)
                    

    return True

def extract_article_from_xml(article, article2, l1_file_raw_txt, l2_file_raw_txt, str_buf):
    for line in article2.findall('div'):
        #str_buf = line.text
        str_buf = line.xpath("string()")
        l2_file_raw_txt.write(str_buf)
        l2_file_raw_txt.write('\n')

    for line in article.findall('div'):
        #str_buf = line.text
        str_buf = line.xpath("string()")
        l1_file_raw_txt.write(str_buf)
        l1_file_raw_txt.write('\n')
    l1_file_raw_txt.write('.EOA\n')
    l2_file_raw_txt.write('.EOA\n')

if __name__ == '__main__':
    pass
