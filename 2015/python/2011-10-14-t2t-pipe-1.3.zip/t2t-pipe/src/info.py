#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-

# info.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Programme Information File
"""

NAME = "Tree-to-Tree (t2t) Alignment Pipe"
SHORT_NAME = "t2t-pipe"
VERSION = (1, 3)
YEARS = "2010-2011"
AUTHOR = u"Markus Killer"
INSTITUTION = "University of Zurich"

def get_copyright():
    return "%s %s" % (YEARS, AUTHOR)

def get_full_copyright():
    return "© Copyright %s %s, %s" % (YEARS, AUTHOR, INSTITUTION)

def get_version_string():
    return "%s (Beta)" % (".".join(str(i) for i in VERSION))

def get_full_name():
    return "%s v%s" % (NAME, get_version_string())

def get_name():
    return NAME
