#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# prepare_corpus.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Prepare Corpus

Minor cleaning, checking and string replacement operations.

"""
import codecs
import config
import errors
import fileinput
import get_files
import inspect
import os
import re
import subprocess


def perl_re_sub(re_search_replace_pattern,
                abs_path_file,
                backup_file_ext=''):
    r'''Use Perl oneliner to replace pattern :py:attr:`re_search_replace_pattern` in a closed file 
(:py:attr:`abs_path_file`). Not the most elegant solution, but in some cases - mainly for minor
string substitutions -  it is a lot easier than having to go through a whole 
open-read-close-open-write-close-cycle.

.. note::

    Use ``r' '``-strings for regex pattern. 

    '''

    print("\n\n... doing in place perl re search & replace on file:\n" + abs_path_file)
    print("using the following pattern: " + re_search_replace_pattern)
    print("\n")

    replace = subprocess.Popen(["perl",
                                "-pi" + backup_file_ext,
                                "-e",
                                re_search_replace_pattern,
                                abs_path_file])
    replace.wait()
    return True

#perl_re_sub(r's/<pb facs=[^>]+>//g', r'/media/DATA/eclipse_ws/t2t_pipe/testset/tmp/SAC-Jahrbuch_1957_de_af7.combined.ocr-merged-logical-pagemap.xml', ".bak")
#perl_re_sub(r's/^\s+\n//', r'/media/DATA/eclipse_ws/t2t_pipe/testset/tmp/SAC-Jahrbuch_1957_de_af7.combined.ocr-merged-logical-pagemap.xml')

def check_and_clean_txt_files():
    in_f_ext = "_raw.txt"
    l1_files = get_files.get_files(config.INPUT_DIRECTORY, config.L1 + in_f_ext)
    l2_files = get_files.get_files(config.INPUT_DIRECTORY, config.L2 + in_f_ext)
    errors.check_parallel_input_files(l1_files, l2_files, config.INPUT_DIRECTORY, in_f_ext)

    if len(l1_files) > 1 and config.ONE_BIG_FILE is True:
        l1_file_name = config.CORPUS_ID + "_" + config.CORPUS_YEARS + config.PA + config.L1 + ".txt"
        l2_file_name = config.CORPUS_ID + "_" + config.CORPUS_YEARS + config.PA + config.L2 + ".txt"
        concat_and_clean_txt_files(l1_file_name, l2_file_name)
        check_article_boundaries(l1_file_name, l2_file_name)

        # Remove temporary raw.txt-files
        for raw_txt_l1, raw_txt_l2 in zip(l1_files, l2_files):
            os.remove(raw_txt_l1)
            os.remove(raw_txt_l2)
        print len(l1_files) + len(l2_files),
        print " temporary raw.txt-files (L1 & L2) removed from INPUT_DIRECTORY"

        return True

    else:
        for l1_file, l2_file in zip(l1_files, l2_files):
            check_article_boundaries(l1_file.split(os.sep)[-1], l2_file.split(os.sep)[-1])
        clean_txt_files(l1_files, l2_files)
        return True

def check_article_boundaries(l1_file_name, l2_file_name):
    l1_article_counter = 0
    l2_article_counter = 0
    with open(os.path.join(config.INPUT_DIRECTORY, l1_file_name), "r") as l1_file:
        for line in l1_file:
            if line.strip() == ".EOA":
                l1_article_counter += 1

    with open(os.path.join(config.INPUT_DIRECTORY, l2_file_name), "r") as l2_file:
        for line in l2_file:
            if line.strip() == ".EOA":
                l2_article_counter += 1

    if l1_article_counter == l2_article_counter and l1_article_counter >= 1:
        print "TXT-file check passed. There are ",
        print str(l1_article_counter), "parallel articles in the following files: "
        print l1_file_name
        print l2_file_name
        return True

    elif os.path.getsize(os.path.join(config.INPUT_DIRECTORY, l1_file_name)) > 0 \
      and os.path.getsize(os.path.join(config.INPUT_DIRECTORY, l2_file_name)) > 0:
        with codecs.open(os.path.join(config.INPUT_DIRECTORY, l1_file_name),
                         "a", "utf-8") as l1_file:
            with codecs.open(os.path.join(config.INPUT_DIRECTORY, l2_file_name),
                             "a", "utf-8") as l2_file:
                l1_file.seek(2)
                l1_file.write("\n")
                l1_file.write(".EOA")
                l2_file.seek(2)
                l2_file.write("\n")
                l2_file.write(".EOA")
                print "Fallback-TXT-file check passed. The following files ",
                print "are treated as 1 parallel article: "
                print l1_file_name
                print l2_file_name
    else:
        errors.err_log(errors.UNSPECIFIED_ERROR + str(inspect.getmodule(check_article_boundaries)))
        errors.err_log("\n\n")
        errors.err_log(str(inspect.getsource(check_article_boundaries)))


def clean_line_de(line):
    if line == u"":
        return line
    str_buffer = ''
    for word in line.split():
        for ch in word:
            if ch in config.CHARACTER_REPLACEMENT_DICTIONARY_DE:
                str_buffer += config.CHARACTER_REPLACEMENT_DICTIONARY_DE[ch]
            else:
                if ch not in config.CHARACTER_STOP_LIST:
                    str_buffer += ch
        str_buffer += " "
    if config.REMOVE_MID_SNT_NEWLINES:
        str_buffer += " "
    else:
        str_buffer += "\n"
    return str_buffer

def clean_line_en(line):
    if line == u"":
        return line
    str_buffer = ''
    for word in line.split():
        for ch in word:
            if ch in config.CHARACTER_REPLACEMENT_DICTIONARY_EN:
                str_buffer += config.CHARACTER_REPLACEMENT_DICTIONARY_EN[ch]
            else:
                if ch not in config.CHARACTER_STOP_LIST:
                    str_buffer += ch
        str_buffer += " "
    if config.REMOVE_MID_SNT_NEWLINES:
        str_buffer += " "
    else:
        str_buffer += "\n"
    return str_buffer

def clean_line_fr(line):
    if line == u"":
        return line
    str_buffer = ''
    for word in line.split():
        for ch in word:
            if ch in config.CHARACTER_REPLACEMENT_DICTIONARY_FR:
                str_buffer += config.CHARACTER_REPLACEMENT_DICTIONARY_FR[ch]
            else:
                if ch not in config.CHARACTER_STOP_LIST:
                    str_buffer += ch
        str_buffer += " "
    if config.REMOVE_MID_SNT_NEWLINES:
        str_buffer += " "
    else:
        str_buffer += "\n"
    return str_buffer


def clean_txt_files(l1_files, l2_files):
    
    for l1_file, l2_file in zip(l1_files, l2_files):
        in_l1 = codecs.open(l1_file, "r", "utf-8")
        in_l2 = codecs.open(l2_file, "r", "utf-8")
        if config.PA in l1_file:
            out_l1_file_name = l1_file.split(os.sep)[-1][:-8] + ".txt"
            out_l2_file_name = l2_file.split(os.sep)[-1][:-8] + ".txt"
        else:
            out_l1_file_name = l1_file.split(os.sep)[-1][:-11] + config.PA + config.L1 + ".txt"
            out_l2_file_name = l2_file.split(os.sep)[-1][:-11] + config.PA + config.L2 + ".txt"
        
        # Two separate runs through files are necessary, because at this stage, the files
        # do not have the same number of lines
        with codecs.open(os.path.join(config.INPUT_DIRECTORY, out_l1_file_name),
                         "w", "utf-8") as out_l1:
            for line in in_l1:
                # remove xml-markup (e.g. europarl txt-files)
                line = re.sub(r' *<[^>]+> *', r'', line)
                if line.startswith(u"\n"):
                    out_l1.write(u"\n")
                else:
                    
                    if config.L1 == "de":
                        out_l1.write(clean_line_de(line.strip()))
                    elif config.L1 == "en":
                        out_l1.write(clean_line_en(line.strip()))
                    elif config.L1 == "fr":
                        out_l1.write(clean_line_fr(line.strip()))
        in_l1.close()

        with codecs.open(os.path.join(config.INPUT_DIRECTORY, out_l2_file_name),
                         "w", "utf-8") as out_l2:
            for line in in_l2:
                # remove xml-markup (e.g. europarl txt-files)
                line = re.sub(r' *<[^>]+> *', r'', line)
                if line.startswith(u"\n"):
                    out_l2.write(u"\n")
                else:
                    
                    if config.L2 == "de":
                        out_l2.write(clean_line_de(line.strip()))
                    elif config.L2 == "en":
                        out_l2.write(clean_line_en(line.strip()))
                    elif config.L2 == "fr":
                        out_l2.write(clean_line_fr(line.strip()))
        in_l2.close()
        
        perl_re_sub(r"s/^\n$//", os.path.join(config.INPUT_DIRECTORY, out_l1_file_name))
        perl_re_sub(r"s/^\n$//", os.path.join(config.INPUT_DIRECTORY, out_l2_file_name))
        # Remove temporary raw.txt-files
        os.remove(l1_file)
        os.remove(l2_file)

    print len(l1_files), " temporary raw.txt-files (L1) removed from INPUT_DIRECTORY"
    print len(l2_files), " temporary raw.txt-files (L2) removed from INPUT_DIRECTORY"

    return True


def concat_and_clean_txt_files(l1_file_name, l2_file_name):
    in_f_ext = "_raw.txt"
    l1_files = get_files.get_files(config.INPUT_DIRECTORY, config.L1 + in_f_ext)
    l2_files = get_files.get_files(config.INPUT_DIRECTORY, config.L2 + in_f_ext)
    errors.check_parallel_input_files(l1_files, l2_files, config.INPUT_DIRECTORY, in_f_ext)

    with codecs.open(l1_file_name, "w", "utf-8") as out_l1:
        for f in l1_files:
            with codecs.open(f, "r", "utf-8") as in_l1:
                for line in in_l1:
                    # remove xml-markup (e.g. europarl txt-files)
                    line = re.sub(r' *<[^>]+> *', r'', line)
                    if line != "\n":
                        if config.L1 == "de":
                            out_l1.write(clean_line_de(line.strip()))
                        if config.L1 == "en":
                            out_l1.write(clean_line_en(line.strip()))
                        if config.L1 == "fr":
                            out_l1.write(clean_line_fr(line.strip()))

    with codecs.open(l2_file_name, "w", "utf-8") as out_l2:
        for f in l2_files:
            with codecs.open(f, "r", "utf-8") as in_l2:
                for line in in_l2:
                    line = re.sub(r' *<[^>]+> *', r'', line)
                    if line != "\n":
                        if config.L2 == "de":
                            out_l2.write(clean_line_de(line.strip()))
                        if config.L2 == "en":
                            out_l2.write(clean_line_en(line.strip()))
                        if config.L2 == "fr":
                            out_l2.write(clean_line_fr(line.strip()))
    return True

def concat_small_txt_files(l1_dir, l1_files, l2_files):
    ''' Combine corpus into files that are as big as specified in :const:`config.MAX_LINES_PER_FILE`
(a new output file will be produced as soon as the file breaching the limit
is processed - splits only possible at the beginning of a new input file)
        
.. todo:: refine this algorithm there seem to be huge differences in file sizes
    '''
    fi = fileinput.FileInput(l1_files)
    for line in fi:
        pass
    total_no_of_lines = fi.lineno()
    fi.close()
    split_before_file = []
    fi = fileinput.FileInput(l1_files)
    for line in fi:
        if fi.lineno() in range(config.MAX_LINES_PER_FILE, total_no_of_lines, config.MAX_LINES_PER_FILE):
            split_before_file.append(os.path.join(l1_dir, fi.filename()))
    fi.close()
    part = 1
    CORPUS_PREFIX = config.CORPUS_ID + "_" + config.CORPUS_YEARS
    L1_SUFFIX = config.L1 + "_raw.txt"
    L2_SUFFIX = config.L2 + "_raw.txt"
    l1_file_name = CORPUS_PREFIX + "_part_{0:04d}".format(part) + config.PA + L1_SUFFIX
    l2_file_name = CORPUS_PREFIX + "_part_{0:04d}".format(part) + config.PA + L2_SUFFIX
    l1_out = codecs.open(os.path.join(config.INPUT_DIRECTORY, l1_file_name), "w", "utf-8")
    l2_out = codecs.open(os.path.join(config.INPUT_DIRECTORY, l2_file_name), "w", "utf-8")
    print "concatenating small files ... split before ", config.MAX_LINES_PER_FILE, "lines"
    print l1_file_name, l2_file_name
    for l1_file, l2_file in zip(l1_files, l2_files):
        l1_in = codecs.open(l1_file, "r", "utf-8")
        l2_in = codecs.open(l2_file, "r", "utf-8")
        if l1_file in split_before_file:
            l1_out.close()
            l2_out.close()
            part += 1
            l1_file_name = CORPUS_PREFIX + "_part_{0:04d}".format(part) + config.PA + L1_SUFFIX
            l2_file_name = CORPUS_PREFIX + "_part_{0:04d}".format(part) + config.PA + L2_SUFFIX
            l1_out = codecs.open(os.path.join(config.INPUT_DIRECTORY, l1_file_name), "w", "utf-8")
            l2_out = codecs.open(os.path.join(config.INPUT_DIRECTORY, l2_file_name), "w", "utf-8")
            print l1_file_name, l2_file_name
        for line in l1_in:
            l1_out.write(line)
            l1_out.write("\n")
        for line in l2_in:
            l2_out.write(line)
            l2_out.write("\n")
        l1_out.write(".EOA\n")
        l1_in.close()
        l2_out.write(".EOA\n")
        l2_in.close()
    l1_out.close()
    l2_out.close()
    return True


if __name__ == '__main__':
    pass
