#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# autodoc.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Sphinx Autodoc generator (executable)

**Usage**

Adapt ``docs/source/conf.py`` to current environment and run e.g. ``./autodoc.py --output=PDF``
or ``./autodoc.py -h`` for a list of supported output formats and command line options.
"""

import codecs
import os
import subprocess
import sys
sys.path.append(os.path.abspath("../"))
import config

T2T_DOC_DIR = os.path.abspath('../../docs')

def create_docs(output_format):
    """Creates .rst-files for modules included in this python package and runs sphinx-build"""
    with codecs.open(os.path.join(T2T_DOC_DIR, "source", "index.rst"),
                     "w", "utf-8") as index_rst:

        INDEX_HEADER = u""".. Tree-to-tree (t2t) Alignment Pipe Dokumentation master file.

Tree-to-tree (t2t) Alignment Pipe Dokumentation
=============================================================

Die *Tree-to-Tree (t2t) Alignment Pipe* ist eine Sammlung von Python-Skripts, 
die über einen einfachen Programmaufruf (Spezifkationen in Konfigurationsdatei) automatisch 
alignierte Baumbanken aus parallelen Texten erzeugt. Zur Zeit werden die Sprachen Deutsch, 
Französisch und Englisch unterstützt. Die generierten Ausgabedateien (``TIGERxml`` und ``TMX``) 
können sowohl in den :program:`Stockholm TreeAligner` als auch in gängige Translation-Memory-Systeme 
importiert werden.

Introduced in Killer/Sennrich/Volk (2011)::
   
   @inproceedings{killer-sennrich-volk:2011,
       booktitle = {Multilingual Resources and Multilingual Applications.  
       		Proceedings of the Conference of the German Society for Computational 
       		Linguistics and Language Technology (GSCL 2011)},
           month = {September},
           title = {{F}rom {M}ultilingual {W}eb-{A}rchives to {P}arallel {T}reebanks in 
                    {F}ive {M}inutes},
          author = {Markus Killer, Rico Sennrich and Martin Volk},
            year = {2011},
    	   pages = {57--62},
        abstract = {The Tree-to-Tree (t2t) Alignment Pipe is a collection of Python scripts, 
        	generating automatically aligned parallel treebanks from multilingual web 
                resources or existing parallel corpora. The pipe contains wrappers for a 
                number of freely available NLP software programs. Once these third party 
                programs have been installed and the system and corpus specific details 
                have been updated, the pipe is designed to generate a parallel treebank 
                with a single program call from a unix command line. We discuss alignment 
                quality on a fully automatically processed parallel corpus.}
        			}


.. figure:: /images/coded-with-logo-129x66.png
   :height: 66px
   :width: 129px
   :align: center
   
   A big thank you goes to `Wingware Python IDE <http://www.wingware.com>`_ for a free open source development license of Wing IDE PRO v.4   
   

.. toctree::
   :maxdepth: 2

Ziele und Arbeitsschritte
=========================================

.. toctree::
   :maxdepth: 2

   steps/intro
   steps/step_1
   steps/step_2
   steps/step_3
   steps/step_4
   steps/step_5
   steps/step_6
   steps/step_7
   steps/outlook


Erfahrungsbericht und Mini-Evaluation
=========================================

.. toctree::
   :maxdepth: 2

   mini-eval/report_dict_cc
   mini-eval/eval_t2t_align


Module der t2t-pipe (Englisch)
===============================

.. toctree::
   :maxdepth: 2
   
"""
        os.chdir(config.T2T_SCRIPTDIR)
        t2t_pipe_files = os.listdir(os.path.join("."))
        t2t_pipe_resources_files = []
        t2t_pipe_brackparser_files = []
        for curr_file in os.listdir(os.path.join("resources")):
            t2t_pipe_resources_files.append(os.path.join("resources", curr_file))
        for curr_file in os.listdir(os.path.join("resources", "brackparser")):
            t2t_pipe_brackparser_files.append(os.path.join("resources", "brackparser", curr_file))
        project_files = t2t_pipe_files + t2t_pipe_resources_files + t2t_pipe_brackparser_files
        print project_files
        init_files = ["resources/__init__.py", "resources/brackparser/__init__.py"]
        index_rst.write(INDEX_HEADER)
        for curr_file in project_files:
            if curr_file.endswith(".py") and curr_file not in init_files:
                with codecs.open(curr_file, "r", "utf-8") as in_f:
                    lines = [line.strip() for line in in_f]
                    for line in lines:
                        if line.startswith(('"""..','r"""..')):
                            mod_title = line.split("::")[-1].strip()
                mod_name = curr_file[:-3]
                mod_name_title = mod_name.replace(r'/', r'.')
                index_rst.write("   " + os.path.join("modules", mod_name))
                index_rst.write("\n")
                with codecs.open(os.path.join(T2T_DOC_DIR, "source", "modules", mod_name + ".rst"),
                                 "w", "utf-8") as rst_file:

                    title_string = ":mod:`" + mod_name_title + "` -- " + mod_title.split(" - ")[-1]
                    
                    rst_file.write(title_string)
                    rst_file.write("\n")
                    rst_file.write(len(title_string) * "=")
                    rst_file.write("\n")
                    rst_file.write("\n")
                    rst_file.write(".. automodule:: " + mod_name_title)
                    rst_file.write("\n")
                    rst_file.write("    :members:")
                    rst_file.write("\n")
                    rst_file.write("    :undoc-members:")
                    rst_file.write("\n")
                    rst_file.write(".. autoclass:")
                    rst_file.write("\n")
                    rst_file.write("    :show-inheritance:")
                    rst_file.write("\n")
                    rst_file.write("    :members:")
                    rst_file.write("\n")
                    rst_file.write("    :undoc-members:")
                    rst_file.write("\n")

        index_rst.write('''

.. only:: html

   :ref:`Literaturverzeichnis`


   ''')
    
    if output_format in ["ALL", "HTML"]:
        build_sphinx = subprocess.Popen(["sphinx-build",
                                         r"-a",
                                         r"-b",
                                         r"html",
                                         r".",
                                         r"../html"],
                                         cwd=os.path.join(T2T_DOC_DIR, "source"))
        build_sphinx.wait()

#    if output_format in ["ALL", "EPUB"]:
    if output_format in ["EPUB"]:
        build_sphinx = subprocess.Popen(["sphinx-build",
                                         r"-a",
                                         r"-b",
                                         r"epub",
                                         r".",
                                         r"../epub"],
                                         cwd=os.path.join(T2T_DOC_DIR, "source"))
        build_sphinx.wait()

    if output_format in ["ALL", "PDF", "LATEX"]:
        build_sphinx = subprocess.Popen(["sphinx-build",
                                         r"-a",
                                         r"-b",
                                         r"latex",
                                         r".",
                                         r"../latex"],
                                         cwd=os.path.join(T2T_DOC_DIR, "source"))
        build_sphinx.wait()
        if output_format in ["ALL", "PDF"]:
            latex = subprocess.Popen(["latex",
                                      r"-interaction=nonstopmode",
                                      r"t2t-pipe-manual.tex"],
                                    cwd=os.path.join(T2T_DOC_DIR, "latex"))
            latex.wait()

            pdflatex = subprocess.Popen(["pdflatex",
                                      r"-interaction=nonstopmode",
                                      r"t2t-pipe-manual.tex"],
                                    cwd=os.path.join(T2T_DOC_DIR, "latex"))
            pdflatex.wait()

    

def main():
    """Checks command line arguments and creates automated documentation in the
    Output formats specified, using Sphinx v1.0 or greater.
    
    Supported output formats: HTML, PDF, EPUB, LATEX and ALL
    """
    from optparse import OptionParser

    usage = '''
    
    Adapt docs/source/conf.py to current environment and run 
    
    ./%prog [options]
    '''
    parser = OptionParser(usage, version='%prog v1.0 for Sphinx > 1.0')
    parser.add_option('-o', '--output', type="string", default='HTML',
                        help='Supported output formats: HTML, PDF, EPUB, LATEX or ALL [default=HTML]')
    (options, args) = parser.parse_args()
    if options.output in ["HTML", "PDF","EPUB", "LATEX", "ALL"]:
        create_docs(options.output)
    else:
        print '''autodoc.py: error: no such option:''', options.output
        print '''Type: autodoc.py -h for help'''
        sys.exit(-1)


if __name__ == '__main__':
    main()
