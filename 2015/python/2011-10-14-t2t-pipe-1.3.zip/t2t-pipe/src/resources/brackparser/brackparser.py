#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# resources.brackparser.brackparser.py
# Author: Torsten Marek (PCL3) - October 2009
# modified: Markus Killer (mki) <mki5600@gmail.com>
# July 2010
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Parse bracketed sentences (Penn)

Parsing bracketed PennTreebank format into Terminals and Nonterminals 
using :mod:`resources.brackparser.nodes`.

"""


def parse_node(text, node_factory):
    current_child = ""
    children = []
    label = True
    for char in text:
        if char in "( )":
            if current_child != "":
                if label:
#                    print current_child
                    children.append(current_child)
                    label = False
                else:
                    children.append(node_factory.make_terminal(current_child))
#                print current_child
                current_child = ""

            if char == "(":
                children.append(parse_node(text, node_factory))
            elif char == ")":
                return node_factory.make_nonterminal(children[0], children[1:])
        else:
            current_child += char

#    print children
    return children[0]

def parse(text, node_factory):
    assert text.startswith("(") and text.endswith(")")
    return parse_node(iter(text), node_factory)
