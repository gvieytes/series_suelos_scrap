#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# resources.brackparser.nodes.py
# Author: Torsten Marek (PCL3) - October 2009
# modified: Markus Killer (mki) <mki5600@gmail.com>
# July-September 2010
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Extract Terminals and Nonterminals (Penn)

Extract Terminals and Nonterminals from syntactically parsed sentences (PennTreebank format)

"""
ELEM_SPLIT = object()

class TreeElementsFactory(object):
    def __init__(self):
        self.t_count = 0
        self.nt_count = 499
    def make_terminal(self, surface):
        self.t_count += 1
        return Terminal(surface, self.t_count)

    def make_nonterminal(self, label, children):
        self.nt_count += 1
        return Nonterminal(label, children, self.nt_count)


class Terminal(object):
    def __init__(self, surface, t_count):
        self.surface = surface
        self.t_count = t_count

    def _featurize(self, s_id, elems):
#        s_t_id = "s" + str(s_id) + "_" + str(self.t_count)
        s_t_id = "s{0:05d}_{1:03d}".format(s_id, self.t_count)
        elems.append("terminal{0}{1}{0}{2}".format(ELEM_SPLIT, s_t_id,
                                                   self.surface.encode('utf-8')))
        return s_t_id

class Nonterminal(object):
    def __init__(self, nt_type, children, nt_count):
        self.nt_type = nt_type
        self.children = children
        self.nt_count = nt_count

    def _featurize(self, s_id, elems):
#        s_nt_id = "s" + str(s_id) + "_" + str(self.nt_count)
        s_nt_id = "s{0:05d}_{1:03d}".format(s_id, self.nt_count)
        elems.append("nonterminal{0}{1}{0}{2}".format(ELEM_SPLIT, s_nt_id, self.nt_type))
        for c in self.children:
            child_id = c._featurize(s_id, elems)
            if elems[-1].startswith("terminal"):
                word = elems[-1].split(str(ELEM_SPLIT))[-1]
                pos = elems[-2].split(str(ELEM_SPLIT))[-1]
                elems.append("word_pos{0}{1}{0}{2}{0}{3}{0}{4}".format(ELEM_SPLIT, word, pos,
                                                                       child_id, s_nt_id))
                elems.remove(elems[-3])
            else:
                elems.append("edge{0}{1}{0}{2}".format(ELEM_SPLIT, s_nt_id, child_id))
        return s_nt_id

    def to_feature_list(self, s_id, elems):
        self._featurize(s_id, elems)
        return elems
