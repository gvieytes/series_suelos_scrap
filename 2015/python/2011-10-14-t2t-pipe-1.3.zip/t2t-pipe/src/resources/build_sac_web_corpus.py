#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# resources.build_sac-web_corpus.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# February 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Build SAC-Web-Korpus (executable)

Extract relevant parallel articles from SAC Archive 
(http://www.sac-cas.ch/Zeitschrift-Die-Alpen.1504.0.html?&L=0)

- use :mod:`resources.download_files` to download the pdf-files
- convert pdf files to xml (:mod:`resources.convert_files`)

- For the SAC web archives the script works out-of-the-box if you use the following commands to convert the files to xml:

German: ``./convert_files.py -f ad -t <target-directory-for-xml-files> -p sac- -s -de pdf xml <source-directory-of-pdf-files>``

French: ``./convert_files.py -f af -t <target-directory-for-xml-files> -p sac- -s -fr pdf xml <source-directory-of-pdf-files>``

- extract articles:

**Usage**

``%prog [options] <sac-xml-directory>``

"""
from collections import defaultdict
from difflib import SequenceMatcher as SM
from lxml import etree as ET
import codecs
import os
import sys
import time



VERSION = "%prog v0.3 (c) September 2011 <mki5600@gmail.com>"

def log(s):
    sys.stderr.write(s + "\n")

def log_and_exit(s):
    sys.stderr.write(s + "\n")
    sys.exit(-1)

# function copied from src/get_files.py for stand-alone functionality
def get_files(directory, extension, return_absolute_path=True):
    directory = os.path.abspath(directory)
    all_files = os.listdir(directory)
    files = []

    for f in sorted(all_files):
        if f.endswith(extension):
            if return_absolute_path:
                files.append(os.path.join(directory, f))
            else:
                files.append(f)

    if len(files) > 0:
        return files
    else:
        log_and_exit("""
        
        ***ERROR: No input file(s) found***
        
        directory: {0}
        required file extension: {1}
        
        """.format(directory, extension))

def remove_duplicates(directory, list_of_files):
    prev_content = ""
    prev_file = None
    map_of_removed_files = defaultdict(str)
    identical_counter = 0
    for curr_file in list_of_files:
        fp = os.path.join(directory, curr_file)
        with open(fp,"r") as in_file:
            curr_content = [l for l in in_file]
            d = SM(None, curr_content, prev_content)
            r = d.ratio()
            print curr_file, "<->", prev_file, r
            if r > 0.99:
                print "identical to previous file, remove: ", curr_file
                os.remove(fp)
                if prev_file not in map_of_removed_files:
                    map_of_removed_files[curr_file] = prev_file
                    identical_counter = 0
                else:
                    identical_counter += 1
                    map_of_removed_files[curr_file] = map_of_removed_files[sorted(map_of_removed_files.iterkeys())[-identical_counter]]
                
            prev_content = curr_content
            prev_file = curr_file
            
    for k in sorted(map_of_removed_files.iterkeys()):
        print k, "->", map_of_removed_files[k]
#    return map_of_removed_files

    

def get_files_per_month(directory, extension, year, month):
    directory = os.path.abspath(directory)
    all_files = os.listdir(directory)
    files = []

    for f in sorted(all_files):
        if f.endswith(extension):
            if f.split("_")[1] == year and f.split("_")[2] == month:
                files.append(f)

    if len(files) > 0:
        return files
    else:
        log("""
        
        ***ERROR: No input file(s) found***
        
        directory: {0}
        required file extension: {1}
        year: {2}    month: {3}
        
        """.format(directory, extension, year, month))
        return []


def generate_sac_toc(xml_directory):
    l1_ext = "de.xml"
    l2_ext = "fr.xml"
    l1_files = get_files(xml_directory, l1_ext)
    l2_files = get_files(xml_directory, l2_ext)
    
    print "total number of files ending in {0}: {1}".format(l1_ext, len(l1_files))
    print "total number of files ending in {0}: {1}".format(l2_ext, len(l2_files))
    
    
    YEARS = range(2011, 2012)
    MONTHS = range(10, 11)
    
    toc_dir = os.path.join(xml_directory, "tocs")
    check_or_create_dir(toc_dir)

    for year in YEARS:
        for month in MONTHS:
            year = "{0:04d}".format(int(year))
            month = "{0:02d}".format(month)
            with codecs.open(os.path.join(toc_dir,
                                          "sac_parallel_toc_{0}_{1}.csv".format(year, month)),
                                          "w", "utf-8") as toc:
                
                TOC_FOOTER = "\n\ncreated: " + time.strftime("%d/%m/%Y %H:%M:%S") + "\n" + VERSION.replace("%prog", globals()["__file__"])
                
                l1_files = get_files_per_month(xml_directory, l1_ext, year, month)
                l2_files = get_files_per_month(xml_directory, l2_ext, year, month)

                remove_duplicates(xml_directory, l1_files)
                remove_duplicates(xml_directory, l2_files)
                        
                l1_files = get_files_per_month(xml_directory, l1_ext, year, month)
                l2_files = get_files_per_month(xml_directory, l2_ext, year, month)
                               
                l1_ids = [curr_file.split("-")[1][3:] for curr_file in l1_files]
                l2_ids = [curr_file.split("-")[1][3:] for curr_file in l2_files]

                same_ids = []
                rest_l1 = []
                rest_l2 = []
                if len(l1_files) >= len(l2_files):
                    for curr_file in l1_files:
                        if curr_file.split("-")[1][3:] in l2_ids:
                            same_ids.append(curr_file.split("-")[1][3:])
                elif len(l2_files) > len(l1_files):
                    for curr_file in l2_files:
                        if curr_file.split("-")[1][3:] in l1_ids:
                            same_ids.append(curr_file.split("-")[1][3:])
                
                for id in l1_ids:
                    if id not in same_ids:
                        rest_l1.append(id)
                        
                for id in l2_ids:
                    if id not in same_ids:
                        rest_l2.append(id)
            
                print "\n\nIssues Year: {0} Month: {1}\n".format(year, month)
                toc.write("\n\nIssues Year: {0} Month: {1}\n".format(year, month))
                print "same ids: ", same_ids
                for id in same_ids:
                    print id
                    l1_file = "sac-ad_{0}-de.xml".format(id)
                    l1_captions = extract_from_sac_web_xml(xml_directory, l1_file)
                    l2_file = "sac-af_{0}-fr.xml".format(id)
                    l2_captions = extract_from_sac_web_xml(xml_directory, l2_file)
                    toc.write(u"\n{0}**{1}".format(l1_file, l1_captions))
                    toc.write(u"\n{0}**{1}".format(l2_file, l2_captions))
                print "rest l1: ", rest_l1
                for id in rest_l1:
                    l1_file = "sac-ad_{0}-de.xml".format(id)
                    l1_captions = extract_from_sac_web_xml(xml_directory, l1_file)
                    toc.write(u"\n{0}**{1}".format(l1_file, l1_captions))
                print "rest l2: ", rest_l2
                for id in rest_l2:
                    l2_file = "sac-af_{0}-fr.xml".format(id)
                    l2_captions = extract_from_sac_web_xml(xml_directory, l2_file)
                    toc.write(u"\n{0}**{1}".format(l2_file, l2_captions))
                print TOC_FOOTER
                toc.write(TOC_FOOTER)

                    
                    
                    
        
def extract_from_sac_web_xml(xml_directory, xml_file):
    xml_path = os.path.join(xml_directory, xml_file)
    try:
        xml = ET.parse(xml_path)
    except ET.XMLSyntaxError:
        parser = ET.XMLParser(recover=True)
        xml = ET.parse(xml_path, parser)


    txt = codecs.open(os.path.join(xml_directory,
                                   "txt",
                                    xml_file[:-3] + "txt"),
                      "w", "utf-8")
    
    fontspecs_l1 = defaultdict(str)
    
    pages = xml.findall('page')
    print pages
    
    for p in pages:
        for fs in p.findall("fontspec"):
            fs_id = fs.attrib["id"]
            fs_size = fs.attrib["size"]
            fontspecs_l1[fs_id] = fs_size
    page_nos = []
    captions = []
    headings = []
    headings_backup = []
    font_sizes = sorted([int(s) for s in fontspecs_l1.itervalues()])
    headline_font_1 = font_sizes[-1]
    headline_font_2 = font_sizes[-2]

    print "\n\n*** File", xml_file
    print fontspecs_l1
    print "font sizes used: ", font_sizes
    prev_fs = None
    for t in xml.findall("page/text"):
        t_fs = t.attrib["font"]
        t_fs_size = fontspecs_l1[t_fs]
        t_offset_top = t.attrib["top"]
        if int(t_fs_size) == int(headline_font_1):
            heading = t.xpath("string()").strip()
            if heading != "":
                print "\n\n*** HEADING ***", heading, "*** HEADING ***\n\n"
                headings.append(heading)
        elif int(t_fs_size) == int(headline_font_2):
            heading = t.xpath("string()").strip()
            if heading != "":
                print "\n\n*** BACKUP HEADING ***", heading, "*** BACKUP HEADING ***\n\n"
                headings_backup.append(heading)
        if int(t_fs_size) >= 7 and 30 < int(t_offset_top) < 800 : 
            if t_fs != prev_fs and t.xpath("string()") not in ("", " "):
                print "\n\n***NEWLINE\n\n"
                print t_fs, t_fs_size, t.xpath("string()").strip(),
                txt.write("\n")
                txt.write(t.xpath("string()"))
            else:
                print t.xpath("string()").strip(),
                txt.write(t.xpath("string()"))
            prev_fs = t_fs
        else:
            if 1200 < int(t_offset_top) < 1220:
                try:
                    if int(t.xpath("string()")) and 1 < int(t.xpath("string()")) < 200:
                        page_nos.append(t.xpath("string()"))
                except:
                    captions.append((t_fs, t_offset_top, t.xpath("string()")))
    
    if len(headings) == 0:
        headings = headings_backup
             
        
    
    txt.write("\n\n")
    prev_fs_c = None
    for c in captions:
        if 30 < int(c[1]) < 800 and c[2] not in tuple("1234567890"):
            if c[0] != prev_fs_c:
                print c[2]
                txt.write("\n")
                txt.write(c[2])
            else:
                print c[2],
                txt.write(c[2])
            prev_fs_c = c[0]
    print fontspecs_l1
    txt.close()
    page_nos_filesize_headings = page_nos + ["**"] + [str(os.path.getsize(xml_path))] + ["**"] + headings
    return u" ".join([i for i in page_nos_filesize_headings])
            
        
    



def check_or_create_dir(directory):
    if os.path.isdir(directory):
        print "exists: ", directory
    else:
        os.mkdir(directory)
        print "created: ", directory

if __name__ == '__main__':
    
#    extract_from_sac_web_xml("/home/mki/corpora/sac_2001-2011/xml", "/home/mki/corpora/sac_2001-2011/xml/sac-ad_2011_01_18-de.xml")
#    extract_from_sac_web_xml("/home/mki/corpora/sac_2001-2011/xml", "/home/mki/corpora/sac_2001-2011/xml/sac-af_2011_01_18-fr.xml")
    #print len(sys.argv), sys.argv

    #if len(sys.argv) == 1:
        #sys.argv.insert(1, "-h")
    
    #from optparse import OptionParser

    #usage = "\n\n".join(__doc__.split("\n")[2:-2])
    #parser = OptionParser(usage, version=VERSION)

    #parser.add_option('-f', '--source_filter', type="string", default="",
                        #help='only process files starting with this prefix [default=no prefix/all files]')
    
    #parser.add_option('-t', '--target_dir', type="string", default=os.path.join(sys.argv[-1], "txt"),
                        #help='output directory for converted files [default=source_dir/target_ext]')
  
    #parser.add_option('-p', '--target_prefix', type="string", default="",
                        #help='prefix to original file name [default=no prefix]')

    #parser.add_option('-s', '--target_suffix', type="string", default="",
                        #help='suffix to original file name [default=no suffix]')

    #options, args = parser.parse_args()
    
    #if len(args) != 1:
        #log_and_exit(usage)
    
    #check_or_create_dir(options.target_dir)

    generate_sac_toc('/home/mki/workspace/t2t-pipe-dev/test/t2t-pipe-demo/xml')