#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# resources.combine_autodicts.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Combine Hunalign Autodict Files (executable)

**Usage**
        
``./combine_autodicts.py <path_to_primary_dict> <path_to_secondary_dict> <path_to_new_dict>``

"""

import codecs
import sys

def err_log_and_exit(s):
    sys.stderr.write(s)
    sys.exit(-1)

def combine_autodicts(primary, secondary, new):
    new_entries = []
    with codecs.open(primary, "r", "utf-8") as dict1:
        print "reading primary dict ..."
        lines_dict1 = [line.strip() for line in dict1]
        with codecs.open(secondary, "r", "utf-8") as dict2:
            print "comparing secondary to primary dict ..."
            for line in dict2:
                if line.strip() not in lines_dict1:
                    new_entries.append(line.strip())

    lines_new_dict = lines_dict1 + new_entries
    with codecs.open(new, "w", "utf-8") as new_dict:
        print "writing new dict ..."
        for line in sorted(set(lines_new_dict)):
            new_dict.write(line + "\n")
        print "new dict finished: ", new

def main():
    if len(sys.argv) != 4:
        err_log_and_exit('''
        Usage:
        
        combine_autodicts.py path_to_primary_dict path_to_secondary_dict path_to_new_dict
        ''')

    primary = sys.argv[1]
    secondary = sys.argv[2]
    new = sys.argv[3]
    combine_autodicts(primary, secondary, new)


if __name__ == '__main__':
    main()
