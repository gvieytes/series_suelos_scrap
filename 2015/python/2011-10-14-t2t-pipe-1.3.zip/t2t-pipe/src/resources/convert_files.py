#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# resources.convert_files.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# February 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Convert Files PDF->XML, etc. (executable)

Batch convert files from one format and/or encoding to another, using standard UNIX tools (xpdf)

Suggested naming conventions for the SAC web archives 
(if different naming conventions are used :mod:`resources.build_sac_web_corpus` might have to be manually adapted):

German: ``./convert_files.py -f ad -t <target-directory-for-xml-files> -p sac- -s -de pdf xml <source-directory-of-pdf-files>``
French: ``./convert_files.py -f af -t <target-directory-for-xml-files> -p sac- -s -fr pdf xml <source-directory-of-pdf-files>``

**Usage**

``%prog [options] <source file extension (pdf, txt)> <target file extension (xml, txt)> <source directory>``

The following conversions are implemented:

 - PDF->XML
 - PDF->TXT
 - TXT (encoding1) -> TXT (encoding2)

.. todo:: add more conversion options
"""
import os
import sys
import subprocess
import shutil

def log_and_exit(s):
    sys.stderr.write(s + "\n")
    sys.exit(-1)

# function copied and adapted from src/get_files.py for stand-alone functionality
def get_files(directory, identifier, source_filter, return_absolute_path=True):
    directory = os.path.abspath(directory)
    all_files = os.listdir(directory)
    files = []
    if source_filter == "":
        print "\n\nprocessing all {0}-files\n\n".format(identifier)
        for f in sorted(all_files):
            if f.endswith(identifier):
                if return_absolute_path:
                    files.append(os.path.join(directory, f))
                else:
                    files.append(f)
    else:
        print "\n\nprocessing {0}-files starting with {1}\n\n".format(identifier, source_filter)
        for f in sorted(all_files):
            if f.startswith(source_filter) and f.endswith(identifier):
                if return_absolute_path:
                    files.append(os.path.join(directory, f))
                else:
                    files.append(f)
    if len(files) > 0:
        return files
    else:
        log_and_exit("""
        
        ***ERROR: No input file(s) found***
        
        directory: {0}
        required file identifier: {1}
        
        """.format(directory, identifier))

def check_or_create_dir(directory):
    if os.path.isdir(directory):
        print "exists: ", directory
    else:
        os.mkdir(directory)
        print "created: ", directory

def pdftoxml(source_directory, source_filter, target_directory, target_prefix, target_suffix, target_encoding):
    pdf_files = get_files (source_directory, ".pdf", source_filter, return_absolute_path=False)
    for f in sorted(pdf_files):
        
        print "converting PDF->XML ... ", f
        
        pdftohtml = subprocess.Popen(["pdftohtml",
                                         r"-i",
                                         r"-xml",
                                         r"-enc",
                                         target_encoding.upper(),
                                         r"-nodrm",
                                         f],
                                         cwd=os.path.join(source_directory))
        pdftohtml.wait()
        
        xml_file_in_source_dir = os.path.join(source_directory, f[:-3]) + "xml"
        xml_file_in_target_dir = os.path.join(target_directory, target_prefix + f[:-4])+ target_suffix + ".xml"
        
        shutil.move(xml_file_in_source_dir, xml_file_in_target_dir)
        

def pdftotxt(source_directory, source_filter, target_directory, target_prefix, target_suffix, target_encoding):
    pdf_files = get_files (source_directory, ".pdf", source_filter, return_absolute_path=False)
    for f in sorted(pdf_files):
        
        print "converting PDF->TXT ... ", f
        
        pdftotxt = subprocess.Popen(["pdftotext",
                                         r"-eol",
                                         r"dos",
                                         r"-nopgbrk",
                                         f],
                                         cwd=os.path.join(source_directory))
        pdftotxt.wait()
        
        txt_file_in_source_dir = os.path.join(source_directory, f[:-3]) + "txt"
        txt_file_in_target_dir = os.path.join(target_directory, target_prefix + f[:-4])+ target_suffix + ".txt"
        
        if target_encoding == "utf-8":
            shutil.move(txt_file_in_source_dir, txt_file_in_target_dir)
        
        else:
            convert_encoding_in_file(txt_file_in_source_dir, txt_file_in_target_dir, "utf-8", target_encoding)


def convert_encoding_in_file(file_in_source_dir, file_in_target_dir, source_encoding, target_encoding):
    # adapted from John Machin (18/3/2010)
    # http://stackoverflow.com/questions/2404855/fastest-way-to-convert-file-from-latin1-to-utf-8-in-python
    print "\nconverting encoding from ", source_encoding, " to ", target_encoding
    infile = open(file_in_source_dir, 'rb')
    outfile = open(file_in_target_dir, 'wb')
    BLOCKSIZE = 65536 # experiment with size
    while True:
        block = infile.read(BLOCKSIZE)
        if not block: break
        outfile.write(block.decode(source_encoding).encode(target_encoding, "replace"))
    infile.close()
    print "\nsaving ", file_in_target_dir
    outfile.close()
    
    print "\nremoving ", file_in_source_dir
    print "\n\n"
    os.remove(file_in_source_dir)


def convert_encoding_in_dir(source_directory, source_filter, target_directory, target_prefix, target_suffix, source_encoding, target_encoding):
    txt_files = get_files (source_directory, ".pdf", source_filter, return_absolute_path=False)
    for f in sorted(txt_files):
        txt_file_in_source_dir = os.path.join(source_directory, f[:-3]) + "txt"
        txt_file_in_target_dir = os.path.join(target_directory, target_prefix + f[:-4])+ target_suffix + ".txt"
        
        if target_encoding == "utf-8" and source_encoding == "utf-8":
            shutil.move(txt_file_in_source_dir, txt_file_in_target_dir)
        
        else:
            convert_encoding_in_file(txt_file_in_source_dir, txt_file_in_target_dir, source_encoding, target_encoding)

if __name__ == '__main__':
    if len(sys.argv) == 1:
        sys.argv.insert(1,"-h")
    
    from optparse import OptionParser

    usage = "\n".join(__doc__.split("\n")[2:-2])
    parser = OptionParser(usage, version="%prog v0.1 (c) Feb 2011 <mki5600@gmail.com>")

    parser.add_option('-f', '--source_filter', type="string", default="",
                        help='only process files starting with this prefix [default=no prefix/all files]')
    
    parser.add_option('-t', '--target_dir', type="string", default=os.path.join(sys.argv[-1], sys.argv[-2]),
                        help='output directory for converted files [default=source_dir/target_ext]')
  
    parser.add_option('-p', '--target_prefix', type="string", default="",
                        help='prefix to original file name [default=no prefix]')

    parser.add_option('-s', '--target_suffix', type="string", default="",
                        help='suffix to original file name [default=no suffix]')

    parser.add_option('-n', '--source_encoding', type="string", default="utf-8",
                        help='encoding of source txt file [default="utf-8"]')
    
    parser.add_option('-e', '--target_encoding', type="string", default="utf-8",
                        help='encoding of target file [default="utf-8"]')

    options, args = parser.parse_args()
    
    if len(args) != 3:
        log_and_exit(usage)
    
    check_or_create_dir(options.target_dir)

    if args[0] == "pdf" and args[1] == "xml":
        pdftoxml(args[2], options.source_filter, options.target_dir, options.target_prefix, options.target_suffix, options.target_encoding)
    elif args[0] == "pdf" and args[1] == "txt":
        pdftotxt(args[2], options.source_filter, options.target_dir, options.target_prefix, options.target_suffix, options.target_encoding)
    elif args[0] == "txt" and args[1] == "txt":
        convert_encoding_in_dir(args[2], options.source_filter, options.target_dir, options.target_prefix, options.target_suffix, options.source_encoding, options.target_encoding)

    else:
        log_and_exit(usage)