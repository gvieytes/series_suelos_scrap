#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# resources.dictcc_extract.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Extract entries from dict.cc files (executable)

extracts only 1to1 word-translations

**Usage**
        
``./dictcc_extract.py <path_to_dict_cc_txt_file>``

"""

import codecs
import os
import re
import sys

L1 = "de"
L2 = "en"
DICT_DIRECTORY = '.'

def log(s):
    sys.stderr.write(s + "\n")

DICT_STOP_LIST = [  u'®', u'!', u'?', u';', u'...', u' se ', u" s'", u'sich ' u" d'", u'an etw.', u'an jdn.',
                    u'auf etw.', u'auf jdn./etw.', u'aus etw.', u'aus jdm.', 'etw. tun', u'etw. zu tun',
                    u'faire qc.', u'jdn.', u'jdm.', u'qn.', u'jdm./etw.', u'qn./qc.', u'etw.', u'qc.',
                    u'jd./etw.', u'jdm. etw.', u'jdm. etwas', u'jdn./etw.',  u'jd.', u'to ', u'sth.', 
                    u'jdn.', u' sb.', u'sth./sb.', u'sb./sth.', u'.']

def dictcc_extract_one2one_word_translations(in_f, hunalign_dict, lex_e2f, lex_f2e):
    one2one_word_translations = []

    for line in in_f:
        if line.startswith("#"):
            continue
        else:
            line = line.replace(u"\t", u" @ ")
            line = line.replace(u"ß", u"ss")
            line = line.replace(u"œ", u"oe")
            line = line.replace(u"Œ", u"OE")
            for i in DICT_STOP_LIST:
                line = line.replace(i, u"")
            line = line.replace(u"(m}", u"")
            line = re.sub(ur'''{[^}]+}''', ur"", line)
            line = re.sub(ur'''<[^>]+>''', ur"", line)
            line = re.sub(ur'''\[[^\]^@]+\]''', ur"", line)
            line = re.sub(ur'''\[[^\)]+\)''', ur"", line)
            line = re.sub(ur'''\([^\)]+\)''', ur"", line)
            line = re.sub(ur"\s+", ur" ", line)
            # apply rules for French post-tokenisation
            if L2 == "fr":
                line = re.sub(r"@ (.')(.+)\b", r'\1 \2', line)
                line = re.sub(r"@ ([Cc]') \b(est-à-dire)", r'\1\2', line)
                line = re.sub(r"@ ([dD]') \b(abord|ailleurs|après|autant)", r'\1\2', line)
                line = re.sub(r"@ (.') \b(.+)", r'@ \2', line)
            if line.endswith(r" @ "):
                line = line[:-3]
            print line
            try:
                if len(line.split(" @ ")[0].split()) == 1 and len(line.split(" @ ")[1].split()) == 1:
                    one2one_word_translations.append(line.strip())
                    one2one_word_translations.append(line.strip().lower())
                    one2one_word_translations.append(line.strip().title())
                    one2one_word_translations.append(line.strip().upper())
                    one2one_word_translations.append(u"{0} @ {1}".format(line.split(" @ ")[0].title(),
                                                                        line.split(" @ ")[1].lower()))
                    one2one_word_translations.append(u"{0} @ {1}".format(line.split(" @ ")[0].lower(),
                                                                        line.split(" @ ")[1].title()))
            except IndexError:
                continue
    hunalign_dict.write(u'''. @ .
, @ ,
: @ :
; @ ;
' @ "
' @ '
- @ -
! @ !
-LRB- @ -LRB-
-RRB- @ -RRB-
*LRB* @ (
*LRB* @ -LRB-
*RRB* @ )
*RRB* @ -RRB-
-LRB- @ (
-LRB- @ *LRB*
-RRB- @ )
-RRB- @ *RRB*
$ @ $
£ @ £
% @ %
''')
    for entry in sorted(set(one2one_word_translations)):
        print entry
        hunalign_dict.write(entry.split(" @ ")[1].strip() + " @ " + entry.split(" @ ")[0].strip() +"\n")
        lex_e2f.write(entry.split(" @ ")[1].strip() + " " + entry.split(" @ ")[0].strip() + " " + "1.0" + "\n")
        lex_f2e.write(entry.split(" @ ")[0].strip() + " " + entry.split(" @ ")[1].strip() + " " + "1.0" + "\n")

    for i in range(1, 20001):
        hunalign_dict.write(str(i) + " @ " + str(i) + "\n")
        lex_e2f.write(str(i) + " " + str(i) + " " + "1.0" + "\n")
        lex_f2e.write(str(i) + " " + str(i) + " " + "1.0" + "\n")

    for i in range(1, 101):
        hunalign_dict.write(str(i) + " @ " + str(i) + ".\n")
        lex_e2f.write(str(i) + " " + str(i) + ". " + "1.0" + "\n")
        lex_f2e.write(str(i) + " " + str(i) + ". " + "1.0" + "\n")


def get_dictionary():
    dict_cc_file = os.path.join(DICT_DIRECTORY, L1 + "-" + L2 + "_dict_cc.txt")
    hun_dict_file = os.path.join(DICT_DIRECTORY, L1 + "-" + L2 + "_dict_cc.dic")
    moses_prob_file_e2f = os.path.join(DICT_DIRECTORY, "dict_cc_lex.e2f")
    moses_prob_file_f2e = os.path.join(DICT_DIRECTORY, "dict_cc_lex.f2e")
    with codecs.open(dict_cc_file, 'r', 'utf-8') as in_f:
        with codecs.open(hun_dict_file, 'w', 'utf-8') as hunalign_dict:
            with codecs.open(moses_prob_file_e2f, 'w', 'utf-8') as lex_e2f:
                with codecs.open(moses_prob_file_f2e, 'w', 'utf-8') as lex_f2e:
                    dictcc_extract_one2one_word_translations(in_f, hunalign_dict, lex_e2f, lex_f2e)


def main():
    if len(sys.argv) != 2:
        log('''
        Usage:
        
        dictcc_extract.py <path_to_dict_cc_txt_file>
        ''')
        sys.exit(-1)
    with codecs.open(sys.argv[1], 'r', 'utf-8') as in_f:
        with codecs.open(sys.argv[1][:-3] + 'dic', 'w', 'utf-8') as hunalign_dict:
            with codecs.open(sys.argv[1][:-4] + '_lex.e2f', 'w', 'utf-8') as lex_e2f:
                with codecs.open(sys.argv[1][:-4] + '_lex.f2e', 'w', 'utf-8') as lex_f2e:
                    dictcc_extract_one2one_word_translations(in_f, hunalign_dict, lex_e2f, lex_f2e)




if __name__ == "__main__" :
    main()
