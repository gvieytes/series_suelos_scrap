#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# resources.download_files.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# February 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Download Files from Web-Server (executable)

Download multiple files from web-servers (e.g. to build your own corpus)

There are handlers for the following sites:

 - SAC    Archiv SAC-Zeitschrift 'Die Alpen/Les Alpes' (2001-)

**Usage**
        
``./download_files.py <site> <download_directory>``

.. todo:: add more archive sites

"""
import urllib2
import os
import sys
import time

USAGE = '''

Download multiple files from web-servers (e.g. to build your own corpus)

There are handlers for the following sites:

 - SAC    Archiv SAC-Zeitschrift 'Die Alpen/Les Alpes' (2001-)

**Usage**
        
``./download_files.py <site> <download_directory>``
        '''

def log_and_exit(s):
    sys.stderr.write(s + "\n")
    sys.exit(-1)

def download_sac(download_dir):
    LANGUAGES = ["de", "fr"]
    YEARS = range(2011,2012)
    MONTHS = range(10,11)
#    LANGUAGES = ["fr"]
#    YEARS = range(2002,2011)
#    MONTHS = range(7,11)
    ARTICLES = range(2,3)
    
    for LANGUAGE in LANGUAGES:
        for YEAR in YEARS:
            for MONTH in MONTHS:
                for ART in ARTICLES:
                    status, file_name, url = download_file("http://alpen.sac-cas.ch/{language}/archiv/{year}/{year}{month:02d}/a{lang}_{year}_{month:02d}_{art:02d}.pdf".format(language=LANGUAGE, year=YEAR, month=MONTH, lang=LANGUAGE[0], art=ART),
                                                           download_dir)
                    if status == "file download completed":
                        print status, file_name
                    elif status == "failed":
                        print status, url
                # continuous requests for files might cause the server to lock the connection
                # in this case, a 10 second pause after each volume did the trick (could probably
                # be reduced ...)
                time.sleep(3)
                        
def download_file(url, download_dir):
    """ (c) 2008 PabloG 
        http://stackoverflow.com/questions/22676/how-do-i-download-a-file-over-http-using-python
        modified 2011-02-19: - exception handling <mki5600@gmail.com>
    """
    file_name = url.split('/')[-1]
    try:
        u = urllib2.urlopen(url)
    except urllib2.HTTPError:
        status = "failed"
        return status, file_name, url
    except urllib2.URLError:
        status = "failed"
        return status, file_name, url
    
    f = open(os.path.join(download_dir, file_name), 'wb')
    meta = u.info()
    file_size = int(meta.getheaders("Content-Length")[0])
    print "Downloading: %s Bytes: %s" % (file_name, file_size)

    file_size_dl = 0
    block_sz = 8192
    while True:
        buffer = u.read(block_sz)
        if not buffer:
            break

        file_size_dl += block_sz
        f.write(buffer)
        status = r"%10d  [%3.2f%%]" % (file_size_dl, file_size_dl * 100. / file_size)
        status = status + chr(8)*(len(status)+1)
        print status,

    f.close()
    status = "file download completed"
    return status, file_name, url

def check_or_create_dir(directory):
    if os.path.isdir(directory):
        print "exists: ", directory
    else:
        os.mkdir(directory)
        print "created: ", directory

if __name__ == '__main__':
    if len(sys.argv) != 3:
        log_and_exit(USAGE)

    if sys.argv[1] == "SAC":
        check_or_create_dir(sys.argv[2])
        download_sac(sys.argv[2])
    else:
        log_and_exit(USAGE)
