#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# resources.tagsets.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - POS-Tagset Dictionaries

POS-Tagset specifications used for the generation of TigerXML files.

"""

TAGSETS = {
    "berkeley_de"          :'STTS',
    "berkeley_fr"          :'FTB',
    "berkeley_en"          :'PTB',
    "stanford_old_de"      :'STTS',
    "stanford_de"          :'STTS',
    "stanford_en"          :'PTB',
    "stanford_fr"          :'FTB-STAN'
    }

#: Tag Set Specifications can be found here:
#: `STTS Tag Set <http://www.ids-mannheim.de/cosmas2/projekt/referenz/stts/morph.v2.html>`_
STTS = {        '$(' : 'sonstige Satzzeichen; satzintern' ,
                '$,' : 'Komma' ,
                '$.' : 'Satzbeendende Interpunktion' ,
                'None' : 'nicht zugeordnet' ,
                'ADJA' : 'attributives Adjektiv' ,
                'ADJD' : u'adverbiales oder prädikatives Adjektiv' ,
                'ADV' : 'Adverb' ,
                'APPO' : 'Postposition' ,
                'APPR' : u'Präposition; Zirkumposition links' ,
                'APPRART' : u'Präposition mit Artikel' ,
                'APZR' : 'Zirkumposition rechts' ,
                'ART' : 'bestimmter oder unbestimmter Artikel' ,
                'CARD' : 'Kardinalzahl (Ordinalzahlen sind als ADJA getaggt)' ,
                'FM' : 'Fremdsprachliches Material' ,
                'ITJ' : 'Interjektion' ,
                'KOKOM' : 'Vergleichskonjunktion' ,
                'KON' : 'nebenordnende Konjunktion' ,
                'KOUI' : 'unterordnende Konjunktion mit "zu" und Infinitiv' ,
                'KOUS' : 'unterordnende Konjunktion mit Satz' ,
                'NE' : 'Eigennamen' ,
                'NN' : 'normales Nomen' ,
                'PAV' : 'Pronominaladverb' ,
                'PDAT' : 'attribuierendes Demonstrativpronomen' ,
                'PDS' : 'substituierendes Demonstrativpronomen' ,
                'PIAT' : 'attribuierendes Indefinitpronomen ohne Determiner' ,
                'PIDAT' : 'attribuierendes Indefinitpronomen mit Determiner' ,
                'PIS' : 'substituierendes Indefinitpronomen' ,
                'PPER' : 'irreflexives Personalpronomen' ,
                'PPOSAT' : 'attribuierendes Possessivpronomen' ,
                'PPOSS' : 'substituierendes Possessivpronomen' ,
                'PRELAT' : 'attribuierendes Relativpronomen' ,
                'PRELS' : 'substituierendes Relativpronomen' ,
                'PRF' : 'reflexives Personalpronomen' ,
                'PTKA' : 'Partikel bei Adjektiv oder Adverb' ,
                'PTKANT' : 'Antwortpartikel' ,
                'PTKNEG' : 'Negationspartikel' ,
                'PTKVZ' : 'abgetrennter Verbzusatz' ,
                'PTKZU' : '"zu" vor Infinitiv' ,
                'PWAT' : 'attribuierendes Interrogativpronomen' ,
                'PWAV' : 'adverbiales Interrogativ oder Relativpronomen' ,
                'PWS' : 'substituierendes Interrogativpronomen' ,
                'TRUNC' : 'Kompositions-Erstglied' ,
                'VAFIN' : 'finites Verb, aux' ,
                'VAIMP' : 'Imperativ, aux' ,
                'VAINF' : 'Infinitiv, aux' ,
                'VAPP' : 'Partizip Perfekt, aux' ,
                'VMFIN' : 'finites Verb, modal' ,
                'VMINF' : 'Infinitiv, modal' ,
                'VMPP' : 'Partizip Perfekt, modal' ,
                'VVFIN' : 'finites Verb, voll' ,
                'VVIMP' : 'Imperativ, voll' ,
                'VVINF' : 'Infinitiv, voll' ,
                'VVIZU' : 'Infinitiv mit "zu", voll' ,
                'VVPP' : 'Partizip Perfekt, voll' ,
                'XY' : 'Nichtwort, Sonderzeichen enthaltend'
                }
# Abeillé (FTB Specs)
#We distinguish 15 lexical categories, used for simple words as well as for
#compounds:
  #- A (adjective)
  #- Adv (adverb)
  #- CC (coordinating conjunction)
  #- Cl (weak clitic pronoun)
  #- CS (subordinating conjunction)
  #- D (determiner)
  #- ET (foreign word)
  #- I (interjection)
  #- NC (common noun)
  #- NP (proper noun)
  #- P (preposition)
  #- PREF (prefix)
  #- PRO (strong pronoun)
  #- V (verb)
  #- PONCT (punctuation mark)

#-----------------
#Constituent annotation 
#_________________

#We have chosen surface and shallow annotations, compatible with
#various syntactic frameworks.

#Our phrasal tagset is as follows:
  #- AP (adjectival phrases)
  #- AdP (adverbial phrases)
  #- COORD (coordinated phrases)
  #- NP (noun phrases)
  #- PP (prepositional phrases)
  #- VN (verbal nucleus)
  #- VPinf (infinitive clauses)
  #- VPpart (nonfinite clauses)
  #- SENT (sentences)
  #- Sint, Srel, Ssub (finite clauses)


#: Tag Set Specifications can be found here:
#: `FTB Tag Set <http://www.llf.cnrs.fr/Gens/Abeille/French-Treebank-fr.php>`_
#: `Stanford Implementation of FTB <http://nlp.stanford.edu/pubs/green+demarneffe+bauer+manning.emnlp11.pdf>`_
FTB_STAN = {    'A'     : 'Adjectif' ,
                'ADV'   : 'Adverbe' ,
                'C'     : 'Conjonction' ,
                'I'     : 'Interjection' ,
                'D'     : u'Déterminant' ,
                'N'     : 'Nom' ,
                'P'     : u'Préposition' ,
                'PRO'   : 'Pronom' ,
                'PUNC' : 'Ponctuation' ,
                'V'     : 'Verbe' ,
                'CL'    : 'Clitique' ,
                'ET'    : u'Mot étranger'
                }


if __name__ == '__main__':
    pass
