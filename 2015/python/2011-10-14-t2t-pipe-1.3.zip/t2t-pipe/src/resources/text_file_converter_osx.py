#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# resources.text_file_converter_osx.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# July 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Convert Documents to TXT  (executable - OSX Version)

Batch convert files from one format to plain TXT, 
using standard OSX (textutil) and UNIX tools (poppler)

tested with 
- textutil OS X 10.6.8
- pdftotext poppler 0.16.6

known issues:
- pdftotext xpdf 3.02 Patch 5 - loss of word boundaries for some mac generated pdf files


**Usage**

``%prog [options] <source directory>``

Output will be saved in cwd/converted_files

"""
import codecs
import os
import sys
import subprocess
import time

def log_and_exit(s):
    sys.stderr.write(s + "\n")
    sys.exit(-1)

def check_or_create_dir(directory):
    if os.path.isdir(directory):
        print "exists: ", os.path.abspath(directory)
    else:
        os.mkdir(directory)
        print "created: ", os.path.abspath(directory)

def convert_files(top, target_prefix, target_encoding):
    from collections import defaultdict
    counters = defaultdict(int)
    ext_not_supported = list()
    errors = list()
    os.chdir(top)
    os.chdir("..")
    check_or_create_dir("converted_files")
    for root, dirs, files in os.walk(top, topdown=True):    
        # counter will be reset to 0 for every directory in 'top'
        for dir in dirs:
            counters[dir] = 0
        for name in files:       
            ext = name.split(".")[-1].lower()    
            if ext == "pdf":
                pdftotxt(root, name, ext, counters, target_prefix, target_encoding)
            elif ext in ("txt", "html", "htm", "rtf", "rtfd", "doc", "docx", "wordml", "odt", "webarchive"):
                textutil(root, name, ext, counters, target_prefix, target_encoding)
            else:
                if name.startswith("."):
                    continue
                else:
                    print ext, "not supported: ", name
                    ext_not_supported.append(os.path.join(root.split(os.sep)[-1],name))
    
    if len(ext_not_supported) > 0:
        print "\n\nThe following files could not be converted:\n"
        for f in ext_not_supported:
            print f

def textutil(root, name, ext, counters, target_prefix, target_encoding):
    
    f = os.path.join(root.split(os.sep)[-1], name)
        
    print u"converting {0}->TXT ... {1}".format(ext.upper(), f.decode("utf-8"))
    
    textutil = subprocess.Popen(["textutil",
                                     "-convert",
                                     "txt",
                                     os.path.join(root, name)],
                                     cwd=os.getcwd(),
                                     stderr = subprocess.PIPE,
                                     stdout = subprocess.PIPE)
    textutil.wait()
    
    out, err = textutil.communicate()
    
    print err
    
    if "Error" in err:
        textutil_force_doc(root, name, ext, counters, target_prefix, target_encoding)
        
   
    stamp_rename_encode(root, name, ext, counters, "utf-8", target_prefix, target_encoding)    

def textutil_force_doc(root, name, ext, counters, target_prefix, target_encoding):
    
    f = os.path.join(root.split(os.sep)[-1], name)
        
    print u"FALLBACK converting {0} (DOC)->TXT ... {1}".format(ext.upper(), f.decode("utf-8"))
    
    textutil_doc = subprocess.Popen(["textutil",
                                     "-convert",
                                     "txt",
                                     "-format",
                                     "doc",
                                     os.path.join(root, name)],
                                     cwd=os.getcwd(),
                                     stderr = subprocess.PIPE,
                                     stdout = subprocess.PIPE)
    textutil_doc.wait()

    out, err = textutil_doc.communicate()
    
    print err
    
    if "Error" in err:
        textutil_force_docx(root, name, ext, counters, target_prefix, target_encoding)

def textutil_force_docx(root, name, ext, counters, target_prefix, target_encoding):
    
    f = os.path.join(root.split(os.sep)[-1], name)
        
    print u"FALLBACK converting {0} (DOCX)->TXT ... {1}".format(ext.upper(), f.decode("utf-8"))
    
    textutil_docx = subprocess.Popen(["textutil",
                                     "-convert",
                                     "txt",
                                     "-format",
                                     "docx",
                                     os.path.join(root, name)],
                                     cwd=os.getcwd(),
                                     stderr = subprocess.PIPE,
                                     stdout = subprocess.PIPE)
    textutil_docx.wait()

    out, err = textutil_docx.communicate()
    
    print err

def pdftotxt(root, name, ext, counters, target_prefix, target_encoding):
        
    f = os.path.join(root.split(os.sep)[-1], name)
        
    print u"converting {0}->TXT ... {1}".format(ext.upper(), f.decode("utf-8"))
     
    pdftotxt = subprocess.Popen(["pdftotext",
                                     r"-eol",
                                     r"dos",
                                     r"-nopgbrk",
                                     os.path.join(root, name)],
                                     cwd=os.getcwd())
    pdftotxt.wait()
   
    stamp_rename_encode(root, name, ext, counters, "utf-8", target_prefix, target_encoding)
    
def stamp_rename_encode(root, name, ext, counters, source_encoding, target_prefix, target_encoding):
    folder = root.split(os.sep)[-1]
    counters[folder] += 1
    stamp = u'''{0} converted {1}-file {2}\n\n'''.format(os.path.join(root.split(os.sep)[-1], name).decode("utf-8"), 
                                                         ext.upper(),
                                                         time.strftime("%d/%m/%y %H:%M:%S") )
    new_name = '''{0}_{1}_{2:04d}.txt'''.format(target_prefix, folder, counters[folder])
    
    converter_output = ".".join(name.split(".")[:-1]) + ".txt"
    
    with codecs.open(os.path.join(root, converter_output), "r", source_encoding) as in_file:
        with codecs.open(os.path.join("converted_files", new_name), "w", target_encoding) as out_file:
            
            out_file.write(stamp)
            for line in in_file:
                out_file.write(line.strip())
                out_file.write("\n")

    if ext != "txt":
        os.remove(os.path.join(root, converter_output))

if __name__ == '__main__':
    if len(sys.argv) == 1:
        sys.argv.insert(1,"-h")
    
    from optparse import OptionParser

    usage = "\n".join(__doc__.split("\n")[2:-2])
    parser = OptionParser(usage, version="%prog v0.2 (c) July 2011 <mki5600@gmail.com>")
 
    parser.add_option('-p', '--target_prefix', type="string", default="CONVERTED",
                        help='prefix to file name consisting of folder name plus numbered sequence separated by underscore [default=CONVERTED]')
  
    parser.add_option('-t', '--target_encoding', type="string", default="utf-8",
                        help='encoding of target file [default="utf-8"]')

    options, args = parser.parse_args()
    
    if len(args) != 1:
        log_and_exit(usage)
    
    convert_files(args[0], options.target_prefix, options.target_encoding)
