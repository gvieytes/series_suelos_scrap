#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# run_parser.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Statistical Phrase Structure Parsing
"""
import config
import errors
import os
import prepare_corpus
import get_files
import subprocess
import sys
import time


def get_parse_trees(parser):
    """Choose and run parser specified in :mod:`config`

    """
    if parser == "stanford_de":
        if run_stanford_de() is True:
            return True
    elif parser == "stanford_old_de":
        if run_stanford_old_de() is True:
            return True
    elif parser == "stanford_en":
        if run_stanford_en() is True:
            return True
    elif parser == "stanford_fr":
        if run_stanford_fr() is True:
            return True
    elif parser == "berkeley_de":
        if run_berkeley_de() is True:
            return True
    elif parser == "berkeley_fr":
        if run_berkeley_fr() is True:
            return True
    elif parser == "berkeley_en":
        if run_berkeley_en() is True:
            return True

    else:
        errors.err_log_and_exit(errors.PARSER_NOT_IMPLEMENTED)


def run_stanford_old_de():
    """Run Python Wrapper for the :program:`Stanford Parser` for each German language file in 
:const:`config.TMP_DIRECTORY`.

    """
    files = get_files.get_aligned_files(config.TMP_DIRECTORY, "de")
    for defile in sorted(files):
        prepare_corpus.perl_re_sub(r"s/«/'/g", defile)
        prepare_corpus.perl_re_sub(r"s/»/'/g", defile)
        print "\n", config.timestamp(),
        print "stanford parser started parsing file:\t", defile.split(os.sep)[-1], "\n\n"
        parse_de = parse_file_stanford_old_de(defile)
        parse_de.wait()
        # time.sleep(1)
        os.rename(defile + ".parser_out.de", defile[:-10] + 'parser_out.de')

        print "\n\n", config.timestamp(),
        print "stanford parser finished parsing file:\t", defile.split(os.sep)[-1], "\n\n"

    return True

def run_stanford_de():
    """Run Python Wrapper for the :program:`Stanford Parser` for each German language file in 
:const:`config.TMP_DIRECTORY`.

    """
    files = get_files.get_aligned_files(config.TMP_DIRECTORY, "de")
    for stanford_de_input in sorted(files):
        prepare_corpus.perl_re_sub(r"s/\(/-LRB-/g", stanford_de_input)
        prepare_corpus.perl_re_sub(r"s/\)/-RRB-/g", stanford_de_input)
        prepare_corpus.perl_re_sub(r"s/«/'/g", stanford_de_input)
        prepare_corpus.perl_re_sub(r"s/»/'/g", stanford_de_input)
        print "\n", config.timestamp(),
        print "stanford parser started parsing file:\t", stanford_de_input.split(os.sep)[-1], "\n\n"
        parse_de = parse_file_stanford_de(stanford_de_input)
        parse_de.wait()
        # time.sleep(1)
        os.rename(stanford_de_input + ".parser_out.de", stanford_de_input[:-10] + 'parser_out.de')

        print "\n\n", config.timestamp(),
        print "stanford parser finished parsing file:\t", stanford_de_input.split(os.sep)[-1], "\n\n"

    return True

def run_stanford_fr():
    """Run Python Wrapper for the :program:`Stanford Parser` for each German language file in 
:const:`config.TMP_DIRECTORY`.

    """
    files = get_files.get_aligned_files(config.TMP_DIRECTORY, "fr")
    for stanford_fr_input in sorted(files):
        prepare_corpus.perl_re_sub(r"s/\(/-LRB-/g", stanford_fr_input)
        prepare_corpus.perl_re_sub(r"s/\)/-RRB-/g", stanford_fr_input)
        prepare_corpus.perl_re_sub(r"s/«/'/g", stanford_fr_input)
        prepare_corpus.perl_re_sub(r"s/»/'/g", stanford_fr_input)
        print "\n", config.timestamp(),
        print "stanford parser started parsing file:\t", stanford_fr_input.split(os.sep)[-1], "\n\n"
        parse_de = parse_file_stanford_fr(stanford_fr_input)
        parse_de.wait()
        # time.sleep(1)
        os.rename(stanford_fr_input + ".parser_out.fr", stanford_fr_input[:-10] + 'parser_out.fr')

        print "\n\n", config.timestamp(),
        print "stanford parser finished parsing file:\t", stanford_fr_input.split(os.sep)[-1], "\n\n"

    return True


def run_stanford_en():
    """Run Python Wrapper for the :program:`Stanford Parser` for each English language file in 
:const:`config.TMP_DIRECTORY`.

    """
    files = get_files.get_aligned_files(config.TMP_DIRECTORY, "en")
    for enfile in sorted(files):
        print "\n", config.timestamp(),
        print "stanford parser started parsing file:\t", enfile.split(os.sep)[-1], "\n\n"
        parse_en = parse_file_stanford_en(enfile)
        parse_en.wait()
        print "\n\n"
        for line in parse_en.stdout:
            print line,
        print "\n\n", config.timestamp(),
        print "stanford parser finished parsing file:\t", enfile.split(os.sep)[-1], "\n\n"

    return True

def run_berkeley_de():
    """Run Python Wrapper for the :program:`Berkeley Parser` for each German language file in 
:const:`config.TMP_DIRECTORY`.

    """
    files = get_files.get_aligned_files(config.TMP_DIRECTORY, "de")
    for berkeley_de_input in sorted(files):
        prepare_corpus.perl_re_sub(r"s/\(/-LRB-/g", berkeley_de_input)
        prepare_corpus.perl_re_sub(r"s/\)/-RRB-/g", berkeley_de_input)
        prepare_corpus.perl_re_sub(r's/«/"/g', berkeley_de_input)
        prepare_corpus.perl_re_sub(r's/»/"/g', berkeley_de_input)
        berkeley_de_output = berkeley_de_input[:-10] + "parser_out.de"
        print "\n", config.timestamp(),
        print "berkeley parser started parsing file:\t", berkeley_de_input.split(os.sep)[-1], "\n\n"
        parse_de = parse_file_berkeley_de(berkeley_de_input, berkeley_de_output)
        print "parsing ",

        while parse_de.poll() is None:
            print "*",
            time.sleep(1.0)
            sys.stdout.flush()

        print "\n\n", config.timestamp(),
        print "berkeley parser finished parsing file:\t", berkeley_de_input.split(os.sep)[-1], "\n\n"
        prepare_corpus.perl_re_sub("s/^\(\s//", berkeley_de_output)
        prepare_corpus.perl_re_sub("s/\s\)$//", berkeley_de_output)

    return True

def run_berkeley_en():
    """Run Python Wrapper for the :program:`Berkeley Parser` for each English language file in 
:const:`config.TMP_DIRECTORY`.

    """
    files = get_files.get_aligned_files(config.TMP_DIRECTORY, "en")
    for berkeley_en_input in sorted(files):
        prepare_corpus.perl_re_sub(r"s/\(/-LRB-/g", berkeley_en_input)
        prepare_corpus.perl_re_sub(r"s/\)/-RRB-/g", berkeley_en_input)
        prepare_corpus.perl_re_sub(r's/«/"/g', berkeley_en_input)
        prepare_corpus.perl_re_sub(r's/»/"/g', berkeley_en_input)
        berkeley_en_output = berkeley_en_input[:-10] + "parser_out.en"
        print "\n", config.timestamp(),
        print "berkeley parser started parsing file:\t", berkeley_en_input.split(os.sep)[-1], "\n\n"
        parse_en = parse_file_berkeley_en(berkeley_en_input, berkeley_en_output)
        print "parsing ",

        while parse_en.poll() is None:
            print "*",
            time.sleep(1.0)
            sys.stdout.flush()

        print "\n\n", config.timestamp(),
        print "berkeley parser finished parsing file:\t", berkeley_en_input.split(os.sep)[-1], "\n\n"
        prepare_corpus.perl_re_sub("s/^\(\s//", berkeley_en_output)
        prepare_corpus.perl_re_sub("s/\s\)$//", berkeley_en_output)

    return True


def run_berkeley_fr():
    """Run Python Wrapper for the :program:`Berkeley Parser` for each French language file in 
:const:`config.TMP_DIRECTORY`.

    """
    files = get_files.get_aligned_files(config.TMP_DIRECTORY, "fr")
    for berkeley_fr_input in sorted(files):
        prepare_corpus.perl_re_sub(r"s/\(/-LRB-/g", berkeley_fr_input)
        prepare_corpus.perl_re_sub(r"s/\)/-RRB-/g", berkeley_fr_input)
        prepare_corpus.perl_re_sub(r's/«/"/g', berkeley_fr_input)
        prepare_corpus.perl_re_sub(r's/»/"/g', berkeley_fr_input)
        berkeley_fr_output = berkeley_fr_input[:-10] + "parser_out.fr"
        print "\n", config.timestamp(),
        print "berkeley parser started parsing file:\t", berkeley_fr_input.split(os.sep)[-1], "\n\n"
        parse_fr = parse_file_berkeley_fr(berkeley_fr_input, berkeley_fr_output)
        print "parsing ",

        while parse_fr.poll() is None:
            print "*",
            time.sleep(1.0)
            sys.stdout.flush()

        print "\n\n", config.timestamp(),
        print "berkeley parser finished parsing file:\t", berkeley_fr_input.split(os.sep)[-1], "\n\n"
        prepare_corpus.perl_re_sub("s/^\(\s//", berkeley_fr_output)
        prepare_corpus.perl_re_sub("s/\s\)$//", berkeley_fr_output)

    return True



def parse_file_stanford_en(stanford_en_input):
    """Python Wrapper for the :program:`Stanford Parser` (English)
    
For a list of command line options see :py:func:`parse_file_stanford_de`.

    """

    parser = subprocess.Popen(["java", "-mx3000m", "-cp",
                               "stanford-parser.jar:",
                               "edu.stanford.nlp.parser.lexparser.LexicalizedParser",
#                               "-sentences",
#                               "newline",
                               "-outputFormat",
                               "oneline",
                               os.path.join("grammar", "englishPCFG.ser.gz"),
                               stanford_en_input]
                               , stdout=subprocess.PIPE,
                               cwd=config.PARSER_L1_ROOT)
    return parser

def parse_file_stanford_de(stanford_de_input):
    """Python Wrapper for the :program:`Stanford Parser` (German)

Stanford Parser command line options

(See `Stanford NLP Website <http://nlp.stanford.edu/software/lex-parser.shtml>`_ 
and 
`Stanford NLP Javadocs <http://nlp.stanford.edu/nlp/javadoc/javanlp/edu/stanford/nlp/parser/lexparser/package-summary.html>`_ 
for details)

Default configuration adapted from stanford-parser-2011-08-04/lexparser-lang.sh & lexparser_lang.def

    -sentences             specify sentence segmentation type (:attr:`"newline"`)
    -tokenized             use this flag if you want to preserve your tokenization
    -outputFormat          specify output format (:attr:`"oneline, penn, latexTree, words, wordsAndTags, rootSymbolOnly, dependencies, typedDependencies, typedDependenciesCollapsed, collocations, semanticGraph, conllStyleDependencies, conll2008"`)
    -outputFormatOptions   specify output format options (:attr:`"removeTopBracket,includePunctuationDependencies"`)
    -encoding              specify encoding of input file (:attr:`"utf-8"`) default: Latin1
    -writeOutputFiles      write to files instead of stdout
    -outputFilesDirectory  specify directory where output files are saved
    -outputFilesExtension  specify extension of output files

    """
    
    grammar_file = os.path.join("grammar", "germanFactored.ser.gz")
    # for Stanford Parser Versions < 1.6.6: 
    # grammar_file = "germanFactored.ser.gz"

    parser = subprocess.Popen(["java", "-server", "-Xmx6g", "-Xms6g", "-cp",
                               "stanford-parser.jar:",
                               "edu.stanford.nlp.parser.lexparser.LexicalizedParser",
                               # "-v", # this option might cause system to freeze
                               "-tLPP", "edu.stanford.nlp.parser.lexparser.NegraPennTreebankParserParams",
                               
                               # lang_opts
                               "-hMarkov", "1",
                               "-vMarkov", "2",
                               "-vSelSplitCutOff", "300",
                               "-uwm", "1",
                               "-unknownSuffixSize", "2",
                               "-nodeCleanup", "2",
                               "-encoding",
                               "utf-8",
                               
                               # parse_opts
                               "-sentences",
                               "newline", # newline option is important to preserve sentence alignments
                               #"-tokenized",
                               #"-escaper",
                               #"edu.stanford.nlp.process.PTBEscapingProcessor", # class has been removed in stanford-parser 1.6.6
                               
                               # output options
                               "-writeOutputFiles",
                               "-outputFilesExtension",
                               "parser_out.de",
                               "-outputFilesDirectory",
                               config.TMP_DIRECTORY,
                               "-outputFormat",
                               "oneline",
                               "-outputFormatOptions",
                               "removeTopBracket",
                               
                               grammar_file,
                               
                               stanford_de_input]
                               , stdout=subprocess.PIPE,
                               cwd=config.PARSER_L1_ROOT)
    return parser

def parse_file_stanford_old_de(file):
    """Python Wrapper for the :program:`Stanford Parser` (German)

Stanford Parser command line options

(Unfortunately, these options are not well documented, see 
`Stanford NLP Website <http://nlp.stanford.edu/software/lex-parser.shtml>`_ 
and 
`Stanford NLP Javadocs <http://nlp.stanford.edu/nlp/javadoc/javanlp/edu/stanford/nlp/parser/lexparser/package-summary.html>`_ 
for details)

    -sentences             specify sentence segmentation type (:attr:`"newline"`)
    -tokenized             use this flag if you want to preserve your tokenization
    -escaper               specify escaper (in combination with :option:`-tokenized`)if you want to preserve your tokenization but also want to escape characters in the way they are escaped in the penn treebank (:js:attr:`edu.stanford.nlp.process.PTBEscapingProcessor`)
    -outputFormat          specify output format (:attr:`"oneline, penn, latexTree, words, wordsAndTags, rootSymbolOnly, dependencies, typedDependencies, typedDependenciesCollapsed, collocations, semanticGraph, conllStyleDependencies, conll2008"`)
    -outputFormatOptions   specify output format options (:attr:`"includePunctuationDependencies"`)
    -encoding              specify encoding of input file (:attr:`"utf-8"`) default: Latin1
    -writeOutputFiles      write to files instead of stdout
    -outputFilesDirectory  specify directory where output files are saved
    -outputFilesExtension  specify extension of output files

    """

    parser = subprocess.Popen(["java", "-mx3000m", "-cp",
                               "stanford-parser.jar:",
                               "edu.stanford.nlp.parser.lexparser.LexicalizedParser",
                               "-sentences",
                               "newline",
                               "-outputFormat",
                               "oneline",
                               "-encoding",
                               "utf-8",
                               "-tokenized",
                               "-escaper",
                               "edu.stanford.nlp.process.PTBEscapingProcessor",
                               "-writeOutputFiles",
                               "-outputFilesDirectory",
                               config.TMP_DIRECTORY,
                               "-outputFilesExtension",
                               "parser_out.de",
                               "germanFactored.ser.gz",
                               file]
                               , stdout=subprocess.PIPE,
                               cwd=config.PARSER_L1_ROOT)
    return parser

def parse_file_stanford_fr(stanford_fr_input):
    """Python Wrapper for the :program:`Stanford Parser` (French)
    
For a list of command line options see :py:func:`parse_file_stanford_de`.

    """
    
    grammar_file = os.path.join("grammar", "frenchFactored.ser.gz")

    parser = subprocess.Popen(["java", "-server", "-Xmx6g", "-Xms6g", "-cp",
                               "stanford-parser.jar:",
                               "edu.stanford.nlp.parser.lexparser.LexicalizedParser",
                               # "-v", # this option might cause system to freeze
                               "-tLPP", "edu.stanford.nlp.parser.lexparser.FrenchTreebankParserParams",
                               
                               # lang_opts
                               "-frenchFactored",
                               "-encoding",
                               "utf-8",
                               
                               # parse_opts
                               "-sentences",
                               "newline",
                               "-tokenized",
                               #"-escaper",
                               #"edu.stanford.nlp.process.PTBEscapingProcessor", # class has been removed in stanford-parser 1.6.6
                               
                               # output options
                               "-writeOutputFiles",
                               "-outputFilesExtension",
                               "parser_out.fr",
                               "-outputFilesDirectory",
                               config.TMP_DIRECTORY,
                               "-outputFormat",
                               "oneline",
                               "-outputFormatOptions",
                               "removeTopBracket",
                               
                               grammar_file,
                               
                               stanford_fr_input]
                               , stdout=subprocess.PIPE,
                               cwd=config.PARSER_L2_ROOT)
    return parser

def parse_file_berkeley_de(berkeley_de_input, berkeley_de_output):
    """Python Wrapper for the :program:`Berkeley Parser` (German)

For a list of command line options see :py:func:`parse_file_berkeley_fr`.

"""
    parser = subprocess.Popen([
                               "java", "-mx3000m",
                               "-jar",
                               "BerkeleyParser5.jar",
                               "-gr",
                               "ger_sm5.gr",
                               "-accurate",
                               "-inputFile",
                               berkeley_de_input,
                               "-outputFile",
                               berkeley_de_output],
                               cwd=config.PARSER_L1_ROOT,
                               stdout=subprocess.PIPE,
                               )
    return parser


def parse_file_berkeley_en(berkeley_en_input, berkeley_en_output):
    """Python Wrapper for the :program:`Berkeley Parser` (English)

For a list of command line options see :py:func:`parse_file_berkeley_fr`.

"""
    parser = subprocess.Popen([
                               "java", "-mx3000m",
                               "-jar",
                               "BerkeleyParser6.jar",
                               "-gr",
                               "eng_sm6.gr",
                               "-accurate",
                               "-inputFile",
                               berkeley_en_input,
                               "-outputFile",
                               berkeley_en_output],
                               cwd=config.PARSER_L1_ROOT,
                               stdout=subprocess.PIPE,
                               )
    return parser



def parse_file_berkeley_fr(berkeley_fr_input, berkeley_fr_output):
    """Python Wrapper for the :program:`Berkeley Parser` (French)

Berkeley Parser command line options

-render        Write rendered tree to image file. (Default: false)
-inputFile     Read input from this file instead of reading it from STDIN.
-substates     Output subcategories (only for binarized viterbi trees). (Default: false)
-gr            Grammarfile [required]
-binarize      Output binarized trees. (Default: false)
-likelihood    Output sentence likelihood, i.e. summing out all parse trees: P(w) (Default: false)
-confidence    Output confidence measure, i.e. tree likelihood: P(T|w) (Default: false)
-tokenize      Tokenize input first. (Default: false=text is already tokenized)
-scores        Output inside scores (only for binarized viterbi trees). (Default: false)
-viterbi       Compute viterbi derivation instead of max-rule tree (Default: max-rule)
-chinese       Enable some Chinese specific features in the lexicon.
-accurate      Set thresholds for accuracy. (Default: set thresholds for efficiency)
-outputFile    Store output in this file instead of printing it to STDOUT.
-useGoldPOS    Read data in CoNLL format, including gold part of speech tags.
-nThreads      Parse in parallel using n threads (Default: 1).
-kbest         Output the k best parse max-rule trees (Default: 1).
-maxLength     Maximum sentence length (Default = 200).
-h             help message

"""
    parser = subprocess.Popen([
                               "java", "-mx3000m",
                               "-jar",
                               "BerkeleyParser5.jar",
                               "-gr",
                               "fra_sm5.gr",
                               "-accurate",
                               "-inputFile",
                               berkeley_fr_input,
                               "-outputFile",
                               berkeley_fr_output],
                               cwd=config.PARSER_L2_ROOT,
                               stdout=subprocess.PIPE,
                               )
    return parser


if __name__ == '__main__':
    pass
