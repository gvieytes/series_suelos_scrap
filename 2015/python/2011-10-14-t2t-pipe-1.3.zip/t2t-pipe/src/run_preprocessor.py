#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# run_preprocessor.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
r""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Tokenization Module

As of Version 1.2 no modification of nltk-files needed.

"""


from collections import defaultdict
import config
import errors
import codecs
import nltk
import os
import re

RE_MULTIPLE_PUNCT = re.compile(r'''[\.,:;?!'"»\)]{2,4}''', re.UNICODE)

PUNCTUATION = tuple(ur""".,:;?!'"«»()""")
NUMBER_PUNCTUATION = tuple(ur""".,:'`""")

FREQUENT_ORDINAL_COLLOCATIONS = [u"Mal", u"Preis"]

_BOS = object()
_EOS = object()
_EOP = object()


def snt_word_tokenize_txt_files():
    errors.check_languages()
    l1_files, l2_files = get_txt_files()

    if config.L1 == "de":
        print "L1 - tokenizing files: ", l1_files
        word_freqs_l1 = tokenize_de(l1_files)
    if config.L1 == "en":
        print "L1 - tokenizing files: ", l1_files
        word_freqs_l1 = tokenize_en(l1_files)
    if config.L1 == "fr":
        print "L1 - tokenizing files: ", l1_files
        word_freqs_l1 = tokenize_fr(l1_files)

    if config.L2 == "de":
        print "L2 - tokenizing files: ", l2_files
        word_freqs_l2 = tokenize_de(l2_files)
    if config.L2 == "en":
        print "L2 - tokenizing files: ", l2_files
        word_freqs_l2 = tokenize_en(l2_files)
    if config.L2 == "fr":
        print "L1 - tokenizing files: ", l2_files
        word_freqs_l2 = tokenize_fr(l2_files)

    l1_files, l2_files = get_tmp_files()
    fix_hyphanation(config.L1, l1_files, word_freqs_l1)
    fix_hyphanation(config.L2, l2_files, word_freqs_l2)

    for tmp_l1, tmp_l2 in zip(l1_files, l2_files):
        os.remove(os.path.join(config.TMP_DIRECTORY, tmp_l1))
        os.remove(os.path.join(config.TMP_DIRECTORY, tmp_l2))
    return True

def get_txt_files():
    files = os.listdir(config.INPUT_DIRECTORY)
    l1_files = []
    l2_files = []
    for f in sorted(files):
        if f.endswith("_parallel_articles_" + config.L1 + ".txt"):
            l1_files.append(f)
        if f.endswith("_parallel_articles_" + config.L2 + ".txt"):
            l2_files.append(f)
    return l1_files, l2_files

def get_tmp_files():
    files = os.listdir(config.TMP_DIRECTORY)
    l1_files = []
    l2_files = []
    for f in sorted(files):
        if f.endswith("tok_" + config.L1 + ".tmp"):
            l1_files.append(f)
        if f.endswith("tok_" + config.L2 + ".tmp"):
            l2_files.append(f)
    return l1_files, l2_files

# NLTK sentence tokenizer with language specific pickle-files.
# Adapted from function sent_tokenize in nltk.tokenize.__init__.py
def sent_tokenize_de(text):
    """
    Use NLTK's currently recommended sentence tokenizer to tokenize
    sentences in the given text.  Currently, this uses
    L{PunktSentenceTokenizer}.
    """
    tokenizer = nltk.data.load('tokenizers/punkt/german.pickle')
    return tokenizer.tokenize(text)

def sent_tokenize_en(text):
    """
    Use NLTK's currently recommended sentence tokenizer to tokenize
    sentences in the given text.  Currently, this uses
    L{PunktSentenceTokenizer}.
    """
    tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')
    return tokenizer.tokenize(text)

def sent_tokenize_fr(text):
    """
    Use NLTK's currently recommended sentence tokenizer to tokenize
    sentences in the given text.  Currently, this uses
    L{PunktSentenceTokenizer}.
    """
    tokenizer = nltk.data.load('tokenizers/punkt/french.pickle')
    return tokenizer.tokenize(text)

def tokenize_de(list_of_files):
    '''Wrapper for NLTK's ``treebank.py`` on word level and ``punkt.py`` on sentence level. 
    See docstring of Module :mod:`run_preprocessor` for necessary changes to the two files.
    
    '''
    word_freqs = defaultdict()
    print "\n\n*** Tokenizing German files ***\n"

    for f in list_of_files:
        print "\n... tokenizing ", f
        with codecs.open(os.path.join(config.INPUT_DIRECTORY, f), 'r', 'utf-8') as in_de:
            tmp_file_name = f[:-6] + 'tok_de.tmp'
            with codecs.open(os.path.join(config.TMP_DIRECTORY, tmp_file_name), 'w', 'utf-8') as tmp_file:
                sents = [sent_tokenize_de(line.strip()) for line in in_de]
                for i in range(len(sents)):
                    s_counter = 0
                    for sent in sents[i]:
                        try:
                            next_snt_starter = sents[i][s_counter + 1].split()[0]
                            if next_snt_starter.startswith(PUNCTUATION):
                                next_snt_starter = next_snt_starter[1:]
                            if next_snt_starter.endswith(PUNCTUATION):
                                next_snt_starter = next_snt_starter[:-1]
                        except IndexError:
                            next_snt_starter = _EOP
                        s_counter += 1
                        sent_post_tok = post_tokenize_de(nltk.wordpunct_tokenize(sent), next_snt_starter)
                        if sent_post_tok:
                            sent_post_tok = clean_sentence(sent_post_tok)
                            tmp_file.write(sent_post_tok)
                            for word in sent_post_tok.strip().split():
                                try:
                                    word_freqs[unicode(word)] += 1
                                except KeyError:
                                    word_freqs[unicode(word)] = 1

    print "\nStats for German part of ", config.CORPUS_ID, " (if OCR data incl. OCR debris):\n"
    print "Tokens: ", sum(word_freqs.itervalues())
    print "Types: ", len(word_freqs)
    return word_freqs

def tokenize_en(list_of_files):
    '''Wrapper for NLTK's ``treebank.py`` on word level and ``punkt.py`` on sentence level. 
    See docstring of Module :mod:`run_preprocessor` for necessary changes to the two files.
    
    '''

    word_freqs = defaultdict()
    print "\n\n*** Tokenizing English files ***\n"
    for f in list_of_files:
        print "\n... tokenizing ", f
        with codecs.open(os.path.join(config.INPUT_DIRECTORY, f), 'r', 'utf-8') as in_en:
            tmp_file_name = f[:-6] + 'tok_en.tmp'
            with codecs.open(os.path.join(config.TMP_DIRECTORY, tmp_file_name), 'w', 'utf-8') as tmp_file:
                sents = [sent_tokenize_en(line.strip()) for line in in_en]
                for i in range(len(sents)):
                    for sent in sents[i]:
                        sent_post_tok = post_tokenize_en(nltk.wordpunct_tokenize(sent))
                        if sent_post_tok:
                            sent_post_tok = clean_sentence(sent_post_tok)
                            tmp_file.write(sent_post_tok)
                            for word in sent_post_tok.strip().split():
                                try:
                                    word_freqs[unicode(word)] += 1
                                except KeyError:
                                    word_freqs[unicode(word)] = 1

    print "\nStats for English part of ", config.CORPUS_ID, " (if OCR data incl. OCR debris):\n"
    print "Tokens: ", sum(word_freqs.itervalues())
    print "Types: ", len(word_freqs)
    return word_freqs

def tokenize_fr(list_of_files):
    '''Wrapper for NLTK's ``treebank.py`` on word level and ``punkt.py`` on sentence level. 
    See docstring of Module :mod:`run_preprocessor` for necessary changes to the two files.
    
    '''

    word_freqs = defaultdict()
    print "\n\n*** Tokenizing French files ***\n"
    for f in list_of_files:
        print "\n... tokenizing ", f
        with codecs.open(os.path.join(config.INPUT_DIRECTORY, f), 'r', 'utf-8') as in_fr:
            tmp_file_name = f[:-6] + 'tok_fr.tmp'
            with codecs.open(os.path.join(config.TMP_DIRECTORY, tmp_file_name), 'w', 'utf-8') as tmp_file:
                sents = [sent_tokenize_fr(line.strip()) for line in in_fr]
                for i in range(len(sents)):
                    s_counter = 0
                    for sent in sents[i]:
                        try:
                            next_snt_starter = sents[i][s_counter + 1].split()[0]
                            if next_snt_starter.startswith(PUNCTUATION):
                                next_snt_starter = next_snt_starter[1:]
                            if next_snt_starter.endswith(PUNCTUATION):
                                next_snt_starter = next_snt_starter[:-1]
                        except IndexError:
                            next_snt_starter = _EOP
                        s_counter += 1
                        sent_post_tok = post_tokenize_fr(nltk.wordpunct_tokenize(sent), next_snt_starter)
                        if sent_post_tok:
                            sent_post_tok = clean_sentence(sent_post_tok)
                            tmp_file.write(sent_post_tok)
                            for word in sent_post_tok.strip().split():
                                try:
                                    word_freqs[unicode(word)] += 1
                                except KeyError:
                                    word_freqs[unicode(word)] = 1

    print "\nStats for French part of ", config.CORPUS_ID, " (if OCR data incl. OCR debris):\n"
    print "Tokens: ", sum(word_freqs.itervalues())
    print "Types: ", len(word_freqs)
    return word_freqs


def post_tokenize_de(sent_tok, next_snt_starter):
    str_buffer = u''
    letter_count = 0
    number_count = 0
    word_count = 0
    prev_word = _BOS
    prev2_word = prev_word
    for w in sent_tok:
        try:
            next_word = sent_tok[word_count + 1]
        except IndexError:
            next_word = _EOS
        word_count += 1

        if RE_MULTIPLE_PUNCT.match(w):
            if w.startswith(u"..."):
                str_buffer += u" ... "
                if len(w) > 3:
                    str_buffer += " ".join([p for p in w][3:])
            else:
                str_buffer += u" "
                str_buffer += " ".join([p for p in w])
        # combine mid sentence periods with previous token    
        # do not add a white space at the beginning of a sentence
        elif prev_word == _BOS:
            str_buffer += w
        # do not add white spaces in numbers separated by NUMBER_PUNCTUATION
        elif w in NUMBER_PUNCTUATION and re.match(r"\d+", prev_word) and next_word != _EOS:
            str_buffer += w
        elif prev_word in NUMBER_PUNCTUATION and re.match(r"\d+", w) and re.match(r"\d+", prev2_word) and next_word != _EOS:
            str_buffer += w
        elif w == u"." and next_word != _EOS:
            str_buffer += w
        else:
            # combine expected ordinal numbers with sentence boundary period
            # if they are followed by a word specified in
            # FREQUENT_ORDINAL_COLLOCATIONS
            if w == u"." and next_word == _EOS and re.match(r"\d+", prev_word):
                if next_snt_starter in FREQUENT_ORDINAL_COLLOCATIONS:
                    str_buffer += w
                else:
                    str_buffer += u" "
                    str_buffer += w
            else:
                str_buffer += u" "
                str_buffer += w        
        prev2_word = prev_word
        prev_word = w


        for ch in w:
            if ch in config.LETTERS:
                letter_count += 1
            elif ch in config.NUMBERS:
                number_count += 1
    # Use white space instead of newline if a sentence boundary period
    # is preceded by a number and followed by a word
    # specified in FREQUENT_ORDINAL_COLLOCATIONS    
    if next_snt_starter not in FREQUENT_ORDINAL_COLLOCATIONS:
        str_buffer += u"\n"
    elif w == u"." and re.match(r"\d+", prev2_word):
        str_buffer += u" "
    else:
        str_buffer += u"\n"

    # add sentence break between an all-upper-case word followed by a word with initial capital letter
    # (typically paragraph headings)
    str_buffer = re.sub(r'([A-ZÄÖÜÈÀÉÇÎ]{3,}) \b([A-ZÄÖÜÈÀÉÇÎ][a-zäöü]+\b)', r'\1\n\2', str_buffer)

    if config.RUDIMENTARY_OCR_CLEANING:
        str_buffer = rudimentary_clean_ocr_debris(str_buffer, letter_count, number_count)

    return str_buffer


def post_tokenize_en(sent_tok):
    letter_count = 0
    number_count = 0
    for w in sent_tok:
        for ch in w:
            if ch in config.LETTERS:
                letter_count += 1
            elif ch in config.NUMBERS:
                number_count += 1
    str_buffer = " ".join(sent_tok) + "\n"

    str_buffer = re.sub(r'([A-ZÄÖÜÈÀÉÇÎ]{3,}) \b([A-ZÄÖÜÈÀÉÇÎ][a-zäöü]+\b)', r'\1\n\2', str_buffer)
    
    if config.RUDIMENTARY_OCR_CLEANING:
        str_buffer = rudimentary_clean_ocr_debris(str_buffer, letter_count, number_count)

    return str_buffer


def post_tokenize_fr(sent_tok, next_snt_starter):
    str_buffer = u''
    letter_count = 0
    number_count = 0
    word_count = 0
    prev_word = _BOS
    prev2_word = prev_word
    for w in sent_tok:
        try:
            next_word = sent_tok[word_count + 1]
        except IndexError:
            next_word = _EOS
        word_count += 1
        if RE_MULTIPLE_PUNCT.match(w):
            if w.startswith(u"..."):
                str_buffer += u" ... "
                if len(w) > 3:
                    str_buffer += " ".join([p for p in w][3:])
            else:
                str_buffer += u" "
                str_buffer += " ".join([p for p in w])
        # combine mid sentence periods with previous token    
        # do not add a white space at the beginning of a sentence
        elif prev_word == _BOS:
            str_buffer += w
        # do not add white spaces in numbers separated by NUMBER_PUNCTUATION
        elif w in NUMBER_PUNCTUATION and re.match(r"\d+", prev_word) and next_word != _EOS:
            str_buffer += w
        elif prev_word in NUMBER_PUNCTUATION and re.match(r"\d+", w) and re.match(r"\d+", prev2_word) and next_word != _EOS:
            str_buffer += w
        elif w == u"." and next_word != _EOS:
            str_buffer += w
        else:
            str_buffer += u" "
            str_buffer += w        
        prev2_word = prev_word
        prev_word = w

        for ch in w:
            if ch in config.LETTERS:
                letter_count += 1
            elif ch in config.NUMBERS:
                number_count += 1

    str_buffer += "\n"

    # add sentence break between an all-upper-case word followed by a word with initial capital letter
    # (typically paragraph headings)
    str_buffer = re.sub(ur'([A-ZÄÖÜÈÀÉÇÎ]{3,}) \b([A-ZÄÖÜÈÀÉÇÎ][a-zäöü]+\b)', ur'\1\n\2', str_buffer)
    # language specific treatment of apostrophe
    
    str_buffer = re.sub(ur"\b(\w) ['’] (\w+\b)", ur"\1’ \2", str_buffer)
    str_buffer = re.sub(ur"\b([Qq]u) ['’] (\w+\b)", ur"\1’ \2", str_buffer)
    # Append tokens which should not be separated (some items taken from 
    # tree-tagger-french script (c) 1987 Achim Stein
    str_buffer = re.sub(ur"- (ce|ci|là|elle|elles|il|ils|je|la|le|les|leur|lui|même|mêmes|moi|nous|on|toi|tu|vous|en|y)\b", ur'-\1', str_buffer)
    str_buffer = re.sub(ur"- (t) -(elles?|il)", ur'-\1-\2', str_buffer)
    str_buffer = re.sub(ur"([Cc]’) \best - à - dire", ur'\1est-à-dire', str_buffer)
    str_buffer = re.sub(ur"([dD]’) \b(abord|ailleurs|après|autant)", ur'\1\2', str_buffer)
    str_buffer = re.sub(ur"([Aa]u) - \b(dessus)", ur'\1-\2', str_buffer)

    if config.RUDIMENTARY_OCR_CLEANING:
        str_buffer = rudimentary_clean_ocr_debris(str_buffer, letter_count, number_count)

    return str_buffer

def rudimentary_clean_ocr_debris(str_buffer, letter_count, number_count):
    '''Attempt to automatically remove most of the unwanted lines in data obtained from OCR
    
    * remove lines that contain a sequence of 5 or more periods (e.g. table/table of contents/OCR-debris)
    * remove lines that contain 6 or more consecutive '1 character 1 blank space'-sequence
    * remove lines that contain more numbers than letters (exceptions in: ``resources/very_short_words.txt``)
    * remove lines that contain less letters than specified in :const:`config.MIN_LETTERS_PER_SENT` limit (exceptions in: ``resources/very_short_words.txt``)
    
    '''
    if "....." in str_buffer:
        print "\n\nsentence excluded (5 or more consecutive '.'): ", str_buffer.strip().encode('utf-8')
        return False

    if re.search(r"\b. \b. \b. \b. \b. \b. ", str_buffer) is not None:
        print "\n\nsentence excluded (6 or more consecutive '1 character 1 blank space'-sequences ): ", str_buffer.strip().encode('utf-8')
        return False

    elif letter_count < number_count:
        elem_counter = 0
        for i in str_buffer.split():
            elem_counter += 1
            if unicode(i.strip()) in config.VERY_SHORT_WORDS:
                print "*** VERY SHORT WORD ***", str_buffer.strip().encode('utf-8')
                return str_buffer
            else:
                if re.match(r'\d+ \.', str_buffer):
                    return "".join(str_buffer.strip().split()) + " "
                if elem_counter == len(str_buffer.split()) - 1:
                    print "\n\nsentence excluded (more numbers than letters): ", str_buffer.strip().encode('utf-8')
                    return False

    elif letter_count < config.MIN_LETTERS_PER_SENT:
        elem_counter = 0
        for i in str_buffer.split():
            elem_counter += 1
            if unicode(i.strip()) in config.VERY_SHORT_WORDS:
                print "*** VERY SHORT WORD ***", str_buffer.strip().encode('utf-8')
                return str_buffer
            else:
                if re.match(r'^\d+ \.', str_buffer):
                    return "".join(str_buffer.strip().split()) + " "
                if elem_counter == len(str_buffer.split()) - 1:
                    print "\n\nsentence excluded (less letters than specified in MIN_LETTERS_PER_SENT limit): ", str_buffer.strip().encode('utf-8')
                    return False

    else:
        return str_buffer

def clean_sentence(sentence):
    # clean sentence initial characters that cannot be used at the beginning
    # of a sentence or would have a negative impact on parser output
    sentence = re.sub(ur'^\s*[\-\)_»]\s*', r'', sentence)
    sentence = re.sub(ur'^. EOA', r'.EOA', sentence)
    sentence = re.sub(ur'^" " ', r'', sentence)
    sentence = re.sub(ur'^« » ', r'', sentence)
    return sentence

def fix_hyphanation(Language, list_of_files, word_freqs):
    '''Load complete corpus into memory and delete hyphan in words that occur more frequently 
without hyphan in the current corpus (accuracy increases with corpus size). As the whole corpus 
is loaded into memory anyway, some basic corpus statistics are printed before the hyphans 
are removed. 

.. note::

    In a corpus with a lot of OCR debris. These statistics have to be considered with care, as 


    '''

    print "\n *** fix OCR-word-division errors: \n\n"

    print list_of_files
    print "\n"
    print "Tokens (if OCR data incl. OCR debris): ", sum(word_freqs.itervalues())
    print "Types (if OCR data incl. OCR debris): ", len(word_freqs)

    for f in list_of_files:
        in_f = codecs.open(os.path.join(config.TMP_DIRECTORY, f), "r", "utf-8")
        out_file_name = f[:-10] + Language + ".tok"
        with codecs.open(os.path.join(config.TMP_DIRECTORY, out_file_name), 'w', 'utf-8') as out_f:
            for line in in_f:
                str_buffer = unicode('')
                for word in line.split():
                    hyphanated_word = re.match(ur'(.+)-(.+)', word)
                    if hyphanated_word:
                        hyphanated_digits = re.match(ur'(\d+)-(\d+)', word)
                        if hyphanated_digits:
                            str_buffer += unicode(word)
                        else:
                            dehyphanated_word = unicode("".join(hyphanated_word.groups()))
                            if dehyphanated_word in word_freqs:
                                if word_freqs[dehyphanated_word] > word_freqs[unicode(word)]:
                                    print word.encode('utf-8'), "-->", dehyphanated_word.encode('utf-8')
                                    str_buffer += dehyphanated_word
                                else:
                                    str_buffer += unicode(word)
                            else:
                                str_buffer += unicode(word)
                    else:
                        str_buffer += unicode(word)
                    str_buffer += unicode(" ")
                out_f.write(str_buffer.strip())
                out_f.write("\n")
        in_f.close()
    return True


if __name__ == '__main__':
    pass
