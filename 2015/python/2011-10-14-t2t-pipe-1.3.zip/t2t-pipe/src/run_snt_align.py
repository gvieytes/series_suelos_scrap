#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# run_snt_align.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Sentence Alignment
"""
from __future__ import division
from resources.dictcc_extract import get_dictionary
import codecs
import config
import errors
import get_files
import os
import prepare_corpus
import re
import subprocess
import time


def get_sentence_alignments(sentence_aligner):
    """Co-ordinates and verifies the sentence alignment process
"""


    if sentence_aligner == "gargantua":
        run_gargantua()
    elif sentence_aligner == "hunalign":
        if config.ONE_BIG_FILE:
            run_hunalign_one_file()
        else:
            run_hunalign_batch()
    elif sentence_aligner == "microsoft":
        if config.ONE_BIG_FILE:
            run_microsoft()
        else:
            run_microsoft_multi_file()
    elif sentence_aligner == "vanilla":
        run_vanilla()
    else:
        errors.err_log_and_exit(errors.SENTENCE_ALIGNER_NOT_IMPLEMENTED)

    # remove end of article markers ".EOA" and check if sentence alignment went smoothly
    # - files need to have exactly the same number of lines
    l1_files = get_files.get_aligned_files(config.TMP_DIRECTORY, config.L1)
    l2_files = get_files.get_aligned_files(config.TMP_DIRECTORY, config.L2)
    for l1_file, l2_file in zip(l1_files, l2_files):
        
        if config.SENTENCE_ALIGNER in ["hunalign", "microsoft"]:
            # remove end of article markers - the pattern r"s/^\.EOA\n//g" including the
            # beginning of line character caused exceptions in "microsoft"
            prepare_corpus.perl_re_sub(r"s/\.EOA\n//g", l1_file)
            prepare_corpus.perl_re_sub(r"s/\.EOA\n//g", l2_file)
        if config.SENTENCE_ALIGNER == "vanilla":
            # remove end of sentence markers
            prepare_corpus.perl_re_sub(r"s/\s+\.EOS//g", l1_file)
            prepare_corpus.perl_re_sub(r"s/\s+\.EOS//g", l2_file)
            # make sure that there are no empty lines
            prepare_corpus.perl_re_sub(r"s/^(\s+)?\n//g", l1_file)
            prepare_corpus.perl_re_sub(r"s/^(\s+)?\n//g", l2_file)
        
        print "files {0} and {1} contain {2} aligned sentence pairs".format(
                                                l1_file.split(os.sep)[-1], 
                                                l2_file.split(os.sep)[-1],
                                                errors.check_snt_aligned_files(l1_file, l2_file))


def run_gargantua():
    """Wrapper for :program:`Gargantua` ***NOT YET IMPLEMENTED***
    
.. todo:: implement wrapper and input file preparation for :program:`Gargantua`

"""

    errors.err_log_and_exit(errors.SENTENCE_ALIGNER_NOT_IMPLEMENTED)


def create_hunalign_batch_file(l1_files, l2_files):
    """Creates batch file for :program:`Hunalign` in multi-file mode

File is stored in :const:`config.TMP_DIRECTORY` with the name: ``hunalign.batch``

.. note::

    Currently there is a warning in the :program:`Hunalign` output: 
    ``Batch file has incorrect format.`` - no negative effects could be observed and no
    obvious deviations from the required format could be found.

.. todo:: find mistake in :program:`Hunalign` batch file format or double check if this is a known bug
"""

    with codecs.open(os.path.join(config.TMP_DIRECTORY, "hunalign.batch"), "w", "utf-8") as batch:
        for f_l1, f_l2 in zip(l1_files, l2_files):
            batch.write(os.path.join(config.TMP_DIRECTORY, f_l1))
            batch.write("\t")
            batch.write(os.path.join(config.TMP_DIRECTORY, f_l2))
            batch.write("\t")
            batch.write(os.path.join(config.TMP_DIRECTORY, f_l1[:-6] + "hun.aligned"))
            batch.write("\n")
        batch.write("\n")
    return True


def extract_l1_l2_from_hunalign():
    """Extracts two separate language files from :program:`Hunalign` output

Extension for input files: ``hun.aligned``
"""
    in_file_ext = "hun.aligned"
    out_file_ext = "hun_aligned."
    test_file_ext = "hunalign.test"
    aligned_files = get_files.get_files(config.TMP_DIRECTORY, in_file_ext)
    errors.check_input_files(aligned_files, config.TMP_DIRECTORY, in_file_ext)
    print aligned_files
    for f in aligned_files:
        with codecs.open(f, 'r', 'utf-8') as in_f:
            with codecs.open(f[:-len(in_file_ext)] + out_file_ext + config.L1,
                             'w', 'utf-8') as out_l1:
                with codecs.open(f[:-len(in_file_ext)] + out_file_ext + config.L2,
                                 'w', 'utf-8') as out_l2:
                    with codecs.open(f[:-len(in_file_ext)] + test_file_ext, "w", "utf-8") as test_file:
                        l1_snt_counter = 0
                        l2_snt_counter = 0
                        for line in in_f:
                            sents_l1 = line.split("\t")[0].split("~~~")
                            sents_l2 = line.split("\t")[1].split("~~~")
                            #print sents_l1
                            #print sents_l2
                            if sents_l1 == [u'']:
                                print "\n*** Link: 0 :",
                            else:
                                print "\n*** Link:", len(sents_l1), ":",
                            if sents_l2 == [u'']:
                                print "0",
                            else:
                                print len(sents_l2),
                            print "*** Quality:", line.split("\t")[2].strip(),
                            # s is an intentionally unused variable
                            # suggestions for a more elegant solution are always welcome
                            for s in sents_l1:
                                if sents_l1 == [u'']:
                                    print "L1-S: 0",
                                    test_file.write("-1")
                                    test_file.write(" ")
                                    break
                                else:
                                    l1_snt_counter += 1
                                    print "L1-S:", l1_snt_counter,
                                    test_file.write(str(l1_snt_counter))
                                    test_file.write(" ")
                            test_file.write("; ")
                            print ";",
                            # s is an intentionally unused variable
                            # suggestions for a more elegant solution are always welcome
                            for s in sents_l2:
                                if sents_l2 == [u'']:
                                    print "L2-S: 0",
                                    test_file.write("-1")
                                    break
                                else:
                                    l2_snt_counter += 1
                                    print "L2-S:", l2_snt_counter,
                                    test_file.write(str(l2_snt_counter))
                                    test_file.write(" ")
                            test_file.write("\n")
                            line_l1 = " ".join(sents_l1)
                            line_l2 = " ".join(sents_l2)
                            line_l1 = re.sub(r'\s+', r' ', line_l1)
                            line_l2 = re.sub(r'\s+', r' ', line_l2)
                            print "\n", line_l1
                            print line_l2

                            if float(line.split("\t")[2].strip()) > config.HUNALIGN_THRESHOLD:
                                    if line_l1.strip() != u'' and line_l2.strip() != u'':
                                        out_l1.write(line_l1.strip())
                                        out_l1.write("\n")
                                        out_l2.write(line_l2.strip())
                                        out_l2.write("\n")

    return True


def run_hunalign_one_file():
    """Wrapper for :program:`Hunalign` in one-file mode

Extension for input files: ``.tok``

command line options:

    -text                        output in human readable text format rather than ladder format
    -bisent                      only 1:1 alignments are extracted
    -cautious                    preceding and following segments have to be 1:1 as well
    -hand                        ``=FILE`` - manually compiled reference file against which results are measured
    -realign                     alignment is built in three phases (highest quality, triples running time)
    -autodict                    ``=FILENAME`` - save automatically generated dictionary file to location specified in ``FILENAME``
    -utf                         default is Latin1, use this switch to force the system to poperly calculate character counts if input is in UTF-8
    -thresh                      ``=n`` - don't print segments with score lower than n/100
    -ppthresh                    ``=n`` - filter rungs with less than n/100 average score in their vicinity
    -headerthresh                ``=n`` - filter all rungs at the start and end of texts until finding a reliably plausible region
    -topothresh                  ``=n`` - filter rungs with less than n percent of one-to-one segments in their vicinity

"""
    in_file_ext = ".tok"
    l1_files = get_files.get_files(config.TMP_DIRECTORY, config.L1 + in_file_ext)
    l2_files = get_files.get_files(config.TMP_DIRECTORY, config.L2 + in_file_ext)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, in_file_ext)

    if config.DICT_SOURCE == "no_dict":
        dictionary = os.path.join(config.T2T_SCRIPTDIR, "dicts", "null.dict")
    if config.DICT_SOURCE == "dict_cc":
        dict_file_path = os.path.join(config.T2T_SCRIPTDIR,
                                      "dicts", config.L1 + "-" + config.L2 + "_" + \
                                      config.DICT_SOURCE + ".dic")
        if os.path.isfile(dict_file_path) is False:
            get_dictionary()
        dictionary = dict_file_path

    l1_file = os.path.join(config.TMP_DIRECTORY, l1_files[0])
    l2_file = os.path.join(config.TMP_DIRECTORY, l2_files[0])
    autodict_file = os.path.join(config.DICT_DIRECTORY, config.L1 + "-" + config.L2 + \
                                 "_autodict.txt")
    hunalign_output = os.path.join(config.TMP_DIRECTORY, l1_file[:-6] + "hun.aligned")
    print "ONE_BIG_FILE = True - aligning: "
    print l1_file
    print l2_file

    hunalign = subprocess.Popen(
                                    ["./hunalign",
                                    dictionary,
                                    l1_file,
                                    l2_file,
                                    "-text",
                                    "-realign",
                                    "-autodict=" + autodict_file,
                                    "-utf",
                                    ],
                                    stdout=subprocess.PIPE,
                                    cwd=config.SENTENCE_ALIGNER_ROOT)
    hunalign.wait()
    with codecs.open(os.path.join(config.TMP_DIRECTORY, hunalign_output), "w", "utf-8") as out_f:
        for line in hunalign.stdout:
            out_f.write(line)
            out_f.write("\n")
    extract_l1_l2_from_hunalign()
    return True


def run_hunalign_batch():
    """Wrapper for :program:`Hunalign` in multi-file mode

Extension for input files: ``.tok``

For a list of command line options see :py:func:`run_hunalign_one_file`.
"""

    in_file_ext = ".tok"
    l1_files = get_files.get_files(config.TMP_DIRECTORY, config.L1 + in_file_ext)
    l2_files = get_files.get_files(config.TMP_DIRECTORY, config.L2 + in_file_ext)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, in_file_ext)
    create_hunalign_batch_file(l1_files, l2_files)
    if config.DICT_SOURCE == "no_dict":
        dictionary = os.path.join(config.T2T_SCRIPTDIR, "resources", "null.dic")
    if config.DICT_SOURCE == "dict_cc":
        dict_file_path = os.path.join(config.DICT_DIRECTORY,
                                      config.L1 + "-" + config.L2 + \
                                      "_" + config.DICT_SOURCE + ".dic")
        print "**", dict_file_path
        if os.path.isfile(dict_file_path) is False:
            get_dictionary()
        dictionary = dict_file_path

    batch_file = os.path.join(config.TMP_DIRECTORY, "hunalign.batch")

    if config.DICT_SOURCE == "no_dict" or config.HUNALIGN_FORCE_REALIGN:
        hunalign_cmd = ["./hunalign", dictionary, batch_file, "-text", "-realign", "-utf", "-batch"]
    if config.DICT_SOURCE == "dict_cc":
        hunalign_cmd = ["./hunalign", dictionary, batch_file, "-text", "-utf", "-batch"]

    hunalign = subprocess.Popen(hunalign_cmd, cwd=config.SENTENCE_ALIGNER_ROOT)
    hunalign.wait()
    extract_l1_l2_from_hunalign()
    return True


def run_microsoft():
    """Wrapper for :program:`Microsoft Bilingual Sentence Aligner` in multi-file mode

Extension for input files: ``.tok``

.. warning::

    **On Linux:**
    
    If the subprocess (line 315) is called without "perl" as the first argument, the Perl script 
    ``align-sents-all.pl`` in the root directory of 
    :program:`Microsoft Bilingual Sentence Aligner` needs a ``-w``-flag in the first 
    line: ``#!/usr/bin/perl -w``
    
    All other scripts that are called by the first script (esp. ``build-model-one6.pl`` 
    **must not** have a ``-w``-flag in the first line: ``#!/usr/bin/perl`` otherwise the 
    program gets caught in an endless loop.


"""

    in_file_ext = ".tok"
    l1_files = get_files.get_files(config.TMP_DIRECTORY, config.L1 + in_file_ext)
    l2_files = get_files.get_files(config.TMP_DIRECTORY, config.L2 + in_file_ext)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, in_file_ext)

    tmp_file_ext = ".snt"
    for l1_file, l2_file in zip(l1_files, l2_files):
        get_files.rename_file(l1_file, in_file_ext, tmp_file_ext)
        get_files.rename_file(l2_file, in_file_ext, tmp_file_ext)

    l1_files = get_files.get_files(config.TMP_DIRECTORY, config.L1 + tmp_file_ext)
    l2_files = get_files.get_files(config.TMP_DIRECTORY, config.L2 + tmp_file_ext)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, tmp_file_ext)

    for l1_file, l2_file in zip(l1_files, l2_files):
        microsoft = subprocess.Popen(["perl",
                                     "./align-sents-all.pl",
                                     l1_file,
                                     l2_file,
                                     str(config.INITIAL_THRESHOLD)],
                                     cwd=config.SENTENCE_ALIGNER_ROOT)
        microsoft.wait()
    time.sleep(0.5)
    
    # rename files
    os.chdir(config.TMP_DIRECTORY)
    for l1_file, l2_file in zip(l1_files, l2_files):
        get_files.rename_file(l1_file, tmp_file_ext, in_file_ext)
        get_files.rename_file(l2_file, tmp_file_ext, in_file_ext)
        get_files.rename_file(l1_file + ".aligned", config.L1 +".snt.aligned", 'microsoft_aligned.' + config.L1)
        get_files.rename_file(l2_file + ".aligned", config.L2 +".snt.aligned", 'microsoft_aligned.' + config.L2)

    return True

def run_microsoft_multi_file():
    """Wrapper for :program:`Microsoft Bilingual Sentence Aligner` in multi-file mode

Extension for input files: ``.tok``

.. warning::

    **On Linux:**
    
    If the subprocess (line 382) is called without "perl" as the first argument, the Perl script 
    ``align-sents-all-multi-file.pl`` in the root directory of 
    :program:`Microsoft Bilingual Sentence Aligner` needs ``-w``-flag in the first 
    line: ``#!/usr/bin/perl -w``
    
    All other scripts that are called by the first script (esp. ``build-model-one-multi-file.pl`` 
    **must not** have a ``-w``-flag in the first line: ``#!/usr/bin/perl`` otherwise the 
    program gets caught in an endless loop.


"""
    
    
    # Create additional tmp directory for the huge number of additional ms_bsa-files
    if os.path.isdir(config.MICROSOFT_BSA_TMP):
        print "exists: ", config.MICROSOFT_BSA_TMP
    else:
        os.mkdir(config.MICROSOFT_BSA_TMP)
        print "created: ", config.MICROSOFT_BSA_TMP

    # Get .tok files
    in_file_ext = ".tok"
    l1_files = get_files.get_files(config.TMP_DIRECTORY, config.L1 + in_file_ext,
                                   return_absolute_path=False)
    l2_files = get_files.get_files(config.TMP_DIRECTORY, config.L2 + in_file_ext,
                                   return_absolute_path=False)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, in_file_ext)
    # Temporarily rename files from config.TMP_DIRECTORY/file.tok to MICROSOFT_BSA_TMP/file.snt
    tmp_file_ext = ".snt"
    for l1_file, l2_file in zip(l1_files, l2_files):
        get_files.rename_file(l1_file, in_file_ext, tmp_file_ext,
                              in_dir=config.TMP_DIRECTORY, out_dir=config.MICROSOFT_BSA_TMP)
        get_files.rename_file(l2_file, in_file_ext, tmp_file_ext,
                              in_dir=config.TMP_DIRECTORY, out_dir=config.MICROSOFT_BSA_TMP)
    # Get .snt files
    l1_files = get_files.get_files(config.MICROSOFT_BSA_TMP, config.L1 + tmp_file_ext)
    l2_files = get_files.get_files(config.MICROSOFT_BSA_TMP, config.L2 + tmp_file_ext)
    errors.check_parallel_input_files(l1_files, l2_files, config.MICROSOFT_BSA_TMP, tmp_file_ext)

    microsoft = subprocess.Popen(["perl",
                                  "./align-sents-all-multi-file.pl",
                                  config.MICROSOFT_BSA_TMP,
                                  str(config.INITIAL_THRESHOLD)],
                                  cwd=config.SENTENCE_ALIGNER_ROOT)
    microsoft.wait()
    time.sleep(0.5)
    al_ext = ".snt.aligned"
    l1_files = get_files.get_files(config.MICROSOFT_BSA_TMP, config.L1 + al_ext,
                                   return_absolute_path=False)
    l2_files = get_files.get_files(config.MICROSOFT_BSA_TMP, config.L2 + al_ext,
                                   return_absolute_path=False)
    errors.check_parallel_input_files(l1_files, l2_files, config.MICROSOFT_BSA_TMP, al_ext)
    # Rename and move files generated by Microsoft BSA back to config.TMP_DIRECTORY
    new_al_ext = "microsoft_aligned."
    for l1_file, l2_file in zip(l1_files, l2_files):
        get_files.rename_file(l1_file, config.L1 + al_ext, new_al_ext + config.L1,
                              in_dir=config.MICROSOFT_BSA_TMP, out_dir=config.TMP_DIRECTORY)
        get_files.rename_file(l2_file, config.L2 + al_ext, new_al_ext + config.L2,
                              in_dir=config.MICROSOFT_BSA_TMP, out_dir=config.TMP_DIRECTORY)
    # Get microsoft_aligned files
    l1_files = get_files.get_files(config.TMP_DIRECTORY, new_al_ext + config.L1, 
                                   return_absolute_path=False)
    l2_files = get_files.get_files(config.TMP_DIRECTORY, new_al_ext + config.L2, 
                                   return_absolute_path=False)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, new_al_ext + "L1/L2")
    # rename files back from MICROSOFT_BSA_TMP/file.snt to config.TMP_DIRECTORY/file.tok
    l1_files = get_files.get_files(config.MICROSOFT_BSA_TMP, config.L1 + tmp_file_ext, 
                                   return_absolute_path=False)
    l2_files = get_files.get_files(config.MICROSOFT_BSA_TMP, config.L2 + tmp_file_ext, 
                                   return_absolute_path=False)
    errors.check_parallel_input_files(l1_files, l2_files, config.MICROSOFT_BSA_TMP, tmp_file_ext)
    for l1_file, l2_file in zip(l1_files, l2_files):
        get_files.rename_file(l1_file, tmp_file_ext, in_file_ext,
                              in_dir=config.MICROSOFT_BSA_TMP, out_dir=config.TMP_DIRECTORY)
        get_files.rename_file(l2_file, tmp_file_ext, in_file_ext,
                              in_dir=config.MICROSOFT_BSA_TMP, out_dir=config.TMP_DIRECTORY)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, in_file_ext)
    return True


def prepare_vanilla(in_file, Language):
    """Creates input file for the :program:`Vanilla Aligner`

Processes one file at a time. Called by :py:func:`run_vanilla`.
"""

    with codecs.open(in_file, 'r', 'utf-8') as in_f:
        out_file_name = in_file[:-6] + "vanilla_in." + Language
        with codecs.open(out_file_name, 'w', 'utf-8') as out_f:
            for line in in_f:
                for w in line.split():
                    out_f.write(w + "\n")
                if line.strip() != ".EOA":
                    out_f.write(".EOS\n")

    return True


def extract_l1_l2_from_vanilla():
    """Extracts two separate language files from :program:`Vanilla Aligner` output

Extension for input files: ``.al``
"""

    in_file_ext = ".al"
    out_file_ext = "vanilla_aligned."
    aligned_files = get_files.get_files(config.TMP_DIRECTORY, in_file_ext)
    errors.check_input_files(aligned_files, config.TMP_DIRECTORY, in_file_ext)

    for f in aligned_files:
        print f
        with codecs.open(f, 'r', 'utf-8') as in_f:
            vanilla = []
            counter = 0
            for line in in_f:
                print line
                if line.startswith('.EOA'):
                    counter += 1
                    if counter == 1:
                        print "\n\n*** Parallel Corpus: ", f[:-35], " ***"
                        print "*** End of Article ", counter, " ***"
                    else:
                        print "*** End of Article ", counter, " ***"
                    vanilla.append(line)
                    vanilla.append("\n")
                    vanilla.append("\n")
                else:
                    vanilla.append(line)
        print vanilla
        with codecs.open(f[:-16] + out_file_ext + config.L1,
                         'w', 'utf-8') as l1f:
            for i in range(1, len(vanilla), 4):
                l1f.write(vanilla[i])

        with codecs.open(f[:-16] + out_file_ext + config.L2,
                         'w', 'utf-8') as l2f:
            for i in range(2, len(vanilla), 4):
                l2f.write(vanilla[i])
    return True


def run_vanilla():
    """Wrapper for :program:`Vanilla Aligner`

Extension for input files: ``.tok``
"""
    # Get .tok files
    in_file_ext = ".tok"
    l1_files = get_files.get_files(config.TMP_DIRECTORY, config.L1 + in_file_ext)
    l2_files = get_files.get_files(config.TMP_DIRECTORY, config.L2 + in_file_ext)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, in_file_ext)

    for f in l1_files:
        prepare_vanilla(f, config.L1)
    for f in l2_files:
        prepare_vanilla(f, config.L2)

    # Get vanilla_in files
    in_file_ext = "vanilla_in."
    l1_files = get_files.get_files(config.TMP_DIRECTORY, in_file_ext + config.L1)
    l2_files = get_files.get_files(config.TMP_DIRECTORY, in_file_ext + config.L2)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, in_file_ext)

    for l1_f, l2_f in zip(l1_files, l2_files):
        l1_file = os.path.join(config.TMP_DIRECTORY, l1_f)
        l2_file = os.path.join(config.TMP_DIRECTORY, l2_f)
        vanilla = subprocess.Popen(
                                    ["./align",
                                    '-d',
                                    ".EOS",
                                    '-D',
                                    ".EOA",
                                    l1_file,
                                    l2_file],
                                    cwd=config.SENTENCE_ALIGNER_ROOT)
    vanilla.wait()
    # allow vanilla time to finish writing all the *.al files
    # increase sleep time if there are any unexpected empty *vanilla_aligned.l1 / *vanilla_aligned.l2 files
    time.sleep(5)
    extract_l1_l2_from_vanilla()
    return True



if __name__ == '__main__':
    pass
