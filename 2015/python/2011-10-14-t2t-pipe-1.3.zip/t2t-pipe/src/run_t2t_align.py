#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# run_t2t_align.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Tree-to-Tree Alignment
"""

from run_word_align import improve_giza_dictionaries
import codecs
import config
import errors
import get_files
import os
import subprocess


def get_tree2tree_alignments(tree2tree_aligner):
    if tree2tree_aligner == "zhechev":
        lex_e2f, lex_f2e = find_and_prepare_lex_probs()
        prepare_zhechev_input()
        if run_zhechev(lex_e2f, lex_f2e) is True:
            return True
    elif tree2tree_aligner == "zhechev_str2str":
        lex_e2f, lex_f2e = find_and_prepare_lex_probs()
        prepare_zhechev_input_str2str()
        if run_zhechev_str2str(lex_e2f, lex_f2e) is True:
            return True

    else:
        errors.err_log_and_exit(errors.TREE2TREE_ALIGNER_NOT_IMPLEMENTED)

def get_dictfile():
    if config.DICT_SOURCE == "no_dict":
        errors.err_log(errors.NO_DICT_AFTER_GIZA)
        return None
    if config.DICT_SOURCE == "dict_cc":
        dictfile = get_files.get_file(config.DICT_DIRECTORY, 
                                       config.L1 + "-" + config.L2 \
                                       + "_"+ config.DICT_SOURCE + ".dic")
    return dictfile

def find_and_prepare_lex_probs():
    """Find GIZA++-style ``lex.e2f`` and ``lex.f2e`` files. Update automatically computed
word alignment probabilities with third party dictionary if 
:py:func:`config.UPDATE_WORD_PROBS_WITH_DICT` is ``True``. 

.. todo:: add check before updating dictionaries, if there is already a ``lex.e2f.orig`` file in the directory, don't update or ask if user really intends to update a second time. 
"""
    if config.PATH_TO_WORD_ALIGNMENT_PROBS == '':
        lex_probs_path = os.path.join(config.TMP_DIRECTORY,
                                      config.CORPUS_ID + "_" + config.CORPUS_YEARS,
                                      "model")
    else:
        lex_probs_path = config.PATH_TO_WORD_ALIGNMENT_PROBS
    
    lex_e2f = get_files.get_file(lex_probs_path, "lex.e2f")
    lex_f2e = get_files.get_file(lex_probs_path, "lex.f2e")
    
    print "found GIZA dictionary files : \n"
    print lex_e2f
    print lex_f2e
    
    dictfile = get_dictfile()
    
    if config.UPDATE_WORD_PROBS_WITH_DICT and dictfile != None:
        improve_giza_dictionaries(lex_e2f, lex_f2e, dictfile)

    return lex_e2f, lex_f2e


def prepare_zhechev_input():
    
    l1_files = get_files.get_files(config.TMP_DIRECTORY, 'parser_out.' + config.L1)
    l2_files = get_files.get_files(config.TMP_DIRECTORY, 'parser_out.' + config.L2)
    
    for l1_file, l2_file in zip(l1_files, l2_files):
        with codecs.open(l1_file, 'r', 'utf-8') as s:
            source = [line for line in s]
        with codecs.open(l2_file, 'r', 'utf-8') as t:
            target = [line for line in t]
        
        zhechev_in_name = l1_file[:-13] + 'zhechev_in.txt'
        with codecs.open(zhechev_in_name, 'w', 'utf-8') as z:
            for i in range(len(source)):
                z.write(source[i].strip() + "\n")
                z.write(target[i].strip() + "\n\n\n")
        print "input file written: ", zhechev_in_name
    return True


def run_zhechev(lex_e2f, lex_f2e):
    zhechev_in_files = get_files.get_files(config.TMP_DIRECTORY, 
                                           'zhechev_in.txt', return_absolute_path=False)
    for f in zhechev_in_files:
        zhechev_in = os.path.join(config.TMP_DIRECTORY, f)
        zhechev_out = os.path.join(config.OUTPUT_DIRECTORY, f[:-14] + "zhechev.aligned")
        zhechev_config = os.path.join(config.TMP_DIRECTORY,
                                      config.CORPUS_ID + "_" + config.CORPUS_YEARS + \
                                      "_zhechev.config")
        with codecs.open(zhechev_config, "w", "utf-8") as z_config:
            z_config.write("input " + zhechev_in + "\n")
            z_config.write("source_alignments " + lex_e2f + "\n")
            z_config.write("target_alignments " + lex_f2e + "\n")
            z_config.write("# phrase_alignments " + "<source_to_target_phrase_probs>" + "\n")
            z_config.write("output " + zhechev_out + "\n")
            z_config.write("# log " + "<path_to_stderr_log_file>" + "\n")
            z_config.write("# expensive_statistics " + "{*all*, none, POS, search}" + "\n")

        zhechev = subprocess.Popen(
                                   ["./align",
                                    zhechev_config],
                                    cwd=config.TREE2TREE_ALIGNER_ROOT)
        zhechev.wait()

    return True

def prepare_zhechev_input_str2str():
    
    l1_files = get_files.get_aligned_files(config.TMP_DIRECTORY, config.L1)
    l2_files = get_files.get_aligned_files(config.TMP_DIRECTORY, config.L2)
    
    for l1_file, l2_file in zip(l1_files, l2_files):
        with codecs.open(l1_file, 'r', 'utf-8') as s:
            source = [line for line in s]
        with codecs.open(l2_file, 'r', 'utf-8') as t:
            target = [line for line in t]
        
        zhechev_in_name = l1_file[:-14] + 'zhechev_in.txt'
        with codecs.open(zhechev_in_name, 'w', 'utf-8') as z:
            for i in range(len(source)):
                z.write(source[i].strip() + "\n")
                z.write(target[i].strip() + "\n\n\n")
        print "input file written: ", zhechev_in_name
    return True


def run_zhechev_str2str(lex_e2f, lex_f2e):
    zhechev_in_files = get_files.get_files(config.TMP_DIRECTORY, 
                                           'zhechev_in.txt', return_absolute_path=False)
    for f in zhechev_in_files:
        zhechev_in = os.path.join(config.TMP_DIRECTORY, f)
        zhechev_out = os.path.join(config.OUTPUT_DIRECTORY, f[:-15] + "_zhechev.aligned")
        zhechev_config = os.path.join(config.TMP_DIRECTORY,
                                      config.CORPUS_ID + "_" + config.CORPUS_YEARS + \
                                      "_zhechev.config")
        with codecs.open(zhechev_config, "w", "utf-8") as z_config:
            z_config.write("operation_mode str2str\n")
            z_config.write("input_type plain\n")
            z_config.write("input " + zhechev_in + "\n")
            z_config.write("source_alignments " + lex_e2f + "\n")
            z_config.write("target_alignments " + lex_f2e + "\n")
            z_config.write("# phrase_alignments " + "<source_to_target_phrase_probs>" + "\n")
            z_config.write("output_type standard\n")
            z_config.write("output " + zhechev_out + "\n")
            z_config.write("# log " + "<path_to_stderr_log_file>" + "\n")
            z_config.write("# expensive_statistics " + "{*all*, none, POS, search}" + "\n")

        zhechev = subprocess.Popen(
                                   ["./align_str2str",
                                    zhechev_config],
                                    cwd=config.TREE2TREE_ALIGNER_ROOT)
        zhechev.wait()

    return True


if __name__ == '__main__':
    pass
