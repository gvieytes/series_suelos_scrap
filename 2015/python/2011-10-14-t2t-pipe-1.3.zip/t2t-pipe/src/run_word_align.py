#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# run_word_align.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Word Alignment
"""

from collections import defaultdict
import config
import errors
import codecs
import os
import subprocess
import sys
import get_files
import time

def get_word_alignment_probs(word_aligner):
    if word_aligner == "giza_in_moses":
        prepare_giza_input()
        if run_giza_in_moses() is True:
            return True
    elif word_aligner == "giza":
        if run_giza() is True:
            return True
    elif word_aligner == "berkeley":
        if run_berkeley() is True:
            return True
    elif word_aligner == "berkeley_syn":
        if run_berkeley_syntactic() is True:
            return True
    else:
        errors.err_log_and_exit(errors.WORD_ALIGNER_NOT_IMPLEMENTED)

def prepare_giza_input():
    '''Run Perlscript ``clean-corpus-n.perl`` included in MOSES to prepare Corpus for GIZA++
    Max sentence length for word alignment: 40 tokens (see [sennrich:2009]_ : 28)
    '''
    concat_files()
    files = get_files.get_files(config.TMP_DIRECTORY, "all_aligned." + config.L1)
    for f in files:
        corpus = f[:-3]
        clean_corpus_for_giza = subprocess.Popen(
                                   ["./clean-corpus-n.perl",
                                    corpus,
                                    config.L1,
                                    config.L2,
                                    corpus + "_giza_in",
                                    "1",
                                    "40"],
                                    cwd=config.WORD_ALIGNER_ROOT)
        clean_corpus_for_giza.wait()

    return True


def concat_files():
    l1_file_name = os.path.join(config.TMP_DIRECTORY,
                                config.CORPUS_ID + "_" + config.CORPUS_YEARS + config.PA + \
                                "all_aligned." + config.L1)
    l2_file_name = os.path.join(config.TMP_DIRECTORY,
                                config.CORPUS_ID + "_" + config.CORPUS_YEARS + config.PA + \
                                "all_aligned." + config.L2)

    l1_files = get_files.get_files(config.TMP_DIRECTORY,
                                   "aligned." + config.L1, return_absolute_path=False)
    l2_files = get_files.get_files(config.TMP_DIRECTORY,
                                   "aligned." + config.L2, return_absolute_path=False)

    with codecs.open(l1_file_name, "w", "utf-8") as out_l1:
        for f in l1_files:
            with codecs.open(os.path.join(config.TMP_DIRECTORY, f), "r", "utf-8") as in_l1:
                for line in in_l1:
                    out_l1.write(line)

    with codecs.open(l2_file_name, "w", "utf-8") as out_l2:
        for f in l2_files:
            with codecs.open(os.path.join(config.TMP_DIRECTORY, f), "r", "utf-8") as in_l2:
                for line in in_l2:
                    out_l2.write(line)

    return True

def run_giza_in_moses():
    files = get_files.get_files(config.TMP_DIRECTORY, "giza_in." + config.L1)
    print files
    for f in files:
        corpus = f[:-3]
        word_prob_directory = os.path.join(config.TMP_DIRECTORY,
                                           config.CORPUS_ID + "_" + config.CORPUS_YEARS)
        print corpus
        moses = subprocess.Popen(
                                   ["./train-model.perl",
                                   # for moses versions prior to 04/05/2010 use:
                                   # "./train-factored-phrase-model.perl", 
                                    "--corpus",
                                    corpus,
                                    "--root-dir",
                                    word_prob_directory,
                                    "--f",
                                    config.L2,
                                    "--e",
                                    config.L1,
                                    "--last-step",
                                    "4"],
                                    cwd=config.WORD_ALIGNER_ROOT)
        moses.wait()

    return True

# This function is called only if PATH_TO_WORD_ALIGNMENT_PROBS in config.py is
# not specified -> carefully prepared dictionaries will not be changed
def improve_giza_dictionaries(lex_e2f, lex_f2e, dictfile):
    """Update probabilistic GIZA++ files with third party dictionary

.. todo:: properly redistribute probability mass instead of just setting probability of new entries to 1.0

"""
    dict_cc_e2f = defaultdict(float)
    dict_cc_f2e = defaultdict(float)
    giza_e2f = defaultdict(float)
    giza_f2e = defaultdict(float)

    print "\nUpdate GIZA files with third party dictionary file:\n"
    print dictfile
    with codecs.open(dictfile, "r", "utf-8") as in_f:
        print "\nreading third party dictionary file ... "
        for line in in_f:
            entry_l1 = line.split(" @ ")[1].strip()
            entry_l2 = line.split(" @ ")[0].strip()
            dict_cc_e2f[entry_l2 + " " + entry_l1] = 1.0
            dict_cc_f2e[entry_l1 + " " + entry_l2] = 1.0

    with codecs.open(lex_e2f, "r", "utf-8") as in_f:
        print "reading original lex.e2f file ... "
        print lex_e2f
        for line in in_f:
            entry_l1 = line.split(" ")[1].strip()
            entry_l2 = line.split(" ")[0].strip()
            alignment_prob = float(line.split(" ")[2].strip())
            # Make sure that dict.cc entries have priority over
            # automatically computed GIZA probabilities
            if alignment_prob == 1.0:
                giza_e2f[entry_l2 + " " + entry_l1] = 0.9
            else:
                giza_e2f[entry_l2 + " " + entry_l1] = alignment_prob

    os.rename(lex_e2f, lex_e2f + ".orig")

    with codecs.open(lex_f2e, "r", "utf-8") as in_f:
        print "reading original lex.f2e file ... "
        print lex_f2e
        for line in in_f:
            entry_l1 = line.split(" ")[0].strip()
            entry_l2 = line.split(" ")[1].strip()
            alignment_prob = float(line.split(" ")[2].strip())
            # Make sure that dict.cc entries have priority over
            # automatically computed GIZA probabilities
            if alignment_prob == 1.0:
                giza_f2e[entry_l1 + " " + entry_l2] = 0.9
            else:
                giza_f2e[entry_l1 + " " + entry_l2] = alignment_prob
    os.rename(lex_f2e, lex_f2e + ".orig")

    giza_e2f.update(dict_cc_e2f)
    giza_f2e.update(dict_cc_f2e)

    progress_range = range(10000, 10000000, 10000)

    with codecs.open(lex_e2f, "w", "utf-8") as out_f:
        
        entry_counter = 0

        print "\n\nsorting dictionary entries (this might take a while) ... "
        print "writing new lex.e2f file ... (progress: * = 10000 entries)\n\n"
        for k, v in sorted(giza_e2f.iteritems()):
            entry_counter += 1
            if entry_counter in progress_range:
                print "*",
                sys.stdout.flush()
            if len(k.split()) == 2:
                # Attention: UnicodeEncodeError if .format is used
                # out_f.write("{0} {1:.7f}\n".format(k, v))
                out_f.write("%s %.7f \n" % (k, v))
            else:
                print k


    with codecs.open(lex_f2e, "w", "utf-8") as out_f:
        
        entry_counter = 0
        
        print "\n\nsorting dictionary entries (this might take a while) ... "
        print "writing new lex.f2e file ... (progress: * = 10000 entries)\n\n"
        for k, v in sorted(giza_f2e.iteritems()):
            entry_counter += 1
            if entry_counter in progress_range:
                print "*",
                sys.stdout.flush()
            if len(k.split()) == 2:
                # Attention: UnicodeEncodeError if .format is used
                # out_f.write("{0} {1:.7f}\n".format(k, v))
                out_f.write("%s %.7f \n" % (k, v))
            else:
                print k

    return True


def run_giza():
    errors.err_log(errors.WORD_ALIGNER_NOT_IMPLEMENTED)


def run_berkeley():
    berkeley_conf = os.path.join(config.TMP_DIRECTORY,
                                 config.CORPUS_ID + "_" + config.CORPUS_YEARS + \
                                 "_berkeley.conf")
    word_prob_directory = os.path.join(config.TMP_DIRECTORY,
                                       config.CORPUS_ID + "_" + config.CORPUS_YEARS)
    # Create directory for word alignment files
    if os.path.isdir(word_prob_directory):
        print "exists: ", word_prob_directory
    else:
        os.mkdir(word_prob_directory)
        print "created: ", word_prob_directory

    with codecs.open(berkeley_conf, "w", "utf-8") as conf:
            conf.write(u"""## {0}
## {1}
##
##########################################
# Training: Defines the training regimen #
##########################################

forwardModels    MODEL1 HMM
reverseModels    MODEL1 HMM
mode    JOINT JOINT
iters    6 6

###############################################
# Execution: Controls output and program flow #
###############################################

execDir    {2}
create
overwriteExecDir
saveParams    true
numThreads    2
msPerLine    10000
alignTraining
saveLexicalWeights
# leaveTrainingOnDisk
# searchForThreshold

#################
# Language/Data #
#################

foreignSuffix    {3}
englishSuffix    {4}
#lowercase

# Choose the training sources, which can either be directories or files that list files/directories
# Note that training on the test set does not peek at the correct answers (no cheating)
trainSources    {5}
sentences    MAX

# The test sources must have hand alignments for all sentence pairs
testSources
# maxTestSentences    MAX
# offsetTestSentences    0

##############
# Evaluation #
##############
competitiveThresholding
writeGIZA

""".format(berkeley_conf.split(os.sep)[-1], len(berkeley_conf.split(os.sep)[-1])*"-", 
           word_prob_directory, 
           config.L2, config.L1, 
           word_prob_directory))
    
    if config.SENTENCE_ALIGNER == "hunalign":
        in_file_ext = "hun_aligned."
    else:
        in_file_ext = config.SENTENCE_ALIGNER + "_aligned."
    
    l1_files = get_files.get_files(config.TMP_DIRECTORY, in_file_ext + config.L1,
                                   return_absolute_path=False)
    l2_files = get_files.get_files(config.TMP_DIRECTORY, in_file_ext + config.L2,
                                   return_absolute_path=False)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, in_file_ext+"L1/L2")
    # Temporarily rename files from config.TMP_DIRECTORY/file.tok to MICROSOFT_BSA_TMP/file.snt
    for l1_file, l2_file in zip(l1_files, l2_files):
        get_files.rename_file(l1_file, in_file_ext + config.L1, in_file_ext + config.L1,
                              in_dir=config.TMP_DIRECTORY, out_dir=word_prob_directory)
        get_files.rename_file(l2_file, in_file_ext + config.L2, in_file_ext + config.L2,
                              in_dir=config.TMP_DIRECTORY, out_dir=word_prob_directory)
    
    berkeley = subprocess.Popen(
                               ["./align",
                                berkeley_conf],
                                cwd=config.WORD_ALIGNER_ROOT)
    berkeley.wait()
    
    berkeley2moses_lexprobs(word_prob_directory)

    # rename files back from MICROSOFT_BSA_TMP/file.snt to config.TMP_DIRECTORY/file.tok
    l1_files = get_files.get_files(word_prob_directory, in_file_ext + config.L1, 
                                   return_absolute_path=False)
    l2_files = get_files.get_files(word_prob_directory, in_file_ext + config.L2, 
                                   return_absolute_path=False)
    errors.check_parallel_input_files(l1_files, l2_files, word_prob_directory, in_file_ext+"L1/L2")
    for l1_file, l2_file in zip(l1_files, l2_files):
        get_files.rename_file(l1_file, in_file_ext + config.L1, in_file_ext + config.L1,
                              in_dir=word_prob_directory, out_dir=config.TMP_DIRECTORY)
        get_files.rename_file(l2_file, in_file_ext + config.L2, in_file_ext + config.L2,
                              in_dir=word_prob_directory, out_dir=config.TMP_DIRECTORY)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, in_file_ext)

    return True

def run_berkeley_syntactic():
    berkeley_conf = os.path.join(config.TMP_DIRECTORY,
                                 config.CORPUS_ID + "_" + config.CORPUS_YEARS + \
                                 "_berkeley_syntactic.conf")
    word_prob_directory = os.path.join(config.TMP_DIRECTORY,
                                       config.CORPUS_ID + "_" + config.CORPUS_YEARS)
    # Create directory for word alignment files
    if os.path.isdir(word_prob_directory):
        print "exists: ", word_prob_directory
    else:
        os.mkdir(word_prob_directory)
        print "created: ", word_prob_directory

    with codecs.open(berkeley_conf, "w", "utf-8") as conf:
            conf.write(u"""## {0}
## {1}
##
##########################################
# Training: Defines the training regimen #
##########################################

forwardModels    MODEL1 SYNTAX_HMM
reverseModels    MODEL1 HMM
mode    JOINT JOINT
iters    1 1

###############################################
# Execution: Controls output and program flow #
###############################################

execDir    {2}
create
overwriteExecDir
saveParams    true
numThreads    2
msPerLine    10000
alignTraining
saveLexicalWeights
leaveTrainingOnDisk
# searchForThreshold

#################
# Language/Data #
#################

foreignSuffix    {3}
englishSuffix    {4}
lowercase

# Choose the training sources, which can either be directories or files that list files/directories
# Note that training on the test set does not peek at the correct answers (no cheating)
trainSources    {5}
sentences    MAX

# The test sources must have hand alignments for all sentence pairs
testSources
#maxTestSentences    MAX
#offsetTestSentences    0

##############
# Evaluation #
##############
competitiveThresholding
writeGIZA

""".format(berkeley_conf.split(os.sep)[-1], len(berkeley_conf.split(os.sep)[-1])*"-", 
           word_prob_directory, 
           config.L2, config.L1, 
           word_prob_directory))
    
    if config.SENTENCE_ALIGNER == "hunalign":
        in_file_ext = "hun_aligned."
    else:
        in_file_ext = config.SENTENCE_ALIGNER + "_aligned."
    
    l1_files = get_files.get_files(config.TMP_DIRECTORY, in_file_ext + config.L1,
                                   return_absolute_path=False)
    l1_parsed_files = get_files.get_files(config.TMP_DIRECTORY, "parser_out." + config.L1,
                                   return_absolute_path=False)
    l2_files = get_files.get_files(config.TMP_DIRECTORY, in_file_ext + config.L2,
                                   return_absolute_path=False)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, in_file_ext+"L1/L2")
    
    for f in l1_parsed_files:
        with codecs.open(os.path.join(config.TMP_DIRECTORY, f), "r", "utf-8") as l1_parsed:
            with codecs.open(os.path.join(word_prob_directory, 
                                          "{0}aligned.{1}trees".format(f[:-13], config.L1)), 
                                          "w", "utf-8") as l1_tree:
                for line in l1_parsed:
                    if line.startswith("(ROOT (NUR "):
                        l1_tree.write(line.strip()[11:-2])
                        l1_tree.write("\n")
                    elif line.startswith("(ROOT "):
                        l1_tree.write(line.strip()[6:-1])
                        l1_tree.write("\n")
                    else:
                        l1_tree.write(line)
                
    # Temporarily rename files from config.TMP_DIRECTORY/file.tok to MICROSOFT_BSA_TMP/file.snt
    for l1_file, l2_file in zip(l1_files, l2_files):
        get_files.rename_file(l1_file, in_file_ext + config.L1, in_file_ext + config.L1,
                              in_dir=config.TMP_DIRECTORY, out_dir=word_prob_directory)
        get_files.rename_file(l2_file, in_file_ext + config.L2, in_file_ext + config.L2,
                              in_dir=config.TMP_DIRECTORY, out_dir=word_prob_directory)
    time.sleep(5)
    berkeley = subprocess.Popen(
                               ["./align",
                                berkeley_conf],
                                cwd=config.WORD_ALIGNER_ROOT)
    berkeley.wait()
    
    berkeley2moses_lexprobs(word_prob_directory)

    # rename files back from MICROSOFT_BSA_TMP/file.snt to config.TMP_DIRECTORY/file.tok
    l1_files = get_files.get_files(word_prob_directory, in_file_ext + config.L1, 
                                   return_absolute_path=False)
    l2_files = get_files.get_files(word_prob_directory, in_file_ext + config.L2, 
                                   return_absolute_path=False)
    errors.check_parallel_input_files(l1_files, l2_files, word_prob_directory, in_file_ext+"L1/L2")
    for l1_file, l2_file in zip(l1_files, l2_files):
        get_files.rename_file(l1_file, in_file_ext + config.L1, in_file_ext + config.L1,
                              in_dir=word_prob_directory, out_dir=config.TMP_DIRECTORY)
        get_files.rename_file(l2_file, in_file_ext + config.L2, in_file_ext + config.L2,
                              in_dir=word_prob_directory, out_dir=config.TMP_DIRECTORY)
    errors.check_parallel_input_files(l1_files, l2_files, config.TMP_DIRECTORY, in_file_ext)

    return True


def berkeley2moses_lexprobs(word_prob_directory):
    
    wa_model_directory = os.path.join(word_prob_directory, "model")
    # Find/Create moses-style directory for lex.e2f, lex.f2e files
    if os.path.isdir(wa_model_directory):
        print "exists: ", wa_model_directory
    else:
        os.mkdir(wa_model_directory)
        print "created: ", wa_model_directory
    
    lw_berkeley_l1 = os.path.join(word_prob_directory, "1.lexweights")
    lw_berkeley_l2 = os.path.join(word_prob_directory, "2.lexweights")

    lw_moses_f2e = os.path.join(wa_model_directory, "lex.f2e")
    lw_moses_e2f = os.path.join(wa_model_directory, "lex.e2f")
    
    for lw_berkeley, lw_moses in zip([lw_berkeley_l1, lw_berkeley_l2], [lw_moses_f2e, lw_moses_e2f]):
        entries = []
        with codecs.open(lw_berkeley, "r", "utf-8") as lw:
            with codecs.open(lw_moses, "w", "utf-8") as lex:
                for line in lw:
                    if len(line.split("\t")) == 4:
                        entries.append([line.split("\t")[0].strip(), []])
                    else:
                        entries[-1][-1].append(line.strip())
                
                print u"\nwriting: {0} ...\n".format(lw_moses.split(os.sep)[-1])
                for e in sorted(entries):
                    for t in e[1]:
                        if e[0] == "(NULL)":
                            lex.write(u"NULL {0}\n".format(" ".join(t.split(": "))))
                        else:
                            lex.write(u"{0} {1}\n".format(e[0], " ".join(t.split(": "))))
    return True


if __name__ == '__main__':
    berkeley2moses_lexprobs(os.path.join(config.TMP_DIRECTORY,
                            config.CORPUS_ID + "_" + config.CORPUS_YEARS))
