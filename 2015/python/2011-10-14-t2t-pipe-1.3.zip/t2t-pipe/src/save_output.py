#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# save_output.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe - Save Output Files (executable)

**Usage**
        
Type: ``./save_output.py`` to update TMX_PHRASE files with the latest alignments in the
Stockholm TreeAligner files. 

"""
from resources.tagsets import STTS, FTB_STAN, TAGSETS
from info import get_name, get_version_string
from lxml import etree as ET
from resources.brackparser.nodes import TreeElementsFactory, ELEM_SPLIT
from resources.brackparser.brackparser import parse
from resources.sta_alignment_stats import get_sta_alignment_stats
import codecs
import config
import errors
import os
import prepare_corpus
import uuid
import get_files

def save_output_file(format):
    if format == "TigerXML":
        if save_tiger_xml_and_sta_alignments() is True:
            return True
    elif format == "TMX_SENTS":
        if save_tmx_sents() is True:
            return True
    elif format == "TMX_PHRASES":
        if save_tmx_phrase() is True:
            return True
    else:
        errors.err_log_and_exit(errors.OUTPUT_FORMAT_NOT_SUPPORTED)

#
T2T_NAME = get_name()
T2T_VERSION = get_version_string()

# TIGER-XML specific Metadata
DATE = config.date()

XMLNS_NAMESPACE = "http://www.w3.org/2001/XMLSchema-instance"
XMLNS = "%s" % XMLNS_NAMESPACE

XSI_NO_NAMESPACE_LOC = "http://www.cl.uzh.ch/kitt/treealigner/data/schema/TigerXML.xsd"

TAGSET_L1 = TAGSETS[config.PARSER_L1]
TAGSET_L2 = TAGSETS[config.PARSER_L2]

FORMAT_L1 = "Format: TigerXML - Tok: {0} - SntAlign: {1} Parser: {2} - WordAlign: {3} Tagset: {4}".format("NLTK", 
                                                                                                         config.SENTENCE_ALIGNER, 
                                                                                                         config.PARSER_L1, 
                                                                                                         config.WORD_ALIGNER, 
                                                                                                         TAGSET_L1)
FORMAT_L2 = "Format: TigerXML - Tok: {0} - SntAlign: {1} Parser: {2} - WordAlign: {3} Tagset: {4}".format("NLTK", 
                                                                                                         config.SENTENCE_ALIGNER, 
                                                                                                         config.PARSER_L2, 
                                                                                                         config.WORD_ALIGNER, 
                                                                                                         TAGSET_L2)

HISTORY = config.DESCRIPTION


def save_tiger_xml_and_sta_alignments():
    zhechev_l1_l2()
    generate_tiger_xml()
    return True

def save_tmx_sents():
    print "\n\ncreating .tmx-output (segmentation: sentence)"
    l1_files, l2_files = get_sent_aligned_files()
    generate_tmx_sent_files(l1_files, l2_files)

def save_tmx_phrase():
    sta_al_files = get_files.get_files(config.OUTPUT_XML, "sta.xml")
    print "\n\ncreating .tmx-output (segmentation: phrase)"
    for f in sta_al_files:
        print f
        xml_sta_al = ET.parse(f)
        xpath_l1_file = xml_sta_al.xpath('head/treebanks/treebank[@id="{0}"]/@filename'.format(config.L1))[0]
        xpath_l2_file = xml_sta_al.xpath('head/treebanks/treebank[@id="{0}"]/@filename'.format(config.L2))[0]
        xml_l1 = ET.parse(os.path.join(config.OUTPUT_XML, xpath_l1_file))
        xml_l2 = ET.parse(os.path.join(config.OUTPUT_XML, xpath_l2_file))
        generate_tmx_phrase_files(xml_l1, xml_l2, xml_sta_al, f)


def generate_tmx_phrase_files(xml_l1, xml_l2, xml_sta_al, f):
    alignments = []
    root_sentences_l1 = [id.attrib["root"] for id in xml_l1.findall("body/s/graph")]
    root_sentences_l2 = [id.attrib["root"] for id in xml_l2.findall("body/s/graph")]
#    print root_sentences_l1
#    print root_sentences_l2
    al_counter = 0
    for alignment in xml_sta_al.findall("alignments/align"):
        for al in alignment.getchildren():
            if al.attrib["treebank_id"] == config.L1:
                node_l1 = al.attrib["node_id"]
                al_counter += 1
            if al.attrib["treebank_id"] == config.L2:
                node_l2 = al.attrib["node_id"]
                al_counter += 1
            if al_counter == 2:
                alignments.append((node_l1, node_l2))
                al_counter = 0
    tmx_alignment_l1 = []
    tmx_alignment_l2 = []
    tmx_additional_alignments = []
    for al in alignments:
#        print al
        if int(al[0].split("_")[1]) >= 500 and al[0] not in root_sentences_l1:
            tmx_alignment_l1.append(al)
        if int(al[1].split("_")[1]) >= 500 and al[1] not in root_sentences_l2:
            tmx_alignment_l2.append(al)
#    print tmx_alignment_l1
#    print tmx_alignment_l2
    for al in tmx_alignment_l2:
        if al not in tmx_alignment_l1:
            tmx_additional_alignments.append(al)
#    print tmx_additional_alignments
    unique_alignments = tmx_alignment_l1 + tmx_additional_alignments

    aligned_terminals = []
    for al in unique_alignments:
        terminals_l1 = []
        terminals_l2 = []
#        print "L1:", al[0]
        if int(al[0].split("_")[1]) >= 500:
            for edge in xml_l1.xpath('body/s[@id="{0}"]/graph/nonterminals/nt[@id="{1}"]'.format(al[0].split("_")[0], al[0]))[0].getchildren():
                try:
#                    print edge.attrib["idref"]
                    terminals_l1.append(edge.attrib["idref"])
                except KeyError:
                    print "*",
        else:
            terminals_l1.append(al[0])

#        print "L2:", al[1]
        if int(al[1].split("_")[1]) >= 500:
            for edge in xml_l2.xpath('body/s[@id="{0}"]/graph/nonterminals/nt[@id="{1}"]'.format(al[1].split("_")[0], al[1]))[0].getchildren():
                try:
#                    print edge.attrib["idref"]
                    terminals_l2.append(edge.attrib["idref"])
                except KeyError:
                    print "*",
        else:
            terminals_l2.append(al[1])

        aligned_terminals.append((terminals_l1, terminals_l2))

#    print aligned_terminals
    for al in aligned_terminals:
#        print al
        for e in al[0]:
#            print e
            if int(e.split("_")[1]) >= 500:
                al[0].pop(al[0].index(e))
                for t in expand_nt(e, xml_l1):
                    al[0].append(t)
        for e in al[1]:
#            print e
            if int(e.split("_")[1]) >= 500:
                al[1].pop(al[1].index(e))
                for t in expand_nt(e, xml_l2):
                    al[1].append(t)

#    print "at list", aligned_terminals

    # TMX_PHRASE generator, using lxml.etree
    tmx_phrase_tree = None
    root = ET.Element("tmx",
                      version="1.1")
    header = ET.SubElement(root, "header",
                         creationtool=T2T_NAME,
                         creationtoolversion=T2T_VERSION,
                         segtype="phrase",
                         o_tmf=T2T_NAME + " TMX",
                         adminlang="EN-US",
                         srclang=config.L1_TMX,
                         datatype="plaintext"
                         )

    body = ET.SubElement(root, "body")

    for al in aligned_terminals:
        phrase_l1 = []
        phrase_l2 = []

        print "\nL1:"
        for e in sorted(al[0]):
            if int(e.split("_")[1]) >= 500:
                al[0].pop(al[0].index(e))
                for t in expand_nt(e, xml_l1):
                    al[0].append(t)
            else:
                path_l1 = r'body/s[@id="{0}"]/graph/terminals/t[@id="{1}"]/@word'.format(e.split("_")[0], e)
                print xml_l1.xpath(path_l1)[0],
                phrase_l1.append(xml_l1.xpath(path_l1)[0])

        print "\nL2:"
        for e in al[1]:
            if int(e.split("_")[1]) >= 500:
                al[1].pop(al[1].index(e))
                for t in expand_nt(e, xml_l2):
                    al[1].append(t)
            else:
                path_l2 = r'body/s[@id="{0}"]/graph/terminals/t[@id="{1}"]/@word'.format(e.split("_")[0], e)
                print xml_l2.xpath(path_l2)[0],
                phrase_l2.append(xml_l2.xpath(path_l2)[0])

        tu = ET.SubElement(body, "tu")
        tuv_l1 = ET.SubElement(tu, "tuv",
                            lang=config.L1_TMX
                            )
        seg_l1 = ET.SubElement(tuv_l1, "seg")
        seg_l1.text = " ".join(phrase_l1)

        tuv_l2 = ET.SubElement(tu, "tuv",
                            lang=config.L2_TMX
                            )
        seg_l2 = ET.SubElement(tuv_l2, "seg")
        seg_l2.text = " ".join(phrase_l2)

    outfile = f.split(os.sep)[-1][:-28] + "phrase.tmx"
    with codecs.open(os.path.join(config.OUTPUT_DIRECTORY, "tmx", outfile),
                     "w", "utf-8") as tmxfile:
        tmx_phrase_tree = ET.tostring(root, xml_declaration=True,
                                    encoding="utf-8", pretty_print=True)
        tmxfile.write(unicode(tmx_phrase_tree, 'utf8'))

    prepare_corpus.perl_re_sub(r's/o_tmf/o-tmf/',
                               os.path.join(config.OUTPUT_DIRECTORY, "tmx", outfile))
    
    get_sta_alignment_stats(f, range(1, len(root_sentences_l1) + 1))

    return True

def expand_nt(nt, parsed_xml_tree):
    nt_expanded = []
    for edge in parsed_xml_tree.xpath('body/s[@id="{0}"]/graph/nonterminals/nt[@id="{1}"]'.format(nt.split("_")[0], nt))[0].getchildren():
        try:
            nt_expanded.append(edge.attrib["idref"])
        except KeyError:
            continue
    return nt_expanded

def get_sent_aligned_files():
    files = os.listdir(config.TMP_DIRECTORY)
    l1_files = []
    l2_files = []
    for f in sorted(files):
        if f.endswith("aligned." + config.L1):
            l1_files.append(f)
        if f.endswith("aligned." + config.L2):
            l2_files.append(f)
    print l1_files, l2_files
    return l1_files, l2_files


def zhechev_l1_l2():
    files = os.listdir(config.OUTPUT_DIRECTORY)

    for f in sorted(files):
        if f.endswith('.aligned'):
            with codecs.open(os.path.join(config.OUTPUT_DIRECTORY, f), 'r', 'utf-8') as in_f:
                zhechev = []
                counter = 0
                for line in in_f:
                    zhechev.append(line)

            with codecs.open(os.path.join(config.OUTPUT_DIRECTORY, f[:-8] + "_aligned_tree." + config.L1),
                             'w', 'utf-8') as l1f:
                for i in range(0, len(zhechev), 4):
                    l1f.write(zhechev[i])

            with codecs.open(os.path.join(config.OUTPUT_DIRECTORY, f[:-8] + "_aligned_tree." + config.L2),
                             'w', 'utf-8') as l2f:
                for i in range(1, len(zhechev), 4):
                    l2f.write(zhechev[i])

            with codecs.open(os.path.join(config.OUTPUT_DIRECTORY, f[:-8] + "_alignments." + config.L1 + "_" + config.L2),
                             'w', 'utf-8') as af:
                for i in range(2, len(zhechev), 4):
                    af.write(zhechev[i])
    return True

def generate_tmx_sent_files(l1_files, l2_files):

    for l1_file, l2_file in zip(l1_files, l2_files):

        with codecs.open(os.path.join(config.TMP_DIRECTORY, l1_file), 'r', 'utf-8') as l1_in:
            l1_sents = [line.strip() for line in l1_in]
        with codecs.open(os.path.join(config.TMP_DIRECTORY, l2_file), 'r', 'utf-8') as l2_in:
            l2_sents = [line.strip() for line in l2_in]

        if len(l1_sents) == len(l2_sents):

            # TMX_SENT generator, using lxml.etree
            tmx_sent_tree = None
            root = ET.Element("tmx",
                              version="1.1")
            header = ET.SubElement(root, "header",
                                 creationtool=T2T_NAME,
                                 creationtoolversion=T2T_VERSION,
                                 segtype="sentence",
                                 o_tmf=T2T_NAME + " TMX",
                                 adminlang="EN-US",
                                 srclang=config.L1_TMX,
                                 datatype="plaintext"
                                 )

            body = ET.SubElement(root, "body")

            for sent_l1, sent_l2 in zip(l1_sents, l2_sents):
                tu = ET.SubElement(body, "tu")
                tuv_l1 = ET.SubElement(tu, "tuv",
                                    lang=config.L1_TMX
                                    )
                seg_l1 = ET.SubElement(tuv_l1, "seg")
                seg_l1.text = sent_l1

                tuv_l2 = ET.SubElement(tu, "tuv",
                                    lang=config.L2_TMX
                                    )
                seg_l2 = ET.SubElement(tuv_l2, "seg")
                seg_l2.text = sent_l2

            outfile = l1_file[:-10] + "snt.tmx"
            with codecs.open(os.path.join(config.OUTPUT_DIRECTORY, "tmx", outfile),
                             "w", "utf-8") as tmxfile:
                tmx_sent_tree = ET.tostring(root, xml_declaration=True,
                                            encoding="utf-8", pretty_print=True)
                tmxfile.write(unicode(tmx_sent_tree, 'utf8'))

            prepare_corpus.perl_re_sub(r's/o_tmf/o-tmf/',
                                       os.path.join(config.OUTPUT_DIRECTORY, "tmx", outfile))

    return True


def generate_tiger_xml():
    zhechev_l1_files = get_files.get_files(config.OUTPUT_DIRECTORY,
                                           'aligned_tree.' + config.L1, return_absolute_path=False)
    zhechev_l2_files = get_files.get_files(config.OUTPUT_DIRECTORY,
                                           'aligned_tree.' + config.L2, return_absolute_path=False)

    for z_l1, z_l2 in zip(zhechev_l1_files, zhechev_l2_files):
        tiger_xml_pair = []
        for f in (z_l1, z_l2):
            with codecs.open(os.path.join(config.OUTPUT_DIRECTORY, f), 'r', 'utf-8') as in_f:
                s_count = 0
                sentences_featurized = []

                for line in in_f:
                    # Remove double brackets produced by berkeley parser
                    if line.startswith("(("):
                        line = line.strip()[1:-1]
                    lrb_count = 0
                    # Expand single phrase sentences (NP::N Mittag) as 
                    for ch in line:
                        if ch == "(":
                            lrb_count += 1
                    if lrb_count == 1:
                        line = line.strip().split("::")[0] + "(" + line.strip().split("::")[1] + ")"
                    s_count += 1
                    elems = []
#                    print s_count, line
                    sentence_featurized = parse(line.strip(),
                                                TreeElementsFactory()).to_feature_list(s_count,
                                                                                       elems)
#                    print sentence_featurized
                    sentences_featurized.append(sentence_featurized)

                # TIGER-XML generator, using lxml.etree
                tree = None
                root = ET.Element("corpus",
                                  id=config.CORPUS_ID)
                head = ET.SubElement(root, "head")

                meta = ET.SubElement(head, "meta")
                name = ET.SubElement(meta, "name")
                name.text = config.CORPUS_ID
                author = ET.SubElement(meta, "author")
                author.text = config.AUTHOR
                date = ET.SubElement(meta, "date")
                date.text = DATE
                description = ET.SubElement(meta, "description")
                description.text = config.DESCRIPTION
                if f.endswith(config.L1):
                    format = ET.SubElement(meta, "format")
                    format.text = FORMAT_L1
                if f.endswith(config.L2):
                    format = ET.SubElement(meta, "format")
                    format.text = FORMAT_L2
                history = ET.SubElement(meta, "history")
                history.text = HISTORY

                annotation = ET.SubElement(head, "annotation")


                feature_names = ["word", "pos", "cat"]
                feature_domains = ["T", "T", "NT"]

                tags = []
                cats = dict()
                pos = dict()

                for s in sentences_featurized:
                    for e in s:
                        if e.startswith("word_pos"):
                            pos_zid = e.split(str(ELEM_SPLIT))[2].rsplit("-",1)
                            if len(pos_zid) == 2:
                                pos[pos_zid[0]] = "see POS-Tagset specifications"
                        if e.startswith("nonterminal"):
                            cats[e.split(str(ELEM_SPLIT))[2].rsplit("-",1)[0]] = "Nonterminal"
#                print sorted(pos.items())
#                print sorted(cats.items())

                feature_values = {"cat": cats, "pos":pos}

                for i in range(len(feature_names)):
                    if feature_names[i] in feature_values:
                        feature = ET.SubElement(annotation, "feature",
                                                name=feature_names[i],
                                                domain=feature_domains[i])
                        for k, v in sorted(feature_values[feature_names[i]].items()):
                            value = ET.SubElement(feature, "value", name=k)
                            if feature_names[i] == "pos" and f.endswith("de") and k in STTS:
                                value.text = STTS[k]
                            elif feature_names[i] == "pos" and f.endswith("fr") and k in FTB_STAN:
                                value.text = FTB_STAN[k]
    #                        elif feature_names[i] == "pos" and f.endswith("en") and k in en_tagset:
    #                            value.text = ENTS[k]

                            else:
                                value.text = v
                    else:
                        feature = ET.SubElement(annotation, "feature",
                                                name=feature_names[i],
                                                domain=feature_domains[i])

                edgelabel = ET.SubElement(annotation, "edgelabel")
                value = ET.SubElement(edgelabel, "value", name="--")
                value.text = "not assigned"

                secedgelabel = ET.SubElement(annotation, "secedgelabel")
                value = ET.SubElement(secedgelabel, "value", name="--")
                value.text = "not assigned"

                body = ET.SubElement(root, "body")

                for s in sentences_featurized:
                    s_nonterminal_list = []
                    s_nonterminal_ids = []
                    s_terminal_list = []
                    s_edge_list = []
                    for i in s:
                        if i.startswith("nonterminal"):
                            s_nonterminal_list.append(i)
                            s_nonterminal_ids.append(i.split(str(ELEM_SPLIT))[1])
                        if i.startswith("word_pos"):
                            s_terminal_list.append(i)
                        if i.startswith("edge"):
                            s_edge_list.append(i)
#                    print s_nonterminal_list
                    if s_nonterminal_list == []:
                        s_nonterminal_list.append("nonterminal" + \
                                                  str(ELEM_SPLIT) + \
                                                  s_terminal_list[0].split(str(ELEM_SPLIT))[4] + \
                                                  str(ELEM_SPLIT) + \
                                                  s_terminal_list[0].split(str(ELEM_SPLIT))[2])
                        print "just one flat nonterminal element - ",
                        print "extract nonterminal info from terminal list: ", s_nonterminal_list
#                    print s_terminal_list
#                    print s_edge_list
                    if s_edge_list == []:
                        s_edge_list.append("edge" + str(ELEM_SPLIT) + \
                                            s_terminal_list[0].split(str(ELEM_SPLIT))[3] + \
                                            str(ELEM_SPLIT) + \
                                            s_terminal_list[0].split(str(ELEM_SPLIT))[4])
                        print "just one flat nonterminal element - ",
                        print "extract edge info from terminal list: ", s_edge_list
                    S_ROOT_ID = s_nonterminal_list[0].split(str(ELEM_SPLIT))[1]
                    S_ID = S_ROOT_ID.split("_")[0]
                    s_sentence = ET.SubElement(body, "s", id=S_ID)
                    s_graph = ET.SubElement(s_sentence, "graph", root=S_ROOT_ID)
                    s_terminals = ET.SubElement(s_graph, "terminals")
                    s_nonterminals = ET.SubElement(s_graph, "nonterminals")

                    for t in s_terminal_list:
                        S_T_ID = t.split(str(ELEM_SPLIT))[3]
                        S_WORD = unicode(t.split(str(ELEM_SPLIT))[1], 'utf8')
                        S_POS_ZHECHEV = t.split(str(ELEM_SPLIT))[2].rsplit("-", 1)
                        S_POS = S_POS_ZHECHEV[0]
                        if len(S_POS_ZHECHEV) == 2:
                            S_ZHECHEV_ID = S_POS_ZHECHEV[-1]
                        else:
                            S_ZHECHEV_ID = False
                        #s_t = ET.SubElement(s_terminals,"t", id=S_T_ID,word=S_WORD, pos=S_POS, zid=S_ZHECHEV_ID)
                        s_t = ET.SubElement(s_terminals, "t", id=S_T_ID, word=S_WORD, pos=S_POS)
                        if S_ZHECHEV_ID != False:
                            s_t.append(ET.Comment("zhechev alignment information :" + \
                                                  S_ID + "_z" + S_ZHECHEV_ID + ":" + S_T_ID))

                    for nt in s_nonterminal_list:
                        S_NT_ID = nt.split(str(ELEM_SPLIT))[1]
                        S_CAT_ZHECHEV = nt.split(str(ELEM_SPLIT))[2].rsplit("-",1)
                        S_CAT = S_CAT_ZHECHEV[0]
                        if len(S_CAT_ZHECHEV) == 2:
                            S_ZHECHEV_ID = S_CAT_ZHECHEV[-1]
                        else:
                            S_ZHECHEV_ID = False
                        #s_nt = ET.SubElement(s_nonterminals,"nt",id=S_NT_ID,cat=S_CAT,zid=S_ZHECHEV_ID)
                        s_nt = ET.SubElement(s_nonterminals, "nt", id=S_NT_ID, cat=S_CAT)
                        if S_ZHECHEV_ID != False:
                            s_nt.append(ET.Comment("zhechev alignment information :" + \
                                                   S_ID + "_z" + S_ZHECHEV_ID + ":" + S_NT_ID))

                        for e in s_edge_list:
                            if S_NT_ID == e.split(str(ELEM_SPLIT))[1]:
                                for t in s_terminal_list:
                                    if e.split(str(ELEM_SPLIT))[2] == t.split(str(ELEM_SPLIT))[4]:
                                        EDGE_ID = t.split(str(ELEM_SPLIT))[3]
                                        print S_NT_ID, "-->", EDGE_ID
                                        s_edge = ET.SubElement(s_nt, "edge", idref=EDGE_ID,
                                                               label="--")
                                if e.split(str(ELEM_SPLIT))[2] in s_nonterminal_ids:
                                    EDGE_ID = e.split(str(ELEM_SPLIT))[2]
                                    print S_NT_ID, "-->", EDGE_ID
                                    s_edge = ET.SubElement(s_nt, "edge", idref=EDGE_ID,
                                                           label="--")

                outfile = f[:-3] + "_" + f[-2:] + ".xml"

                tiger_xml_pair.append(outfile)

                with codecs.open(os.path.join(config.OUTPUT_DIRECTORY, "xml", outfile),
                                 "w", "utf-8") as xmlfile:
                    tree = ET.tostring(root, xml_declaration=True, encoding="utf-8",
                                       pretty_print=True)
                    xmlfile.write(unicode(tree, 'utf8'))
                    #print tree

        print tiger_xml_pair

        with codecs.open(os.path.join(config.OUTPUT_DIRECTORY, "xml", tiger_xml_pair[0]),
                         "r", "utf-8") as l1file:
            l1_alignments = dict()
            for line in l1file:
                if line.strip().startswith("<!--zhechev alignment information"):
                    z_id = line.strip().split(":")[1]
                    tiger_id = line.strip().split(":")[2][:-3]
                    l1_alignments["l1_" + z_id] = tiger_id

        with codecs.open(os.path.join(config.OUTPUT_DIRECTORY, "xml", tiger_xml_pair[1]),
                         "r", "utf-8") as l2file:
            l2_alignments = dict()
            for line in l2file:
                if line.strip().startswith("<!--zhechev alignment information"):
                    z_id = line.strip().split(":")[1]
                    tiger_id = line.strip().split(":")[2][:-3]
                    l2_alignments["l2_" + z_id] = tiger_id
        generate_xml_alignment_file_for_sta(tiger_xml_pair, l1_alignments, l2_alignments)
    return True

def generate_xml_alignment_file_for_sta(tiger_xml_pair, l1_alignments, l2_alignments):
    with codecs.open(os.path.join(config.OUTPUT_DIRECTORY,
                                  tiger_xml_pair[0][:-19] + "alignments.{0}_{1}".format(config.L1,
                                                                                        config.L2)),
                                  'r', 'utf-8') as in_f:
        s_id = 0
        alignments_dict = dict()
        for line in in_f:
            s_id += 1
            for i in range(0, len(line.strip().split()) - 1, 2):
                alignments_dict[
                        unicode(
                        "l1_s{0:05d}_z{1}".format(s_id, line.strip().split()[i]))
                                ] = \
                        unicode(
                        "l2_s{0:05d}_z{1}".format(s_id, line.strip().split()[i + 1]))


        # TIGER-XML generator, using lxml.etree
        alignment_tree = None
        root = ET.Element("treealign",
                          subversion="2",
                          version="2")
        head = ET.SubElement(root, "head")

        meta = ET.SubElement(head, "alignment-metadata")
        description = ET.SubElement(meta, "description")
        description.text = config.CORPUS_ID
        license = ET.SubElement(meta, "license")
        description.text = config.LICENSE
        author = ET.SubElement(meta, "author")
        author.text = config.AUTHOR
        uuid_xml = ET.SubElement(meta, "uuid")
        uuid_xml.text = str(uuid.uuid1())
        date = ET.SubElement(meta, "date")
        date.text = DATE
        revision = ET.SubElement(meta, "revision")
        revision.text = "1"
        data = ET.SubElement(meta, "data")
        data.text = DATE
        history = ET.SubElement(meta, "history")
        change = ET.SubElement(history, "change", date=DATE,
                               author="Zhechev Aligner Version 2.8.6 (T2T-Pipe)")
        change.text = "converted Zhechev Aligner output"

        treebanks = ET.SubElement(head, "treebanks")
        treebank1 = ET.SubElement(treebanks, "treebank", id=config.L1,
                                  language=config.L1_TIGERxml, filename=tiger_xml_pair[0])
        treebank2 = ET.SubElement(treebanks, "treebank", id=config.L2,
                                  language=config.L2_TIGERxml, filename=tiger_xml_pair[1])

        alignment_features = ET.SubElement(head, "alignment-features")

        alignment_features_list = [("good", "#33e533",
                                    "Exakte Alignierung"),
                                   ("fuzzy", "#e53333",
                                    "Ungenaue Alignierung"),
                                   ("zhechev", "#3a9dd6",
                                    "Automatischer Alignierungsvorschlag")]
#                alignment_features_list = [("good","#33e533",
#                                            "Exakte Alignierung"),
#                                           ("fuzzy","#e53333",
#                                            "Ungenaue Alignierung")]
        for i in alignment_features_list:
            alignment_feature = ET.SubElement(alignment_features,
                                              "alignment-feature", color=i[1], name=i[0])
            alignment_feature.text = i[2]

        settings = ET.SubElement(head, "settings")
        display_options = ET.SubElement(settings, "display-options")
        top_treebank = ET.SubElement(display_options, "top-treebank")
        auto_align = ET.SubElement(settings, "auto-align", active="True")

        alignments = ET.SubElement(root, "alignments")

        for k, v in sorted(alignments_dict.items()):
            align = ET.SubElement(alignments, "align", type="zhechev",
                                  last_change=config.date_2(), author="t2t_pipe.py")
            print "L1: ", l1_alignments[k], "-->", "L2: ", l2_alignments[v]
            node1 = ET.SubElement(align, "node",
                                  treebank_id=config.L1, node_id=l1_alignments[k])
            node2 = ET.SubElement(align, "node",
                                  treebank_id=config.L2, node_id=l2_alignments[v])

        alignmentfile = tiger_xml_pair[0].split(".")[0][:-2] + "sta.xml"
        sta_xml = os.path.join(config.OUTPUT_DIRECTORY, "xml", alignmentfile)
        
        with codecs.open(sta_xml, "w", "utf-8") as xmlfile:
            alignment_tree = ET.tostring(root, xml_declaration=True, encoding="utf-8",
                                         pretty_print=True)
            xmlfile.write(alignment_tree)
#                    print alignment_tree

        # stats are usually printed after extraction of tmx-phrases, print here, if phrases are
        # not extracted
        if "TMX_PHRASES" not in config.OUTPUT_FORMATS:
            get_sta_alignment_stats(sta_xml, range(1,s_id + 1))

    return True


if __name__ == '__main__':
    save_tmx_phrase()
