#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
#
# t2t_pipe.py
# Author: Markus Killer (mki) <mki5600@gmail.com> 
# June-September 2010, January 2011
# Licensed under the GNU GPLv2
""".. |modtitle| replace:: Tree-to-Tree (t2t) Alignment Pipe Main Module (executable)

**Usage**

There are two ways of starting the pipe

- update and run ``config.py`` (from any directory on your system)

or

- update ``config.py`` in :const:`T2T_SCRIPTDIR` and run::

    t2t_pipe.py [-1 FIRST_STEP (default=1)] [-2 LAST_STEP (default=7)]

    1    extract parallel corpus / add article boundaries
    2    tokenize parallel corpus
    3    align sentences
    4    parse corpus
    5    get word-alignment probabilities
    6    get tree2tree alignments
    7    save output files

.. note::

    For corpora < 100'000 sentence pairs, do steps 1-4 separately and add
    additional corpus (e.g. europarl) to increase the quality of word alignments.
    Specify ``config.PATH_TO_WORD_ALIGNMENT_PROBS``. If this path is not specified,
    the pipe will compute word alignment frequencies on the basis of the corpus provided.
    If the path to a third party dictionary is specified, the word alignment probabilities
    will be updated with dictionary entries (probability set to 1.0)
    Poor results are expected for corpora < 10'000 sentence pairs.


"""

import config
import errors
import extract_corpus
import get_files
import info
import inspect
import os
import prepare_corpus
import run_parser
import run_preprocessor
import run_snt_align
import run_t2t_align
import run_word_align
import save_output

__version__ = info.get_version_string()


####################################################################################################
# Steps 1 to 7 (Command line options)
####################################################################################################

STEP_00 = "UPDATE configuration file: config.py (executable)\n"
STEP_01 = "step 1 - 'extract parallel corpus / add article boundaries'"
STEP_02 = "step 2 - 'tokenize parallel corpus'"
STEP_03 = "step 3 - 'align sentences'"
STEP_04 = "step 4 - 'parse corpus'"
STEP_05 = "step 5 - 'get word-alignment probabilities'"
STEP_06 = "step 6 - 'get tree2tree alignments'"
STEP_07 = "step 7 - 'save output files'"

STEP_DESCRIPTORS = [STEP_00, STEP_01, STEP_02, STEP_03, STEP_04, STEP_05, STEP_06, STEP_07]

def get_step_descriptions():
    str_buffer = "\n\n"
    for step in STEP_DESCRIPTORS:
        str_buffer += step + "\n"
    return str_buffer

def run_step(step):
    """run the steps supplied as command line options (default: all steps) and 
    communicate beginning and end of each step
    """

    if step == 1:
        print("\n\n" + config.timestamp() + " " + STEP_01 + " started")
        if config.INPUT_FORMAT == "XML":
            errors.check_directory(config.CORPUS_XML_DIRECTORY)
            extract_corpus.get_txt_files_from_xml()
            prepare_corpus.check_and_clean_txt_files()
            print("\n\n" + config.timestamp() + " " + STEP_01 + " completed")
        elif config.INPUT_FORMAT == "TXT":
            errors.check_directory(config.CORPUS_TXT_DIRECTORY)
            get_files.get_corpus_src_files()
            prepare_corpus.check_and_clean_txt_files()
            print("\n\n" + config.timestamp() + " " + STEP_01 + " completed")
        elif config.INPUT_FORMAT == "EUROPARL":
            errors.check_directory(config.CORPUS_TXT_DIRECTORY)
            get_files.get_corpus_src_files()
            prepare_corpus.check_and_clean_txt_files()
            print("\n\n" + config.timestamp() + " " + STEP_01 + " completed")

        else:
            errors.err_log_and_exit(errors.INPUT_FORMAT_NOT_SUPPORTED)

    elif step == 2:
        print("\n\n" + config.timestamp() + " " + STEP_02 + " started\n\n")
        run_preprocessor.snt_word_tokenize_txt_files()
        print("\n\n" + config.timestamp() + " " + STEP_02 + " completed\n\n")

    elif step == 3:
        print("\n\n" + config.timestamp() + " " + STEP_03 + " started\n\n")
        run_snt_align.get_sentence_alignments(config.SENTENCE_ALIGNER)
        print("\n\n" + config.timestamp() + " " + STEP_03 + " completed\n\n")

    elif step == 4:
        print("\n\n" + config.timestamp() + " " + STEP_04 + " (L1) started\n\n")
        run_parser.get_parse_trees(config.PARSER_L1)
        print("\n\n" + config.timestamp() + " " + STEP_04 + " (L1) completed\n\n")
        print("\n\n" + config.timestamp() + " " + STEP_04 + " (L2) started\n\n")
        run_parser.get_parse_trees(config.PARSER_L2)
        print("\n\n" + config.timestamp() + " " + STEP_04 + " (L2) completed\n\n")

    elif step == 5:
        print("\n\n" + config.timestamp() + " " + STEP_05 + "started\n\n")
        try:
            check_files = os.listdir(config.PATH_TO_WORD_ALIGNMENT_PROBS)
            if "lex.e2f" in check_files:
                if "lex.f2e" in check_files:
                    print "Word Alignment Probabilities provided in config.py"
                    print("\n\n" + config.timestamp() + " " + STEP_05 + " skipped\n\n")
            else:
                run_word_align.get_word_alignment_probs(config.WORD_ALIGNER)
        except OSError:
            run_word_align.get_word_alignment_probs(config.WORD_ALIGNER)

        print("\n\n" + config.timestamp() + " " + STEP_05 + " completed\n\n")

    elif step == 6:
        print("\n\n" + config.timestamp() + " " + STEP_06 + " started\n\n")
        run_t2t_align.get_tree2tree_alignments(config.TREE2TREE_ALIGNER)
        print("\n\n" + config.timestamp() + " " + STEP_06 + " completed\n\n")

    elif step == 7:
        print("\n\n" + config.timestamp() + " " + STEP_07 + " started\n\n")
        for format in config.OUTPUT_FORMATS:
            save_output.save_output_file(format)
        print("\n\n" + config.timestamp() + " " + STEP_07 + " completed\n\n")

    else:
        errors.err_log(errors.UNSPECIFIED_ERROR + str(inspect.getmodule(run_step)) + "\n\n")
        errors.err_log_and_exit(str(inspect.getsource(run_step)))

####################################################################################################
# Check/create t2t directories specified in config.py
####################################################################################################

def prepare_t2t_filesystem():
    T2T_DIRECTORIES = [config.T2T_BASE_DIRECTORY,
                       config.T2T_PROJECT_BASE_DIRECTORY,
                       config.INPUT_DIRECTORY,
                       config.TMP_DIRECTORY,
                       config.OUTPUT_DIRECTORY,
                       config.OUTPUT_XML,
                       config.OUTPUT_TMX]
    print "\n\nt2t project: ", config.T2T_PROJECT_NAME
    print "\nt2t directories:\n"
    for directory in T2T_DIRECTORIES:
        print directory
        if os.path.isdir(directory):
            print "exists: ", directory
        else:
            os.mkdir(directory)
            print "created: ", directory
    return True

####################################################################################################
# Check command line options, display help and run steps
####################################################################################################

def main():
    from optparse import OptionParser

    usage = '%prog [options]' + get_step_descriptions()
    parser = OptionParser(usage, version=info.get_full_name())
    parser.add_option('-1', '--first_step', type="int", default=1,
                        help='first step to be run [default=1]')
    parser.add_option('-2', '--last_step', type="int", default=7,
                        help='last step to be run [default=7]')
    (options, args) = parser.parse_args()
    current_steps = range(options.first_step, options.last_step + 1)

    print("\n" + config.timestamp()),
    print(" - tree2tree_pipe started ... running step(s) "),
    print(str(current_steps[0]) + " to " + str(current_steps[-1]) + "\n\n")
    errors.check_languages()
    prepare_t2t_filesystem()
    for i in current_steps:
        run_step(i)

if __name__ == '__main__':
    main()
